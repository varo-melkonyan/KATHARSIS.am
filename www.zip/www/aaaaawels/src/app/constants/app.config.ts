export const appConfig = {
    defaultHomePage: 'list',
    userRole: [
        {
            name: 'manager',
            accessLevel: 1
        },
        {
            name: 'supervisor',
            accessLevel: 2
        },
        {
            name: 'crewman',
            accessLevel: 3
        }
    ],
    wellsStatus: [
        {
            name: 'Upcoming',
            value: 0
        },
        {
            name: 'Ongoing',
            value: 1
        },
        {
            name: 'Done',
            value: 2
        },
    ],

    connectionEstablished: 'ConnectionEstablished::LTR',

    colors: ['#1D6CE8', '#00A280', '#FDCA40', '#FF514E', '#7161EF', '#069FC2', '#42AB7F'],
    accessLevel: JSON.parse(localStorage.getItem('userId')) ? JSON.parse(localStorage.getItem('userId')).accessLevel : '',
    isActive: JSON.parse(localStorage.getItem('userId')) ? !(JSON.parse(localStorage.getItem('userId')).accessLevel === 1 ||
        JSON.parse(localStorage.getItem('userId')).accessLevel === 0) : true,
    mobileUser: false,
    dbVersion: 1,
    dbName: 'JMRDB',
};
