import {Component, OnDestroy, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {ISubscription} from 'rxjs/Subscription';
import {EmployeeService} from './employee.service';
import {DeleteDialogComponent} from '../delete-dialog/delete-dialog.component';
import {MatDialog} from '@angular/material';
import {appConfig} from '../../constants/app.config';
import {AlertService} from '../../services/alert.service';
import {WsService} from '../../services/ws.service';
import {identifierName} from '@angular/compiler';
import {HeaderService} from '../../services/header.service';
import {LokiService} from '../../services/loki.service';

@Component({
    selector: 'app-employee',
    templateUrl: './employee.component.html',
    styleUrls: ['./employee.component.scss']
})
export class EmployeeComponent implements OnInit, OnDestroy {
    private employeeDataSub: ISubscription;
    private dialogRefSub: ISubscription;
    private userRemoveSub: ISubscription;
    private headerSub: ISubscription;

    public data: any;
    public isOpenFilter = false;
    public employeeNameFilter: string;
    public roleFilter: number;
    public emailFilter: string;
    public userRol = appConfig.userRole;
    public isActive = appConfig.isActive;
    public getRemoveUserSub: any;
    public getRemoveUser: any;
    public getUser: any;
    public getUserSub: any;

    constructor(private router: Router,
                public dialog: MatDialog,
                private wsSvc: WsService,
                private alertService: AlertService,
                private headerSvc: HeaderService,
                private svc: EmployeeService,
                private lokiSrc: LokiService) {
        this.getRemoveUserSub = this.lokiSrc.returnCallSub().subscribe(coll => {
            if (coll) {
                this.getRemoveUser = coll.by('name', 'removeUser');
                this.getUser = coll.by('name', 'getUser');
                this.userRemoveSub = this.getRemoveUser.req('', this.wsSvc).subscribe(res => {
                    if (res.header.status === 4000) {
                        this.getUserSub = this.getUser.req(this.wsSvc).subscribe();
                    } else {
                        this.error(res.header.summary);
                    }
                });
            }
        });
        this.headerSub = this.headerSvc.getIsActive().subscribe(isActive => {
            this.isActive = isActive;
        });
        this.employeeDataSub = this.svc.getEmployeeData().subscribe(data => {
            if (data) {
                this.data = data;
            }
        });
    }

    ngOnInit() {
        if (!localStorage.getItem('sign')) {
            this.router.navigate(['sign-in']);
        }
    }

    ngOnDestroy() {
        if (this.getRemoveUserSub) {
            this.getRemoveUserSub.unsubscribe();
        }
        if (this.getUserSub) {
            this.getUserSub.unsubscribe();
        }
        if (this.employeeDataSub) {
            this.employeeDataSub.unsubscribe();
        }
        if (this.userRemoveSub) {
            this.userRemoveSub.unsubscribe();
        }
        if (this.headerSub) {
            this.headerSub.unsubscribe();
        }
    }

    success(message: string) {
        this.alertService.success(message);
    }

    error(message: string) {
        this.alertService.error(message);
    }

    setPage() {
        this.router.navigate(['employee']);
    }

    stopProp(e) {
        e.stopPropagation();
    }

    setWellDataPage(id, name) {
        this.headerSvc.setUrlParams(name);
        this.router.navigate(['employee', id]);
    }

    deleteItem(name, id) {
        const dialogRef = this.dialog.open(DeleteDialogComponent, {
            width: '31%',
            data: name
        });

        this.dialogRefSub = dialogRef.afterClosed().subscribe(result => {
            if (result) {
               this.getRemoveUserSub =  this.getRemoveUser.req(id, this.wsSvc).subscribe();
            }
        });
    }

}
