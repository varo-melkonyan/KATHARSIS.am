import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {LoginComponent} from './login.component';
import {DataComponent} from '../data/data.component';

const routes: Routes = [
  {
    path: '', component: LoginComponent
  },
  {path: 'data', component: DataComponent},
  {
    path: 'name/:id', component: DataComponent
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LoginRoutingModule {
}
