import {Injectable} from '@angular/core';
import * as loki from 'lokijs';
import * as lokiIndexed from 'lokijs/src/loki-indexed-adapter.js';

@Injectable({
  providedIn: 'root'
})
export class RegistrService {

  public idbAdapter;
  public db;
  public collname;

  constructor() {
    this.idbAdapter = new lokiIndexed('register');
    this.db = new loki('data', {adapter: this.idbAdapter});
    this.collname = this.db.addCollection('users');
    // this.db.saveDatabase();
  }
}
