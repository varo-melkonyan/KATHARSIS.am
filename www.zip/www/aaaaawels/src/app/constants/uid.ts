export default function UID() {
    function s4() {
        return Math.floor((1 + Math.random()) * 0x10000000000000);
    }
    return s4();
}
