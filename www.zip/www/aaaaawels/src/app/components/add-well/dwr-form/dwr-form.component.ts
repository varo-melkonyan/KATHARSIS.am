import {Component, OnInit, OnDestroy} from '@angular/core';
import {FormArray, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {LoadingService} from '../../../services/loading.service';
import {WsService} from '../../../services/ws.service';
import {AddWellService} from '../add-well.service';
import {appConfig} from '../../../constants/app.config';
import {Router} from '@angular/router';
import {AlertService} from '../../../services/alert.service';
import {saveAs} from 'file-saver';
import {DbService} from '../../../services/db.service';
import {OnlineService} from '../../../services/online.service';
import {Subscription} from 'rxjs';
import {FormType, AccessLevel} from '../../../constants/app.enums';
import {DeleteDialogComponent} from '../../delete-dialog/delete-dialog.component';
import {MatDialog, MatSnackBar} from '@angular/material';
import {ISubscription} from 'rxjs-compat/Subscription';
import {LokiService} from '../../../services/loki.service';

@Component({
    selector: 'app-dwr-form',
    templateUrl: './dwr-form.component.html',
    styleUrls: ['./dwr-form.component.scss'],
})
export class DwrFormComponent implements OnInit, OnDestroy {
    public wellDataSub: Subscription;
    public deleteDWRSub: Subscription;
    public dbReady: Subscription;
    private dialogRefSub: Subscription;
    public dwrForm: FormGroup;
    public formType = FormType;
    public accessLevelEnum = AccessLevel;
    private insertDWRSub: any;
    private insertDwr: any;
    private addWellSub: any;
    private wellId: string;
    private week = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    private chargeArray = [
        'rigTime',
        'travel',
        'supervisor',
        'extraHand',
        'fracTank',
        'flowBackTank',
        'blowOutPreventer',
        'cementPump',
        'packer',
        'rodTongs',
        'tbgTongs',
        'tbgCutter',
        'workString',
        'cementBulkUnit',
        'rigH2SMonitor',
        'cement',
        'saltGel',
        'backhoe',
        'freshWater',
        'brineWater',
        'vacumTruck',
        'disposal',
        'tiw',
        'perforation',
        'wirelineSetUp',
        'pipeRackFloat',
        'wellHeadAdapt',
        'cibp',
        'wellheadCutoff',
        'scba'
    ];
    private isOnline: boolean;
    public totalrig: string;
    public totaltravel: string;
    public totaldown: string;
    public totalcomment: string;
    public total0: string;
    public total1: string;
    public total2: string;
    public total3: string;
    public total4: string;
    public totalAll: string;
    public userCrewman = [];
    public userCrewmanMap = {};
    public userOperator = [];
    public userOperatorMap = {};
    public accessLevel = appConfig.accessLevel;
    public successes = false;
    public mobileUser = appConfig.mobileUser;
    public chargeRecordTotal = null;
    public items: any;
    public wellData: any;
    public transferSub: any;
    public isDisableAddDelete = false;
    public filter: any;
    public submitted = 0;
    public autoSaveInterval: any;
    public getTransfer: any;
    public removeDwr: any;
    public getWells: any;
    public getWellsSub: any;
    public selectDWR: any;
    public selectDWRSub: any;

    constructor(private fb: FormBuilder,
                private svc: WsService,
                private addWellSvc: AddWellService,
                private router: Router,
                private dbSvc: DbService,
                private isOnlineSvc: OnlineService,
                private alertService: AlertService,
                public dialog: MatDialog,
                private snackBar: MatSnackBar,
                private loadingSvc: LoadingService,
                private lokiSvc: LokiService) {
        this.loadingSvc.endLoading();
        this.wellDataSub = this.addWellSvc.getSelectedWell().subscribe(wellData => {
            if (wellData) {
                this.wellData = wellData;
            }
        });

        this.addWellSub = this.addWellSvc.getEditItemName().subscribe(id => {
            if (id) {
                this.wellId = id.split(' ').join('/');
            }
        });

        this.isOnlineSvc.getIsOnline().subscribe(isOnline => {
            this.isOnline = isOnline;
        });
        this.dbReady = this.dbSvc.getDbReady().subscribe(ready => {
            if (ready) {
                this.getDwrs();
                this.dbSvc.openDatabase().then(() => {
                    this.dbSvc.getAll('users').then(
                        users => {
                            if (users && users[0]) {
                                const l = users.length;
                                for (let i = 0; i < l; i++) {
                                    this.userOperator.push(users[i]);
                                    this.userOperatorMap[users[i].id] = `${users[i].firstName} ${users[i].lastName}`;
                                    if (users[i].accessLevel === 3) {
                                        this.userCrewman.push(users[i]);
                                        this.userCrewmanMap[users[i].id] = `${users[i].firstName} ${users[i].lastName}`;
                                    }
                                }
                            }
                        },
                        error => {
                            console.log(error);
                        }
                    );
                });
            }
        });
        this.transferSub = this.lokiSvc.returnCallSub().subscribe(coll => {

            if (coll) {
                this.getTransfer = coll.by('name', 'setTransferForm');
                this.removeDwr = coll.by('name', 'removeDWR');
                this.insertDwr = coll.by('name', 'insertDWR');
                this.getWells = coll.by('name', 'getWell');
                this.selectDWR = coll.by('name', 'selectDWR');
            }
        });
    }

    ngOnInit() {
    }

    ngOnDestroy() {
        if (this.getWellsSub) {
            this.getWellsSub.unsubscribe();
        }
        if (this.selectDWRSub) {
            this.selectDWRSub.unsubscribe();
        }
        if (this.transferSub) {
            this.transferSub.unsubscribe();
        }
        if (this.autoSaveInterval) {
            clearInterval(this.autoSaveInterval);
        }
        if (this.insertDWRSub) {
            this.insertDWRSub.unsubscribe();
        }
        if (this.deleteDWRSub) {
            this.deleteDWRSub.unsubscribe();
        }
        if (this.dbReady) {
            this.dbReady.unsubscribe();
        }
        if (this.addWellSub) {
            this.addWellSub.unsubscribe();
        }
        if (this.wellDataSub) {
            this.wellDataSub.unsubscribe();
        }
        if (this.dialogRefSub) {
            this.dialogRefSub.unsubscribe();
        }
    }

    openDwr(dwr?) {
        this.dwrForm = null;
        this.initForm(dwr);
        this.calculateAllTotals();
    }

    initForm(dwr?) {
        if (this.autoSaveInterval) {
            clearInterval(this.autoSaveInterval);
        }

        this.isDisableAddDelete = !dwr;
        this.successes = (dwr && (dwr.supervisorSign || dwr.managerSign));
        this.dwrForm = this.fb.group({
            assigneeAccessLevel: dwr && (dwr.assigneeAccessLevel || dwr.assigneeAccessLevel === 0) ?
                dwr.assigneeAccessLevel : this.accessLevel,
            status: [dwr ? dwr.status : null],
            supervisorSign: dwr ? dwr.supervisorSign : null,
            managerSign: dwr ? dwr.managerSign : null,
            wellId: [this.wellId],
            id: [dwr ? dwr.id : null],
            date: [dwr ? new Date(dwr.date) : null],
            customerName: [{
                value: this.wellData ? this.wellData.customerName : '',
                disabled: true
            }],
            customerNumber: [{
                value: this.wellData ? this.wellData.customerNumber : null,
                disabled: true
            }],
            pluggersUnitNumber: [{
                value: this.wellData ? this.wellData.pluggersUnitNumber : null,
                disabled: true
            }],
            jobNumber: [{
                value: this.wellData ? this.wellData.jobNumber : null,
                disabled: true
            }],
            leaseWellNumber: [{
                value: this.wellData ? this.wellData.name : '',
                disabled: true
            }],
            api: [{
                value: this.wellData ? this.wellData.api : '',
                disabled: true
            }],
            countryState: [{
                value: this.wellData ? this.wellData.countryState : '',
                disabled: true
            }],
            field: [{
                value: this.wellData ? this.wellData.field : '',
                disabled: true
            }],
            legalDescriptionLease: [{
                value: this.wellData ? this.wellData.legalDescriptionLease : '',
                disabled: true
            }],
            workDescription: dwr ? this.createWorkDescription(dwr.workDescription) :
                this.fb.array([this.createWorkDescription()]),
            timeRecord: this.createTimeRecord(dwr ? dwr.timeRecord : false),
            timeRecordCustomFieldName: [dwr ? dwr.timeRecordCustomFieldName : ''],
            accidentReported: [dwr ? dwr.accidentReported : false],
            turnkey: [dwr ? dwr.turnkey : 0],
            rigTime: this.fb.group({
                code: [dwr ? dwr.rigTime.code : null],
                firstValue: [dwr && dwr.rigTime && dwr.rigTime.firstValue ? +dwr.rigTime.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.rigTime && dwr.rigTime.lastValue ? +dwr.rigTime.lastValue.toFixed(2) : null],
                price: [dwr && dwr.rigTime && dwr.rigTime.price ? +dwr.rigTime.price.toFixed(2) : null],
            }),
            travel: this.fb.group({
                code: [dwr ? dwr.travel.code : null],
                firstValue: [dwr && dwr.travel && dwr.travel.firstValue ? +dwr.travel.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.travel && dwr.travel.lastValue ? +dwr.travel.lastValue.toFixed(2) : null],
                price: [dwr && dwr.travel && dwr.travel.price ? +dwr.travel.price.toFixed(2) : null],
            }),
            supervisor: this.fb.group({
                code: [dwr ? dwr.supervisor.code : null],
                firstValue: [dwr && dwr.supervisor && dwr.supervisor.firstValue ? +dwr.supervisor.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.supervisor && dwr.supervisor.lastValue ? +dwr.supervisor.lastValue.toFixed(2) : null],
                price: [dwr && dwr.supervisor && dwr.supervisor.price ? +dwr.supervisor.price.toFixed(2) : null],
            }),
            extraHand: this.fb.group({
                code: [dwr ? dwr.extraHand.code : null],
                firstValue: [dwr && dwr.extraHand && dwr.extraHand.firstValue ? +dwr.extraHand.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.extraHand && dwr.extraHand.lastValue ? +dwr.extraHand.lastValue.toFixed(2) : null],
                price: [dwr && dwr.extraHand && dwr.extraHand.price ? +dwr.extraHand.price.toFixed(2) : null],
            }),
            fracTank: this.fb.group({
                code: [dwr ? dwr.fracTank.code : null],
                firstValue: [dwr && dwr.fracTank && dwr.fracTank.firstValue ? +dwr.fracTank.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.fracTank && dwr.fracTank.lastValue ? +dwr.fracTank.lastValue.toFixed(2) : null],
                price: [dwr && dwr.fracTank && dwr.fracTank.price ? +dwr.fracTank.price.toFixed(2) : null],
            }),
            flowBackTank: this.fb.group({
                code: [dwr ? dwr.flowBackTank.code : null],
                firstValue: [dwr && dwr.flowBackTank && dwr.flowBackTank.firstValue ? +dwr.flowBackTank.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.flowBackTank && dwr.flowBackTank.lastValue ? +dwr.flowBackTank.lastValue.toFixed(2) : null],
                price: [dwr && dwr.flowBackTank && dwr.flowBackTank.price ? +dwr.flowBackTank.price.toFixed(2) : null],
            }),
            blowOutPreventer: this.fb.group({
                code: [dwr ? dwr.blowOutPreventer.code : null],
                firstValue: [dwr && dwr.blowOutPreventer && dwr.blowOutPreventer.firstValue ?
                    +dwr.blowOutPreventer.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.blowOutPreventer && dwr.blowOutPreventer.lastValue ?
                    +dwr.blowOutPreventer.lastValue.toFixed(2) : null],
                price: [dwr && dwr.blowOutPreventer && dwr.blowOutPreventer.price ? +dwr.blowOutPreventer.price.toFixed(2) : null],
            }),
            cementPump: this.fb.group({
                code: [dwr ? dwr.cementPump.code : null],
                firstValue: [dwr && dwr.cementPump && dwr.cementPump.firstValue ? +dwr.cementPump.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.cementPump && dwr.cementPump.lastValue ? +dwr.cementPump.lastValue.toFixed(2) : null],
                price: [dwr && dwr.cementPump && dwr.cementPump.price ? +dwr.cementPump.price.toFixed(2) : null],
            }),
            packer: this.fb.group({
                code: [dwr ? dwr.packer.code : null],
                firstValue: [dwr && dwr.packer && dwr.packer.firstValue ? +dwr.packer.firstValue.toFixed(2) : null],
                secondValue: [dwr && dwr.packer && dwr.packer.secondValue ? +dwr.packer.secondValue : null],
                lastValue: [dwr && dwr.packer && dwr.packer.lastValue ? +dwr.packer.lastValue.toFixed(2) : null],
                price: [dwr && dwr.packer && dwr.packer.price ? +dwr.packer.price.toFixed(2) : null],
            }),
            rodTongs: this.fb.group({
                code: [dwr ? dwr.rodTongs.code : null],
                firstValue: [dwr && dwr.rodTongs && dwr.rodTongs.firstValue ? +dwr.rodTongs.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.rodTongs && dwr.rodTongs.lastValue ? +dwr.rodTongs.lastValue.toFixed(2) : null],
                price: [dwr && dwr.rodTongs && dwr.rodTongs.price ? +dwr.rodTongs.price.toFixed(2) : null],
            }),
            tbgTongs: this.fb.group({
                code: [dwr ? dwr.tbgTongs.code : null],
                firstValue: [dwr && dwr.tbgTongs && dwr.tbgTongs.firstValue ? +dwr.tbgTongs.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.tbgTongs && dwr.tbgTongs.lastValue ? +dwr.tbgTongs.lastValue.toFixed(2) : null],
                price: [dwr && dwr.tbgTongs && dwr.tbgTongs.price ? +dwr.tbgTongs.price.toFixed(2) : null],
            }),
            tbgCutter: this.fb.group({
                code: [dwr ? dwr.tbgCutter.code : null],
                firstValue: [dwr && dwr.tbgCutter && dwr.tbgCutter.firstValue ? +dwr.tbgCutter.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.tbgCutter && dwr.tbgCutter.lastValue ? +dwr.tbgCutter.lastValue.toFixed(2) : null],
                price: [dwr && dwr.tbgCutter && dwr.tbgCutter.price ? +dwr.tbgCutter.price.toFixed(2) : null],
            }),
            workString: this.fb.group({
                code: [dwr ? dwr.workString.code : null],
                firstValue: [dwr && dwr.workString && dwr.workString.firstValue ? +dwr.workString.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.workString && dwr.workString.lastValue ? +dwr.workString.lastValue.toFixed(2) : null],
                price: [dwr && dwr.workString && dwr.workString.price ? +dwr.workString.price.toFixed(2) : null],
            }),
            cementBulkUnit: this.fb.group({
                code: [dwr ? dwr.cementBulkUnit.code : null],
                firstValue: [dwr && dwr.cementBulkUnit && dwr.cementBulkUnit.firstValue ? +dwr.cementBulkUnit.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.cementBulkUnit && dwr.cementBulkUnit.lastValue ? +dwr.cementBulkUnit.lastValue.toFixed(2) : null],
                price: [dwr && dwr.cementBulkUnit && dwr.cementBulkUnit.price ? +dwr.cementBulkUnit.price.toFixed(2) : null],
            }),
            rigH2SMonitor: this.fb.group({
                code: [dwr ? dwr.rigH2SMonitor.code : null],
                firstValue: [dwr && dwr.rigH2SMonitor && dwr.rigH2SMonitor.firstValue ? +dwr.rigH2SMonitor.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.rigH2SMonitor && dwr.rigH2SMonitor.lastValue ? +dwr.rigH2SMonitor.lastValue.toFixed(2) : null],
                price: [dwr && dwr.rigH2SMonitor && dwr.rigH2SMonitor.price ? +dwr.rigH2SMonitor.price.toFixed(2) : null],
            }),
            cement: this.fb.group({
                code: [dwr ? dwr.cement.code : null],
                firstValue: [dwr && dwr.cement && dwr.cement.firstValue ? +dwr.cement.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.cement && dwr.cement.lastValue ? +dwr.cement.lastValue.toFixed(2) : null],
                price: [dwr && dwr.cement && dwr.cement.price ? +dwr.cement.price.toFixed(2) : null],
            }),
            saltGel: this.fb.group({
                code: [dwr ? dwr.saltGel.code : null],
                firstValue: [dwr && dwr.saltGel && dwr.saltGel.firstValue ? +dwr.saltGel.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.saltGel && dwr.saltGel.lastValue ? +dwr.saltGel.lastValue.toFixed(2) : null],
                price: [dwr && dwr.saltGel && dwr.saltGel.price ? +dwr.saltGel.price.toFixed(2) : null],
            }),
            backhoe: this.fb.group({
                code: [dwr ? dwr.backhoe.code : null],
                firstValue: [dwr && dwr.backhoe && dwr.backhoe.firstValue ? +dwr.backhoe.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.backhoe && dwr.backhoe.lastValue ? +dwr.backhoe.lastValue.toFixed(2) : null],
                price: [dwr && dwr.backhoe && dwr.backhoe.price ? +dwr.backhoe.price.toFixed(2) : null],
            }),
            freshWater: this.fb.group({
                code: [dwr ? dwr.freshWater.code : null],
                firstValue: [dwr && dwr.freshWater && dwr.freshWater.firstValue ? +dwr.freshWater.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.freshWater && dwr.freshWater.lastValue ? +dwr.freshWater.lastValue.toFixed(2) : null],
                price: [dwr && dwr.freshWater && dwr.freshWater.price ? +dwr.freshWater.price.toFixed(2) : null],
            }),
            brineWater: this.fb.group({
                code: [dwr ? dwr.brineWater.code : null],
                firstValue: [dwr && dwr.brineWater && dwr.brineWater.firstValue ? +dwr.brineWater.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.brineWater && dwr.brineWater.lastValue ? +dwr.brineWater.lastValue.toFixed(2) : null],
                price: [dwr && dwr.brineWater && dwr.brineWater.price ? +dwr.brineWater.price.toFixed(2) : null],
            }),
            vacumTruck: this.fb.group({
                code: [dwr ? dwr.vacumTruck.code : null],
                firstValue: [dwr && dwr.vacumTruck && dwr.vacumTruck.firstValue ? +dwr.vacumTruck.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.vacumTruck && dwr.vacumTruck.lastValue ? +dwr.vacumTruck.lastValue.toFixed(2) : null],
                price: [dwr && dwr.vacumTruck && dwr.vacumTruck.price ? +dwr.vacumTruck.price.toFixed(2) : null],
            }),
            disposal: this.fb.group({
                code: [dwr ? dwr.disposal.code : null],
                firstValue: [dwr && dwr.disposal && dwr.disposal.firstValue ? +dwr.disposal.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.disposal && dwr.disposal.lastValue ? +dwr.disposal.lastValue.toFixed(2) : null],
                price: [dwr && dwr.disposal && dwr.disposal.price ? +dwr.disposal.price.toFixed(2) : null],
            }),
            tiw: this.fb.group({
                code: [dwr && dwr.tiw ? dwr.tiw.code : null],
                firstValue: [dwr && dwr.tiw && dwr.tiw.firstValue ? +dwr.tiw.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.tiw && dwr.tiw.lastValue ? +dwr.tiw.lastValue.toFixed(2) : null],
                price: [dwr && dwr.tiw && dwr.tiw.price ? +dwr.tiw.price.toFixed(2) : null],
            }),
            perforation: this.fb.group({
                code: [dwr && dwr.perforation ? dwr.perforation.code : null],
                firstValue: [dwr && dwr.perforation && dwr.perforation.firstValue ? +dwr.perforation.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.perforation && dwr.perforation.lastValue ? +dwr.perforation.lastValue.toFixed(2) : null],
                price: [dwr && dwr.perforation && dwr.perforation.price ? +dwr.perforation.price.toFixed(2) : null],
            }),
            wirelineSetUp: this.fb.group({
                code: [dwr && dwr.wirelineSetUp ? dwr.wirelineSetUp.code : null],
                firstValue: [dwr && dwr.wirelineSetUp && dwr.wirelineSetUp.firstValue ? +dwr.wirelineSetUp.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.wirelineSetUp && dwr.wirelineSetUp.lastValue ? +dwr.wirelineSetUp.lastValue.toFixed(2) : null],
                price: [dwr && dwr.wirelineSetUp && dwr.wirelineSetUp.price ? +dwr.wirelineSetUp.price.toFixed(2) : null],
            }),
            pipeRackFloat: this.fb.group({
                code: [dwr && dwr.pipeRackFloat ? dwr.pipeRackFloat.code : null],
                firstValue: [dwr && dwr.pipeRackFloat && dwr.pipeRackFloat.firstValue ? +dwr.pipeRackFloat.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.pipeRackFloat && dwr.pipeRackFloat.lastValue ? +dwr.pipeRackFloat.lastValue.toFixed(2) : null],
                price: [dwr && dwr.pipeRackFloat && dwr.pipeRackFloat.price ? +dwr.pipeRackFloat.price.toFixed(2) : null],
            }),
            wellHeadAdapt: this.fb.group({
                code: [dwr && dwr.wellHeadAdapt ? dwr.wellHeadAdapt.code : null],
                firstValue: [dwr && dwr.wellHeadAdapt && dwr.wellHeadAdapt.firstValue ? +dwr.wellHeadAdapt.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.wellHeadAdapt && dwr.wellHeadAdapt.lastValue ? +dwr.wellHeadAdapt.lastValue.toFixed(2) : null],
                price: [dwr && dwr.wellHeadAdapt && dwr.wellHeadAdapt.price ? +dwr.wellHeadAdapt.price.toFixed(2) : null],
            }),
            cibp: this.fb.group({
                code: [dwr && dwr.cibp ? dwr.cibp.code : null],
                firstValue: [dwr && dwr.cibp && dwr.cibp.firstValue ? +dwr.cibp.firstValue.toFixed(2) : null],
                secondValue: [dwr && dwr.cibp && dwr.cibp.secondValue ? +dwr.cibp.secondValue : null],
                lastValue: [dwr && dwr.cibp && dwr.cibp.lastValue ? +dwr.cibp.lastValue.toFixed(2) : null],
                price: [dwr && dwr.cibp && dwr.cibp.price ? +dwr.cibp.price.toFixed(2) : null],
            }),
            wellheadCutoff: this.fb.group({
                code: [dwr && dwr.wellheadCutoff ? dwr.wellheadCutoff.code : null],
                firstValue: [dwr && dwr.wellheadCutoff && dwr.wellheadCutoff.firstValue ? +dwr.wellheadCutoff.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.wellheadCutoff && dwr.wellheadCutoff.lastValue ? +dwr.wellheadCutoff.lastValue.toFixed(2) : null],
                price: [dwr && dwr.wellheadCutoff && dwr.wellheadCutoff.price ? +dwr.wellheadCutoff.price.toFixed(2) : null],
            }),
            scba: this.fb.group({
                code: [dwr && dwr.scba ? dwr.scba.code : null],
                firstValue: [dwr && dwr.scba && dwr.scba.firstValue ? +dwr.scba.firstValue.toFixed(2) : null],
                lastValue: [dwr && dwr.scba && dwr.scba.lastValue ? +dwr.scba.lastValue.toFixed(2) : null],
                price: [dwr && dwr.scba && dwr.scba.price ? +dwr.scba.price.toFixed(2) : null],
            }),
            additionalChargeRecords: dwr && dwr.additionalChargeRecords ? this.additionalChargeRecordsInt(dwr.additionalChargeRecords) :
                this.fb.array([this.additionalChargeRecordsInt()]),
        });
        this.totalrig = '';
        this.calculateChargeRecord();
        if (this.accessLevel === this.f['assigneeAccessLevel'].value) {
            this.autoSaveInterval = setInterval(() => {
                this.onSubmit(0);
            }, 180000);
        }/* else {
            this.openSnackBar('Your autosave is not working because you do not have access to save', 'skip')
        }*/
    }

    openSnackBar(message: string, action: string) {
        this.snackBar.open(message, action);
    }

    calculateChargeRecord(field?, index?) {
        this.chargeRecordTotal = null;
        if (field) {
            const firstValue = this.dwrForm.get(field).get('firstValue');
            const lastValue = this.dwrForm.get(field).get('lastValue');
            const price = this.dwrForm.get(field).get('price');
            if ((firstValue.value || firstValue.value === 0) && (lastValue.value || lastValue.value === 0)) {
                price.setValue(firstValue.value * lastValue.value);
            } else {
                price.setValue(null);
            }
        }
        if (!field && !isNaN(index) && index !== null) {
            const firstValue = this.dwrForm.get('additionalChargeRecords')['controls'][index].get('firstValue');
            const lastValue = this.dwrForm.get('additionalChargeRecords')['controls'][index].get('lastValue');
            const price = this.dwrForm.get('additionalChargeRecords')['controls'][index].get('price');
            if ((firstValue.value || firstValue.value === 0) && (lastValue.value || lastValue.value === 0)) {
                price.setValue(firstValue.value * lastValue.value);
            } else {
                price.setValue(null);
            }
        }
        let l = this.chargeArray.length;
        for (let i = 0; i < l; i++) {
            const lPrice = this.dwrForm.get(this.chargeArray[i]).get('price');
            if (lPrice) {
                this.chargeRecordTotal += lPrice.value;
            }
        }
        l = this.f.additionalChargeRecords['controls'].length;
        for (let i = 0; i < l; i++) {
            const lPrice = this.f.additionalChargeRecords['controls'][i].get('price');
            if (lPrice) {
                this.chargeRecordTotal += lPrice.value;
            }
        }
    }

    additionalChargeRecordsInt(array?) {
        if (array) {
            const l = array.length;
            const arr = this.fb.array([]);
            for (let i = 0; i < l; i++) {
                arr.push(this.fb.group({
                    code: [array[i].code],
                    name: [array[i].name],
                    firstValue: [array[i].firstValue !== null ? +array[i].firstValue.toFixed(2) : null],
                    lastValue: [array[i].lastValue !== null ? +array[i].lastValue.toFixed(2) : null],
                    price: [array[i].price !== null ? +array[i].price.toFixed(2) : null],
                }));
            }
            return arr;
        } else {
            return this.fb.group({
                code: [null],
                name: [''],
                firstValue: [null],
                lastValue: [null],
                price: [null]
            });
        }
    }

    addAdditionalChargeRecords() {
        const additionalChargeRecords = this.formData(this.dwrForm.get('additionalChargeRecords'));
        additionalChargeRecords.push(this.additionalChargeRecordsInt());
    }

    deleteAdditionalChargeRecords(index) {
        const additionalChargeRecords = this.formData(this.dwrForm.get('additionalChargeRecords'));
        additionalChargeRecords.removeAt(index);
        this.calculateChargeRecord();
    }


    createWorkDescription(array?) {
        if (array) {
            const l = array.length;
            const arr = this.fb.array([]);
            for (let i = 0; i < l; i++) {
                arr.push(this.fb.group({
                    from: [[new Date(array[i].from).getHours(), new Date(array[i].from).getMinutes()], Validators.required],
                    to: [[new Date(array[i].to).getHours(), new Date(array[i].to).getMinutes()], Validators.required],
                    text: [array[i].text, Validators.required]
                }));
            }
            return arr;
        } else {
            if (this.dwrForm && this.dwrForm.value.workDescription[0]) {
                const l = this.dwrForm.value.workDescription.length;
                const lastElem = this.dwrForm.value.workDescription[l - 1];
                return this.fb.group({
                    from: [lastElem.to.split(':'), Validators.required],
                    to: [[], Validators.required],
                    text: ['', Validators.required]
                });
            } else {
                return this.fb.group({
                    from: [[8, 0], Validators.required],
                    to: [[8, 30], Validators.required],
                    text: ['', Validators.required]
                });
            }
        }
    }

    createTimeRecord(array?) {
        const arr = this.fb.array([]);
        if (array) {
            const l = array.length;
            for (let i = 0; i < l; i++) {
                arr.push(this.fb.group({
                    employee: [array[i].employee],
                    employeeSignature: [array[i].employeeSignature],
                    employeeName: [array[i].employeeName],
                    start: [array[i].start],
                    stop: [array[i].stop],
                    rig: [array[i].rig],
                    travel: [array[i].travel],
                    down: [array[i].down],
                    comment: [array[i].comment],
                    total: ['']
                }));

            }
        } else {
            const defArray = ['Operator', 'Crewman', 'Crewman', 'Crewman', 'Other'];
            const l = defArray.length;
            for (let i = 0; i < l; i++) {
                arr.push(this.fb.group({
                    employee: [defArray[i]],
                    employeeSignature: [''],
                    employeeName: [''],
                    start: [''],
                    stop: [''],
                    rig: [''],
                    travel: [''],
                    down: [''],
                    comment: [''],
                    total: ['']
                }));
            }
        }
        return arr;
    }

    calculateAllTotals() {
        const l = this.dwrForm.get('timeRecord').value.length;
        const item = this.dwrForm.get('timeRecord').value;
        let totalColRig = 0;
        let totalColTravel = 0;
        let totalColDown = 0;
        let totalColComment = 0;
        for (let i = 0; i < l; i++) {
            this.calcTotalLine(i, (item[i].rig ? this.convertMinutes(item[i].rig) : 0) +
                (item[i].travel ? this.convertMinutes(item[i].travel) : 0) +
                (item[i].down ? this.convertMinutes(item[i].down) : 0) +
                (item[i].comment ? this.convertMinutes(item[i].comment) : 0));
            if (item[i]['rig']) {
                totalColRig += this.convertMinutes(item[i]['rig']);
            }
            if (item[i]['travel']) {
                totalColTravel += this.convertMinutes(item[i]['travel']);
            }
            if (item[i]['down']) {
                totalColDown += this.convertMinutes(item[i]['down']);
            }
            if (item[i]['comment']) {
                totalColComment += this.convertMinutes(item[i]['comment']);
            }
        }
        this.calcTotalLine('rig', totalColRig);
        this.calcTotalLine('travel', totalColTravel);
        this.calcTotalLine('down', totalColDown);
        this.calcTotalLine('comment', totalColComment);
        this.allTotalFn();
    }

    calcTotalLine(item, value) {
        this[`total${item}`] = `${Math.floor(+value / 60) >= 10 ? Math.floor(+value / 60) :
            '0' + Math.floor(+value / 60)}:${+value % 60 >= 10 ? +value % 60 : '0' + (+value % 60)}`;
    }

    convertFromTo(time) {
        const timeArray = time.split(':');
        return (+timeArray[0] > 0 ? +timeArray[0] * 60 * 60 * 1000 : 0) + ((+timeArray[1] > 0) ? +timeArray[1] * 60 * 1000 : 0);
    }

    setValueFromTo() {
        const l = this.dwrForm.value['workDescription'].length;
        const date = +this.dwrForm.value.date;
        const array = this.dwrForm.value['workDescription'];
        for (let i = 0; i < l; i++) {
            array[i].from = (typeof array[i].from === 'string' || typeof array[i].from === 'object') ?
                date + this.convertFromTo(array[i].from) : array[i].from;
            array[i].to = (typeof array[i].to === 'string' || typeof array[i].to === 'object') ?
                date + this.convertFromTo(array[i].to) : array[i].to;
        }
    }

    setTimePickerValue(value, form) {
        form.setValue(value);
    }

    checkTime(isFirst, from, to) {
        if (from && to && (typeof from.value === 'string' && typeof to.value === 'string')) {
            const intFrom = from.value.split(':');
            const intTo = to.value.split(':');
            if (((+intFrom[0]) + (+intTo[1])) > ((+intTo[0]) + (+intTo[1]))) {
                if (isFirst) {
                    to.setValue('');
                } else {
                    from.setValue('');
                }
            }
        }
    }

    addItem() {
        const workDescription = this.formData(this.dwrForm.get('workDescription'));
        workDescription.push(this.createWorkDescription());
    }

    deleteItem(index) {
        const workDescription = this.formData(this.dwrForm.get('workDescription'));
        workDescription.removeAt(index);
    }

    calcTotal(index, item) {
        setTimeout(() => {
            const l = this.dwrForm.value.timeRecord.length;
            const elems = this.dwrForm.value.timeRecord;
            let totalCol = 0;
            for (let i = 0; i < l; i++) {
                if (elems[i][item]) {
                    totalCol += this.convertMinutes(elems[i][item]);
                }
            }
            this.calcTotalLine(item, totalCol);
            this.calcTotalLine(index, (elems[index].rig ? +this.convertMinutes(elems[index].rig) : 0) +
                (elems[index].travel ? +this.convertMinutes(elems[index].travel) : 0) +
                (elems[index].down ? +this.convertMinutes(elems[index].down) : 0) +
                (elems[index].comment ? +this.convertMinutes(elems[index].comment) : 0));
            this.allTotalFn();
        }, 100);
    }

    allTotalFn() {
        const totalrig = this.totalrig ? this.convertMinutes(this.totalrig) : 0;
        const totaltravel = this.totaltravel ? this.convertMinutes(this.totaltravel) : 0;
        const totaldown = this.totaldown ? this.convertMinutes(this.totaldown) : 0;
        const totalcomment = this.totalcomment ? this.convertMinutes(this.totalcomment) : 0;
        const total = +totalrig + +totaltravel + +totaldown + +totalcomment;
        this.calcTotalLine('All', total);
    }

    convertMinutes(time) {
        const timeArray = time.split(':');
        return (+timeArray[0] > 0 ? +timeArray[0] * 60 : 0) + (+timeArray[1]);
    }

    formData(arr) {
        return <FormArray>arr;
    }

    get f() {
        return this.dwrForm.controls;
    }

    markFormGroupTouched(formGroup: FormGroup) {
        (<any>Object).values(formGroup.controls).forEach(control => {
            control.markAsTouched();

            if (control.controls) {
                this.markFormGroupTouched(control);
            }
        });
    }

    getDwrs() {
        this.dbSvc.openDatabase().then(() => {
            this.dbSvc.getAllByIndexAndValue('dwr', 'wellId', this.wellId).then(
                dwrs => {
                    if (dwrs) {
                        this.items = dwrs;
                        this.filter = (d: Date) => {
                            const f = +new Date(d);
                            const l = this.items.length;
                            const r = [];
                            for (let i = 0; i < l; i++) {
                                r.push(+new Date(this.items[i].date));
                            }
                            return r.toString().indexOf(`${f}`) === -1;
                        };
                    }
                },
                error => {
                }
            );
        });
    }

    success(message: string) {
        this.alertService.success(message);
    }

    error(message: string) {
        this.alertService.error(message);
    }

    tableToExcel(name) {
        const workDescriptionL = this.dwrForm.value.workDescription.length;
        const workDescriptionElems = this.dwrForm.value.workDescription;
        let workDescription = '';
        for (let i = 0; i < workDescriptionL; i++) {
            /*const fromTime = this.convertFromTo(workDescriptionElems[i].from)
            const fromHour = new Date(fromTime).getHours();
            const fromMin = new Date(fromTime).getMinutes();
            workDescriptionElems[i].from = fromHour > 12 ? (fromHour - 12) : fromHour + ':' + fromMin + ((fromHour > 12) || (fromHour === 12 && fromMin > 0) ? 'PM' : 'AM');
            const toTime = this.convertFromTo(workDescriptionElems[i].to)
            const toHour = new Date(toTime).getHours();
            const toMin = new Date(toTime).getMinutes();
            workDescriptionElems[i].to = toHour > 12 ? (toHour - 12) : toHour + ':' + toMin + ((toHour > 12) || (toHour === 12 && toMin > 0) ? 'PM' : 'AM');*/
            if (typeof workDescriptionElems[i].from === 'number') {
                const hour = new Date(workDescriptionElems[i].from).getHours();
                const min = new Date(workDescriptionElems[i].from).getMinutes();
                workDescriptionElems[i].from = hour > 12 ? (hour - 12) : hour + ':' + min + ((hour > 12) || (hour === 12 && min > 0) ? 'PM' : 'AM');
            }
            if (typeof workDescriptionElems[i].to === 'number') {
                const hour = new Date(workDescriptionElems[i].to).getHours();
                const min = new Date(workDescriptionElems[i].to).getMinutes();
                workDescriptionElems[i].to = hour > 12 ? (hour - 12) : hour + ':' + min + ((hour > 12) || (hour === 12 && min > 0) ? 'PM' : 'AM');
            }
            let from = workDescriptionElems[i].from.split(':');
            from = `${('0' + (from[0])).slice(-2)}:${('0' + (from[1])).slice(-2)}`;
            let to = workDescriptionElems[i].to.split(':');
            to = `${('0' + (to[0])).slice(-2)}:${('0' + (to[1])).slice(-2)}`;
            workDescriptionElems[i].from = from;
            workDescriptionElems[i].to = to;
            workDescription += `
                    <tr>
                        <td colspan="2" class="cell1">${workDescriptionElems[i] ? workDescriptionElems[i].from : ''}</td>
                        <td colspan="2" class="cell1">${workDescriptionElems[i] ? workDescriptionElems[i].to : ''}</td>
                        <td colspan="12" style="border: 1px solid black; text-align:center;">${workDescriptionElems[i] ?
                workDescriptionElems[i].text : ''}</td>
                    </tr>`;
        }
        const template = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"
      xmlns="http://www.w3.org/TR/REC-html40">
        <head>
            <xml>
                <x:ExcelWorkbook>
                    <x:ExcelWorksheets>
                        <x:ExcelWorksheet>
                            <x:WorksheetOptions>
                                <x:FitToPage/>
                                 <x:DoNotDisplayGridlines/>
                                 <x:Print>
                                    <x:FitHeight>0</x:FitHeight>
                                    <x:ValidPrinterInfo/>
                                    <x:PaperSizeIndex>9</x:PaperSizeIndex>
                                    <x:Scale>56</x:Scale>
                                    <x:HorizontalResolution>600</x:HorizontalResolution>
                                    <x:VerticalResolution>600</x:VerticalResolution>
                                </x:Print>
                                <x:Zoom>130</x:Zoom>
                            </x:WorksheetOptions>
                        </x:ExcelWorksheet>
                    </x:ExcelWorksheets>
                </x:ExcelWorkbook>
            </xml>
            <title>DWR</title>
            <meta http-equiv="content-type" content="text/plain; charset=UTF-8"/>
            <style>
                body {
                    font-family: arial;
                    font-weight: normal;
                    font-size: 12px;
                }
                table {
                    font-family: arial;
                    font-weight: normal;
                    font-size: 12px;
                }
        
                .title {
                    font-size: 36px;
                    font-family: arial;
                }
        
                .title1 {
                    font-family: arial;
                    font-weight: normal;
                    font-size: 16px;
                    vertical-align: middle;
                    text-align: left;
                }
        
                .title2 {
                    font-family: arial;
                    font-weight: normal;
                    font-size: 12px;
                    text-align: right;
                }
        
                .td-brd {
                    border: 1px solid black;
                    text-align: left;
                    font-family: arial;
                    font-weight: normal;
                    font-size: 12px;
                }
        
                .bold {
                    font-weight: bold;
                }
        
                .center {
                    text-align: center;
                }
        
                .cell {
                    font-family: arial;
                    font-size: 12px;
                    font-weight: normal;
                    border: 1px solid black;
        
                }
        
                .cell1 {
                    font-weight: bold;
                    text-align: center;
                    border: 1px solid black;
                    font-family: arial;
                    font-size: 12px;
                }
            </style>
        </head>
        <body>
        <table style="width:950px">
            <col width="23">
            <col width="49">
            <col width="23">
            <col width="105">
            <col width="65">
            <col width="75">
            <col width="95">
            <col width="25">
            <col width="45">
            <col width="65">
            <col width="65">
            <col width="65">
            <col width="23">
            <col width="80">
            <col width="90">
            <col width="80">
            <thead>
            <tr>
                <th colspan="4" class="title1">
                    <br/>
                    Plugger's
                    <br/>
                    Daily Work Record
                </th>
                <th colspan="10" class="title">JMR Services</th>
                <th colspan="2" class="title2">
                    JMR Services, LLC
                    <br/>
                    P.O. Box 80730
                    <br/>
                    Midland, TX 79708
                    <br/>
                    (432)580-7280 office
                    <br/>
                    (432)580-7275 fax
                </th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td colspan="4" class="td-brd">
                    <span style="text-align:center;  font-weight:bold;">Customer Name</span>
                    <br/>
                    ${this.dwrForm.get('customerName').value}
                </td>
                <td colspan="2" class="td-brd">
                    <span style="font-weight:bold;">Customer No.</span>
                    <br/>
                    ${this.dwrForm.get('customerNumber').value !== null ? this.dwrForm.get('customerNumber').value : ''}
                </td>
                <td colspan="3" class="td-brd">
                    <span style="font-weight:bold;">Date</span>
                    <br/>
                    ${('0' + (new Date(this.dwrForm.value.date).getMonth() + 1)).slice(-2)}/${new Date(this.dwrForm.value.date).getDate()}/${new Date(this.dwrForm.value.date).getFullYear()}
                </td>
                <td colspan="2" class="td-brd">
                    <span style="font-weight:bold;">Day of Week</span>
                    <br/>
                    ${this.week[new Date(this.dwrForm.value.date).getDay()]}
                </td>
                <td colspan="3" class="td-brd">
                    <span style="font-weight:bold;">Plugger's Unit No.</span>
                    <br/>
                    ${this.dwrForm.get('pluggersUnitNumber').value !== null ? this.dwrForm.get('pluggersUnitNumber').value : ''}
                </td>
                <td colspan="2" style="border: 1px solid black; text-align:left; ">
                    <span style="font-weight:bold;">Job No.</span>
                    <br/>
                    ${this.dwrForm.get('jobNumber').value !== null ? this.dwrForm.get('jobNumber').value : ''}
                </td>
            </tr>
            <tr>
                <td colspan="9" class="td-brd">
                    <span style="font-weight:bold;">Lease and Well No.</span>
                    <br/>
                    ${this.dwrForm.get('leaseWellNumber').value}
                </td>
                <td colspan="7" class="td-brd">
                    <span style="font-weight:bold;">API</span>
                    <br/>
                    ${this.dwrForm.get('api').value}
                </td>
            </tr>
            <tr>
                <td colspan="5" class="td-brd">
                    <span style="font-weight:bold;">County/State</span>
                    <br/>
                    ${this.dwrForm.get('countryState').value}
                </td>
                <td colspan="4" class="td-brd">
                    <span style="font-weight:bold;">Field</span>
                    <br/>
                    ${this.dwrForm.get('field').value}
                </td>
                <td colspan="7" class="td-brd">
                    <span style="font-weight:bold;">Legal Description of Lease</span>
                    <br/>
                    ${this.dwrForm.get('legalDescriptionLease').value}
                </td>
            </tr>
            <tr>
                <td colspan="16"/>
            </tr>
        
            <tr>
                <td colspan="2" class="cell1">From</td>
                <td colspan="2" class="cell1">To</td>
                <td colspan="12" class="cell1">Describe Work to 1/2 - Separate
                    Each Operation
                </td>
            </tr>
            ${workDescription}
            <tr>
                <td colspan="16"/>
            </tr>
        
            <tr>
                <td style="border: 1px solid black; text-align: center; vertical-align: middle;">${this.dwrForm.value.accidentReported ? 'X' : ''}</td>
                <td colspan="15">
                    <span style="font-weight: bold;">No Accident Reported</span>
                </td>
            </tr>
            <tr>
                <td colspan="16"/>
            </tr>
            <tr>
                <td colspan="16" style=" border-top: 1px solid black; border-right: 1px solid black;"/>
            </tr>
            <tr>
                <td colspan="2"></td>
                <td style="border: 1px solid black; text-align: center; vertical-align: middle;" >${this.dwrForm.value.turnkey === 0 ? 'X' : ''}</td>
                <td colspan="4" style="font-size: 12px; font-weight: bold;"> On-Turnkey</td>
                <td style="border: 1px solid black; text-align: center; vertical-align: middle;">${this.dwrForm.value.turnkey === 1 ? 'X' : ''}</td>
                <td colspan="4" style="font-size: 12px; font-weight: bold; "> On-Turnkey with Additional Charges
                </td>
                <td style="border: 1px solid black; text-align: center; vertical-align: middle;">${this.dwrForm.value.turnkey === 2 ? 'X' : ''}</td>
                <td colspan="3" style="font-size: 12px; font-weight: bold;  border-right: 1px solid black;">Off-Turnkey</td>
            </tr>
            <tr>
                <td colspan="16" style="border-bottom: 1px solid black; border-right: 1px solid black;"/>
            </tr>
            <tr>
                <td rowspan="7" style="border-right:1px solid black; font-weight:bold; font-size:14px; word-break:break-all;">
                    CHARGE
                </td>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.rigTime.code !== null ? this.dwrForm.value.rigTime.code : ''} </td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Rig Time</td>
                <td style="text-align:right;  border-bottom: 1px solid black;">${this.dwrForm.value.rigTime.firstValue !== null ? this.dwrForm.value.rigTime.firstValue : ''} $</td>
                <td style="text-align:right; border-right: 1px solid black;  border-bottom: 1px solid black;">
                    ${this.dwrForm.value.rigTime.lastValue !== null ? this.dwrForm.value.rigTime.lastValue : ''} HRS
                </td>
                <td colspan="2" style="text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.rigTime.price !== null ? this.dwrForm.value.rigTime.price : ''} $</td>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.cement.code !== null ? this.dwrForm.value.cement.code : ''}</td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Cement @</td>
                <td style="text-align:right;  border-bottom: 1px solid black;">${this.dwrForm.value.cement.firstValue !== null ? this.dwrForm.value.cement.firstValue : ''} $</td>
                <td style="text-align:right;  border-right: 1px solid black; border-bottom: 1px solid black;">
                    ${this.dwrForm.value.cement.lastValue !== null ? this.dwrForm.value.cement.lastValue : ''} SACKS
                </td>
                <td style=" border-right: 1px solid black; text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.cement.price !== null ? this.dwrForm.value.cement.price : ''} $</td>
            </tr>
            <tr>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.travel.code !== null ? this.dwrForm.value.travel.code : ''}</td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Travel @</td>
                <td style="text-align:right;  border-bottom: 1px solid black;">${this.dwrForm.value.travel.firstValue !== null ? this.dwrForm.value.travel.firstValue : ''} $</td>
                <td style="text-align:right; border-right: 1px solid black;  border-bottom: 1px solid black;">
                    ${this.dwrForm.value.travel.lastValue !== null ? this.dwrForm.value.travel.lastValue : ''} HRS
                </td>
                <td colspan="2" style="text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.travel.price !== null ? this.dwrForm.value.travel.price : ''}  $</td>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.saltGel.code !== null ? this.dwrForm.value.saltGel.code : ''} </td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Salt Gel @</td>
                <td style="text-align:right;  border-bottom: 1px solid black;">${this.dwrForm.value.saltGel.firstValue !== null ? this.dwrForm.value.saltGel.firstValue : ''} $</td>
                <td style="text-align:right;  border-right: 1px solid black; border-bottom: 1px solid black;">
                    ${this.dwrForm.value.saltGel.lastValue !== null ? this.dwrForm.value.saltGel.lastValue : ''} SACKS
                </td>
                <td style=" border-right: 1px solid black; text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.saltGel.price !== null ? this.dwrForm.value.saltGel.price : ''}  $</td>
            </tr>
            <tr>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.supervisor.code !== null ? this.dwrForm.value.supervisor.code : ''}</td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Supervisor @</td>
                <td style="text-align:right;  border-bottom: 1px solid black;">${this.dwrForm.value.supervisor.firstValue !== null ? this.dwrForm.value.supervisor.firstValue : ''} $</td>
                <td style="text-align:right; border-right: 1px solid black;  border-bottom: 1px solid black;">
                    ${this.dwrForm.value.supervisor.lastValue !== null ? this.dwrForm.value.supervisor.lastValue : ''}  DAY
                </td>
                <td colspan="2" style="text-align:right; border-bottom: 1px solid black;"> ${this.dwrForm.value.supervisor.price !== null ? this.dwrForm.value.supervisor.price : ''} $</td>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.backhoe.code !== null ? this.dwrForm.value.backhoe.code : ''} </td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Backhoe</td>
                <td style="text-align:right;   border-bottom: 1px solid black;">${this.dwrForm.value.backhoe.firstValue !== null ? this.dwrForm.value.backhoe.firstValue : ''} $</td>
                <td style="text-align:right; border-right: 1px solid black; border-bottom: 1px solid black;">
                    ${this.dwrForm.value.backhoe.lastValue !== null ? this.dwrForm.value.backhoe.lastValue : ''} HRS
                </td>
                <td style=" border-right: 1px solid black; text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.backhoe.price !== null ? this.dwrForm.value.backhoe.price : ''}  $</td>
            </tr>
            <tr>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.extraHand.code !== null ? this.dwrForm.value.extraHand.code : ''}</td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Extra Hand @</td>
                <td style="text-align:right;  border-bottom: 1px solid black;">${this.dwrForm.value.extraHand.firstValue !== null ? this.dwrForm.value.extraHand.firstValue : ''} $</td>
                <td style="text-align:right; border-right: 1px solid black;  border-bottom: 1px solid black;">
                    ${this.dwrForm.value.extraHand.lastValue !== null ? this.dwrForm.value.extraHand.lastValue : ''} HRS
                </td>
                <td colspan="2" style="text-align:right; border-bottom: 1px solid black;"> ${this.dwrForm.value.extraHand.price !== null ? this.dwrForm.value.extraHand.price : ''} $</td>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.freshWater.code !== null ? this.dwrForm.value.freshWater.code : ''} </td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Fresh Water @</td>
                <td style="text-align:right;  border-bottom: 1px solid black;">${this.dwrForm.value.freshWater.firstValue !== null ? this.dwrForm.value.freshWater.firstValue : ''} $</td>
                <td style="text-align:right;  border-right: 1px solid black; border-bottom: 1px solid black;">
                    ${this.dwrForm.value.freshWater.lastValue !== null ? this.dwrForm.value.freshWater.lastValue : ''} BBL
                </td>
                <td style=" border-right: 1px solid black; text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.freshWater.price !== null ? this.dwrForm.value.freshWater.price : ''} $</td>
            </tr>
            <tr>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.fracTank.code !== null ? this.dwrForm.value.fracTank.code : ''}</td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Frac Tank</td>
                <td style="text-align:right;  border-bottom: 1px solid black;">${this.dwrForm.value.fracTank.firstValue !== null ? this.dwrForm.value.fracTank.firstValue : ''} $</td>
                <td style="text-align:right; border-right: 1px solid black;  border-bottom: 1px solid black;">
                    ${this.dwrForm.value.fracTank.lastValue !== null ? this.dwrForm.value.fracTank.lastValue : ''} DAY
                </td>
                <td colspan="2" style="text-align:right; border-bottom: 1px solid black;"> ${this.dwrForm.value.fracTank.price !== null ? this.dwrForm.value.fracTank.price : ''} $</td>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.brineWater.code !== null ? this.dwrForm.value.brineWater.code : ''} </td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Brine Water @</td>
                <td style="text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.brineWater.firstValue !== null ? this.dwrForm.value.brineWater.firstValue : ''} $</td>
                <td style="text-align:right; border-right: 1px solid black; border-bottom: 1px solid black;">
                    ${this.dwrForm.value.brineWater.lastValue !== null ? this.dwrForm.value.brineWater.lastValue : ''} BBL
                </td>
                <td style=" border-right: 1px solid black; text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.brineWater.price !== null ? this.dwrForm.value.brineWater.price : ''} $</td>
            </tr>
        
            <tr>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.flowBackTank.code !== null ? this.dwrForm.value.flowBackTank.code : ''}</td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Flow Back Tank</td>
                <td style="text-align:right;  border-bottom: 1px solid black;">${this.dwrForm.value.flowBackTank.firstValue !== null ? this.dwrForm.value.flowBackTank.firstValue : ''} $</td>
                <td style="text-align:right; border-right: 1px solid black;  border-bottom: 1px solid black;">
                    ${this.dwrForm.value.flowBackTank.lastValue !== null ? this.dwrForm.value.flowBackTank.lastValue : ''} DAY
                </td>
                <td colspan="2" style="text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.flowBackTank.price !== null ? this.dwrForm.value.flowBackTank.price : ''} $</td>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.vacumTruck.code !== null ? this.dwrForm.value.vacumTruck.code : ''}</td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Vacuum Truck</td>
                <td style="text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.vacumTruck.firstValue !== null ? this.dwrForm.value.vacumTruck.firstValue : ''} $</td>
                <td style="text-align:right;  border-right: 1px solid black; border-bottom: 1px solid black;">
                    ${this.dwrForm.value.vacumTruck.lastValue !== null ? this.dwrForm.value.vacumTruck.lastValue : ''} HRS
                </td>
                <td style="border-right: 1px solid black; text-align:right; border-bottom: 1px solid black;"> ${this.dwrForm.value.vacumTruck.price !== null ? this.dwrForm.value.vacumTruck.price : ''}  $</td>
            </tr>
        
            <tr>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.blowOutPreventer.code !== null ? this.dwrForm.value.blowOutPreventer.code : ''} </td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Blow Out Preventer</td>
                <td style="text-align:right;  border-bottom: 1px solid black;">${this.dwrForm.value.blowOutPreventer.firstValue !== null ? this.dwrForm.value.blowOutPreventer.firstValue : ''} $</td>
                <td style="text-align:right; border-right: 1px solid black;  border-bottom: 1px solid black;">
                    ${this.dwrForm.value.blowOutPreventer.lastValue !== null ? this.dwrForm.value.blowOutPreventer.lastValue : ''} DAY
                </td>
                <td colspan="2" style="text-align:right; border-bottom: 1px solid black;">  ${this.dwrForm.value.blowOutPreventer.price !== null ? this.dwrForm.value.blowOutPreventer.price : ''} $</td>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.disposal.code !== null ? this.dwrForm.value.disposal.code : ''} </td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Disposal @</td>
                <td style="text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.disposal.firstValue !== null ? this.dwrForm.value.disposal.firstValue : ''} $</td>
                <td style="text-align:right; border-right: 1px solid black; border-bottom: 1px solid black;">
                    ${this.dwrForm.value.disposal.lastValue !== null ? this.dwrForm.value.disposal.lastValue : ''} BBL
                </td>
                <td style="border-right: 1px solid black; text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.disposal.price !== null ? this.dwrForm.value.disposal.price : ''} $</td>
            </tr>
        
            <tr>
                <td rowspan="8"
                    style="border-right:1px solid black; font-weight: bold; font-size: 14px; word-break:break-all;  border-bottom: 1px solid black;">
                    RECORD
                </td>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.cementPump.code !== null ? this.dwrForm.value.cementPump.code : ''} </td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Cement Pump @</td>
                <td style="text-align:right;  border-bottom: 1px solid black;">${this.dwrForm.value.cementPump.firstValue !== null ? this.dwrForm.value.cementPump.firstValue : ''} $</td>
                <td style="text-align:right; border-right: 1px solid black;  border-bottom: 1px solid black;">
                    ${this.dwrForm.value.cementPump.lastValue !== null ? this.dwrForm.value.cementPump.lastValue : ''} HRS
                </td>
                <td colspan="2" style="text-align:right; border-bottom: 1px solid black;"> ${this.dwrForm.value.cementPump.price !== null ? this.dwrForm.value.cementPump.price : ''} $</td>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.tiw.code !== null ? this.dwrForm.value.tiw.code : ''} </td>
                <td colspan="3" style=" border-bottom: 1px solid black;">TIW</td>
                <td style="text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.tiw.firstValue !== null ? this.dwrForm.value.tiw.firstValue : ''} $</td>
                <td style="text-align:right; border-right: 1px solid black; border-bottom: 1px solid black;">
                    ${this.dwrForm.value.tiw.lastValue !== null ? this.dwrForm.value.tiw.lastValue : ''} DAY
                </td>
                <td style="border-right: 1px solid black; text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.tiw.price !== null ? this.dwrForm.value.tiw.price : ''}  $</td>
            </tr>
        
            <tr>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.packer.code !== null ? this.dwrForm.value.packer.code : ''}</td>
                <td colspan="2" style=" border-bottom: 1px solid black;">Packer</td>
                <td style=" border: 1px solid black;">${this.dwrForm.value.packer.secondValue !== null ? this.dwrForm.value.packer.secondValue : ''}</td>
                <td style="text-align:right;  border-bottom: 1px solid black;">${this.dwrForm.value.packer.firstValue !== null ? this.dwrForm.value.packer.firstValue : ''} $</td>
                <td style="text-align:right; border-right: 1px solid black;  border-bottom: 1px solid black;">
                    ${this.dwrForm.value.packer.lastValue !== null ? this.dwrForm.value.packer.lastValue : ''}  DAY
                </td>
                <td colspan="2" style="text-align:right; border-bottom: 1px solid black;"> ${this.dwrForm.value.packer.price !== null ? this.dwrForm.value.packer.price : ''} $</td>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.perforation.code !== null ? this.dwrForm.value.perforation.code : ''} </td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Perforation</td>
                <td style="text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.perforation.firstValue !== null ? this.dwrForm.value.perforation.firstValue : ''} $</td>
                <td style="text-align:right; border-right: 1px solid black; border-bottom: 1px solid black;">
                    ${this.dwrForm.value.perforation.lastValue !== null ? this.dwrForm.value.perforation.lastValue : ''} RUN
                </td>
                <td style="border-right: 1px solid black; text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.perforation.price !== null ? this.dwrForm.value.perforation.price : ''}  $</td>
            </tr>
        
            <tr>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.rodTongs.code !== null ? this.dwrForm.value.rodTongs.code : ''} </td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Rod Tongs</td>
                <td style="text-align:right;  border-bottom: 1px solid black;">${this.dwrForm.value.rodTongs.firstValue !== null ? this.dwrForm.value.rodTongs.firstValue : ''} $</td>
                <td style="text-align:right; border-right: 1px solid black;  border-bottom: 1px solid black;">
                    ${this.dwrForm.value.rodTongs.lastValue !== null ? this.dwrForm.value.rodTongs.lastValue : ''} DAY
                </td>
                <td colspan="2" style="text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.rodTongs.price !== null ? this.dwrForm.value.rodTongs.price : ''}  $</td>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.wirelineSetUp.code !== null ? this.dwrForm.value.wirelineSetUp.code : ''} </td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Wireline Set Up</td>
                <td style="text-align:right;  border-bottom: 1px solid black;">${this.dwrForm.value.wirelineSetUp.firstValue !== null ? this.dwrForm.value.wirelineSetUp.firstValue : ''} $</td>
                <td style="text-align:right;  border-right: 1px solid black; border-bottom: 1px solid black;">
                    ${this.dwrForm.value.wirelineSetUp.lastValue !== null ? this.dwrForm.value.wirelineSetUp.lastValue : ''} DAY
                </td>
                <td style=" border-right: 1px solid black; text-align:right; border-bottom: 1px solid black;">
                    ${this.dwrForm.value.wirelineSetUp.price !== null ? this.dwrForm.value.wirelineSetUp.price : ''} $
                </td>
            </tr>
        
            <tr>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.tbgTongs.code !== null ? this.dwrForm.value.tbgTongs.code : ''}</td>
                <td colspan="3" style=" border-bottom: 1px solid black;">TBG Tongs</td>
                <td style="text-align:right;  border-bottom: 1px solid black;">${this.dwrForm.value.tbgTongs.firstValue !== null ? this.dwrForm.value.tbgTongs.firstValue : ''} $</td>
                <td style="text-align:right; border-right: 1px solid black;  border-bottom: 1px solid black;">
                    ${this.dwrForm.value.tbgTongs.lastValue !== null ? this.dwrForm.value.tbgTongs.lastValue : ''} DAY
                </td>
                <td colspan="2" style="text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.tbgTongs.price !== null ? this.dwrForm.value.tbgTongs.price : ''} $</td>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.pipeRackFloat.code !== null ? this.dwrForm.value.pipeRackFloat.code : ''} </td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Pipe Rack/Float</td>
                <td style="text-align:right;border-bottom: 1px solid black;">${this.dwrForm.value.pipeRackFloat.firstValue !== null ? this.dwrForm.value.pipeRackFloat.firstValue : ''} $</td>
                <td style="text-align:right;border-right: 1px solid black; border-bottom: 1px solid black;">
                    ${this.dwrForm.value.pipeRackFloat.lastValue !== null ? this.dwrForm.value.pipeRackFloat.lastValue : ''} DAY
                </td>
                <td style="border-right: 1px solid black; text-align:right; border-bottom: 1px solid black;">
                    ${this.dwrForm.value.pipeRackFloat.price !== null ? this.dwrForm.value.pipeRackFloat.price : ''}  $
                </td>
            </tr>
        
            <tr>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.tbgCutter.code !== null ? this.dwrForm.value.tbgCutter.code : ''} </td>
                <td colspan="3" style=" border-bottom: 1px solid black;">TBG Cutter</td>
                <td style="text-align:right;  border-bottom: 1px solid black;">${this.dwrForm.value.tbgCutter.firstValue !== null ? this.dwrForm.value.tbgCutter.firstValue : ''} $</td>
                <td style="text-align:right; border-right: 1px solid black;  border-bottom: 1px solid black;">
                    ${this.dwrForm.value.tbgCutter.lastValue !== null ? this.dwrForm.value.tbgCutter.lastValue : ''} EA
                </td>
                <td colspan="2" style="text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.tbgCutter.price !== null ? this.dwrForm.value.tbgCutter.price : ''}  $</td>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.wellHeadAdapt.code !== null ? this.dwrForm.value.wellHeadAdapt.code : ''} </td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Well Head Adapt</td>
                <td style="text-align:right;  border-bottom: 1px solid black;">${this.dwrForm.value.wellHeadAdapt.firstValue !== null ? this.dwrForm.value.wellHeadAdapt.firstValue : ''} $</td>
                <td style="text-align:right;  border-right: 1px solid black; border-bottom: 1px solid black;">
                    ${this.dwrForm.value.wellHeadAdapt.lastValue !== null ? this.dwrForm.value.wellHeadAdapt.lastValue : ''} DAY
                </td>
                <td style=" border-right: 1px solid black; text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.wellHeadAdapt.price !== null ? this.dwrForm.value.wellHeadAdapt.price : ''} $</td>
            </tr>
        
            <tr>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.workString.code !== null ? this.dwrForm.value.workString.code : ''} </td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Work String @</td>
                <td style="text-align:right;  border-bottom: 1px solid black;">${this.dwrForm.value.workString.firstValue !== null ? this.dwrForm.value.workString.firstValue : ''} $</td>
                <td style="text-align:right; border-right: 1px solid black;  border-bottom: 1px solid black;">
                    ${this.dwrForm.value.workString.lastValue !== null ? this.dwrForm.value.workString.lastValue : ''}  FT
                </td>
                <td colspan="2" style="text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.workString.price !== null ? this.dwrForm.value.workString.price : ''}  $</td>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.cibp.code !== null ? this.dwrForm.value.cibp.code : ''} </td>
                <td style=" border-bottom: 1px solid black;">CIBP</td>
                <td colspan="2" style="border: 1px solid black;">${this.dwrForm.value.cibp.secondValue !== null ? this.dwrForm.value.cibp.secondValue : ''}</td>
                <td style="text-align:right;  border-bottom: 1px solid black;">${this.dwrForm.value.cibp.firstValue !== null ? this.dwrForm.value.cibp.firstValue : ''} $</td>
                <td style="text-align:right;  border-right: 1px solid black; border-bottom: 1px solid black;">${this.dwrForm.value.cibp.lastValue !== null ? this.dwrForm.value.cibp.lastValue : ''} EA</td>
                <td style=" border-right: 1px solid black; text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.cibp.price !== null ? this.dwrForm.value.cibp.price : ''}  $</td>
            </tr>
        
            <tr>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.cementBulkUnit.code !== null ? this.dwrForm.value.cementBulkUnit.code : ''}</td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Cement Bulk Unit</td>
                <td style="text-align:right;  border-bottom: 1px solid black;">${this.dwrForm.value.cementBulkUnit.firstValue !== null ? this.dwrForm.value.cementBulkUnit.firstValue : ''} $</td>
                <td style="text-align:right; border-right: 1px solid black;  border-bottom: 1px solid black;">
                    ${this.dwrForm.value.cementBulkUnit.lastValue !== null ? this.dwrForm.value.cementBulkUnit.lastValue : ''} DAY
                </td>
                <td colspan="2" style="text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.cementBulkUnit.price !== null ? this.dwrForm.value.cementBulkUnit.price : ''} $</td>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.wellheadCutoff.code !== null ? this.dwrForm.value.wellheadCutoff.code : ''} </td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Well Head Cutoff</td>
                <td style="text-align:right;  border-bottom: 1px solid black;">${this.dwrForm.value.wellheadCutoff.firstValue !== null ? this.dwrForm.value.wellheadCutoff.firstValue : ''} $</td>
                <td style="text-align:right;  border-right: 1px solid black; border-bottom: 1px solid black;">${this.dwrForm.value.wellheadCutoff.lastValue !== null ? this.dwrForm.value.wellheadCutoff.lastValue : ''} EA</td>
                <td style=" border-right: 1px solid black; text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.wellheadCutoff.price !== null ? this.dwrForm.value.wellheadCutoff.price : ''} $</td>
            </tr>
        
            <tr>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.rigH2SMonitor.code !== null ? this.dwrForm.value.rigH2SMonitor.code : ''} </td>
                <td colspan="3" style=" border-bottom: 1px solid black;">Rig H2S Monitor</td>
                <td style="text-align:right;  border-bottom: 1px solid black;">${this.dwrForm.value.rigH2SMonitor.firstValue !== null ? this.dwrForm.value.rigH2SMonitor.firstValue : ''} $</td>
                <td style="text-align:right; border-right: 1px solid black;  border-bottom: 1px solid black;">
                    ${this.dwrForm.value.rigH2SMonitor.lastValue !== null ? this.dwrForm.value.rigH2SMonitor.lastValue : ''} DAY
                </td>
                <td colspan="2" style="text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.rigH2SMonitor.price !== null ? this.dwrForm.value.rigH2SMonitor.price : ''} $</td>
                <td style=" border-bottom: 1px solid black;">${this.dwrForm.value.scba.code !== null ? this.dwrForm.value.scba.code : ''} </td>
                <td colspan="3" style=" border-bottom: 1px solid black;">SCBA(s)</td>
                <td style="text-align:right;  border-bottom: 1px solid black;">${this.dwrForm.value.scba.firstValue !== null ? this.dwrForm.value.scba.firstValue : ''} $</td>
                <td style="text-align:right;  border-right: 1px solid black; border-bottom: 1px solid black;">${this.dwrForm.value.scba.lastValue !== null ? this.dwrForm.value.scba.lastValue : ''} DAY
                </td>
                <td style=" border-right: 1px solid black; text-align:right; border-bottom: 1px solid black;">${this.dwrForm.value.scba.price !== null ? this.dwrForm.value.scba.price : ''} $</td>
            </tr>
            <tr>
                <td colspan="7"></td>
                <td colspan="9" style="border:1px solid black; text-align: right;">Total $ ${this.chargeRecordTotal === 0 ? 0 : this.chargeRecordTotal.toFixed(2).replace(/d(?=(d{3})+.)/g, '$&,')}</td>
            </tr>
            <tr>
                <td colspan="16"></td>
            </tr>
            <tr>
                <td></td>
                <td colspan="15" style="font-weight: bold;"> Time Record</td>
            </tr>
        
            <tr>
                <td colspan="2" style="border:1px solid black; text-align: center"></td>
                <td colspan="3" style="border:1px solid black; font-weight: bold; text-align: center">Employee Signature</td>
                <td colspan="2" style="border:1px solid black; font-weight: bold; text-align: center">Employee Name</td>
                <td colspan="2" style="border:1px solid black; font-weight: bold; text-align: center">Start</td>
                <td style="border:1px solid black; font-weight: bold; text-align: center">Stop</td>
                <td style="border:1px solid black; font-weight: bold; text-align: center">Rig</td>
                <td style="border:1px solid black; font-weight: bold; text-align: center">Travel</td>
                <td colspan="2" style="border:1px solid black; font-weight: bold; text-align: center">Down</td>
                <td style="border:1px solid black; font-weight: bold; text-align: center">${this.dwrForm.value.timeRecordCustomFieldName}</td>
                <td style="border:1px solid black; font-weight: bold; text-align: center">Total</td>
            </tr>
            <tr>
                <td colspan="2" style="border:1px solid black; text-align: center">Operator</td>
                <td colspan="3" style="border:1px solid black; text-align: center">${this.dwrForm.value.timeRecord[0].employeeSignature}</td>
                <td colspan="2" style="border:1px solid black;">${this.userOperatorMap[this.dwrForm.value.timeRecord[0].employeeName] ? this.userOperatorMap[this.dwrForm.value.timeRecord[0].employeeName] : ''}</td>
                <td colspan="2" style="border:1px solid black;">${this.dwrForm.value.timeRecord[0].start}</td>
                <td style="border:1px solid black;">${this.dwrForm.value.timeRecord[0].stop}</td>
                <td style="border:1px solid black;">${this.dwrForm.value.timeRecord[0].rig}</td>
                <td style="border:1px solid black;">${this.dwrForm.value.timeRecord[0].travel}</td>
                <td colspan="2" style="border:1px solid black;">${this.dwrForm.value.timeRecord[0].down}</td>
                <td style="border:1px solid black;">${this.dwrForm.value.timeRecord[0].comment}</td>
                <td style="border:1px solid black;">${this.total0 !== '00:00' ? this.total0 : ''}</td>
            </tr>
            <tr>
                <td colspan="2" style="border:1px solid black; text-align: center"> Crewman</td>
                <td colspan="3" style="border:1px solid black; text-align: center">${this.dwrForm.value.timeRecord[1].employeeSignature}</td>
                <td colspan="2" style="border:1px solid black;">${this.userOperatorMap[this.dwrForm.value.timeRecord[1].employeeName] ? this.userOperatorMap[this.dwrForm.value.timeRecord[1].employeeName] : ''}</td>
                <td colspan="2" style="border:1px solid black;">${this.dwrForm.value.timeRecord[1].start}</td>
                <td style="border:1px solid black;">${this.dwrForm.value.timeRecord[1].stop}</td>
                <td style="border:1px solid black;">${this.dwrForm.value.timeRecord[1].rig}</td>
                <td style="border:1px solid black;">${this.dwrForm.value.timeRecord[1].travel}</td>
                <td colspan="2" style="border:1px solid black;">${this.dwrForm.value.timeRecord[1].down}</td>
                <td style="border:1px solid black;">${this.dwrForm.value.timeRecord[1].comment}</td>
                <td style="border:1px solid black;">${this.total1 !== '00:00' ? this.total1 : ''}</td>
            </tr>
            <tr>
                <td colspan="2" style="border:1px solid black; text-align: center"> Crewman</td>
                <td colspan="3" style="border:1px solid black; text-align: center">${this.dwrForm.value.timeRecord[2].employeeSignature}</td>
                <td colspan="2" style="border:1px solid black;">${this.userOperatorMap[this.dwrForm.value.timeRecord[2].employeeName] ? this.userOperatorMap[this.dwrForm.value.timeRecord[2].employeeName] : ''}</td>
                <td colspan="2" style="border:1px solid black;">${this.dwrForm.value.timeRecord[2].start}</td>
                <td style="border:1px solid black;">${this.dwrForm.value.timeRecord[2].stop}</td>
                <td style="border:1px solid black;">${this.dwrForm.value.timeRecord[2].rig}</td>
                <td style="border:1px solid black;">${this.dwrForm.value.timeRecord[2].travel}</td>
                <td colspan="2" style="border:1px solid black;">${this.dwrForm.value.timeRecord[2].down}</td>
                <td style="border:1px solid black;">${this.dwrForm.value.timeRecord[2].comment}</td>
                <td style="border:1px solid black;">${this.total2 !== '00:00' ? this.total2 : ''}</td>
            </tr>
            <tr>
                <td colspan="2" style="border:1px solid black; text-align: center"> Crewman</td>
                <td colspan="3" style="border:1px solid black; text-align: center">${this.dwrForm.value.timeRecord[3].employeeSignature}</td>
                <td colspan="2" style="border:1px solid black;">${this.userOperatorMap[this.dwrForm.value.timeRecord[3].employeeName] ? this.userOperatorMap[this.dwrForm.value.timeRecord[3].employeeName] : ''}</td>
                <td colspan="2" style="border:1px solid black;">${this.dwrForm.value.timeRecord[3].start}</td>
                <td style="border:1px solid black;">${this.dwrForm.value.timeRecord[3].stop}</td>
                <td style="border:1px solid black;">${this.dwrForm.value.timeRecord[3].rig}</td>
                <td style="border:1px solid black;">${this.dwrForm.value.timeRecord[3].travel}</td>
                <td colspan="2" style="border:1px solid black;">${this.dwrForm.value.timeRecord[3].down}</td>
                <td style="border:1px solid black;">${this.dwrForm.value.timeRecord[3].comment}</td>
                <td style="border:1px solid black;">${this.total3 !== '00:00' ? this.total3 : ''}</td>
            </tr>
            <tr>
                <td colspan="2" style="border:1px solid black; text-align: center"> Other</td>
                <td colspan="3" style="border:1px solid black; text-align: center">${this.dwrForm.value.timeRecord[4].employeeSignature}</td>
                <td colspan="2" style="border:1px solid black;">${this.userOperatorMap[this.dwrForm.value.timeRecord[4].employeeName] ? this.userOperatorMap[this.dwrForm.value.timeRecord[4].employeeName] : ''}</td>
                <td colspan="2" style="border:1px solid black;">${this.dwrForm.value.timeRecord[4].start}</td>
                <td style="border:1px solid black;">${this.dwrForm.value.timeRecord[4].stop}</td>
                <td style="border:1px solid black;">${this.dwrForm.value.timeRecord[4].rig}</td>
                <td style="border:1px solid black;">${this.dwrForm.value.timeRecord[4].travel}</td>
                <td colspan="2" style="border:1px solid black;">${this.dwrForm.value.timeRecord[4].down}</td>
                <td style="border:1px solid black;">${this.dwrForm.value.timeRecord[4].comment}</td>
                <td style="border:1px solid black;">${this.total4 !== '00:00' ? this.total4 : ''}</td>
            </tr>
        
            <tr>
                <td colspan="10" style="border:1px solid black; font-weight: bold; text-align: center"> Total Hours (Hours
                    Extended)
                </td>
                <td style="border:1px solid black;">${this.totalrig !== '00:00' ? this.totalrig : ''}</td>
                <td style="border:1px solid black;">${this.totaltravel !== '00:00' ? this.totaltravel : ''}</td>
                <td colspan="2" style="border:1px solid black;">${this.totaldown !== '00:00' ? this.totaldown : ''}</td>
                <td style="border:1px solid black;">${this.totalcomment !== '00:00' ? this.totalcomment : ''}</td>
                <td style="border:1px solid black;">${this.totalAll !== '00:00' ? this.totalAll : ''}</td>
            </tr>
            <tr>
                <td colspan="16"></td>
            </tr>
            <tr>
                <td colspan="16" style="font-size: 10px;">
                    Services have been provided subject to the terms and conditions on the current price list, the receipt of
                    which is hereby acknowledged. Customer agrees to pay all invoices for services on a net 30 day basis from
                    date on wich purchases were invoiced. Customer agrees that JMR Services shall not be liable for damages that
                    occur “down hole”, any loss of production, any loss of oil in place or any other consequential damages. If
                    customer disputes any item invoiced, customer must, within twenty (20) days after receipt of invoice, notify
                    contractor of item disputed specifying reason therefor, but law in the state where services were performed.
                    All expenses of collection including court costs and reasonable attorney fees will be borne by customer. All
                    amounts due hereunder are payable in Midland, Midland County, Texas. 
                </td>
            </tr>
            <tr>
                <td colspan="16"></td>
            </tr>
        
            <tr>
                <td colspan="16" style="font-weight: bold; text-align: center">Approved by</td>
            </tr>
            <tr>
                <td colspan="16"></td>
            </tr>
            <tr>
                <td colspan="6" style="font-weight: bold; text-align: left">JMR Representative</td>
                <td colspan="3" style="font-weight: bold; text-align: left">Date</td>
                <td colspan="5" style="font-weight: bold; text-align: left">Customer Representative</td>
                <td colspan="2" style="font-weight: bold; text-align: left">Date</td>
            </tr>
            
            <tr>
                <td colspan="6" style="text-align: left">
                    ${(this.dwrForm.value.status === 1) && this.dwrForm.value.supervisorSign ? this.dwrForm.value.supervisorSign.name : (this.dwrForm.value.status === 2) && this.dwrForm.value.managerSign ? this.dwrForm.value.managerSign.name : ''}
                </td>
                <td colspan="3" style="text-align: left">${(this.dwrForm.value.status === 1) && this.dwrForm.value.supervisorSign ? ('0' + (new Date(this.dwrForm.value.supervisorSign.date).getMonth() + 1)).slice(-2) + '/' + new Date(this.dwrForm.value.supervisorSign.date).getDate() + '/' + new Date(this.dwrForm.value.supervisorSign.date).getFullYear() : (this.dwrForm.value.status === 2) && this.dwrForm.value.managerSign ? ('0' + (new Date(this.dwrForm.value.managerSign.date).getMonth() + 1)).slice(-2) + '/' + new Date(this.dwrForm.value.managerSign.date).getDate() + '/' + new Date(this.dwrForm.value.managerSign.date).getFullYear() : ''}
                </td>
                <td colspan="5" style="text-align: left"></td>
                <td colspan="2" style="text-align: left"></td>
            </tr>
            </tbody>
        </table>
        </body>
        </html>
`;
        const blob = new Blob([template], {type: 'text/csv'});
        saveAs(blob, `${name}.html`);
    }

    transfer() {
        this.transferSub = this.getTransfer.req(this.f['id'].value, this.wellId, this.formType['DWR'], this.svc).subscribe(res => {
            if (res.header.status === 4000) {
                this.dwrForm.get('assigneeAccessLevel').setValue(this.accessLevelEnum['Supervisor']);
                this.dwrForm.get('supervisorSign').setValue(null);
                this.dwrForm.get('managerSign').setValue(null);
                this.getWellsSub = this.getWells.req(this.svc).subscribe();
                this.selectDWRSub = this.selectDWR.req(this.svc).subscribe();
            }
        });

    }

    returnDateNum(timestamp) {
        return +new Date(timestamp);
    }

    removeDWR(id, name) {
        const dialogRef = this.dialog.open(DeleteDialogComponent, {
            width: '31%',
            data: {
                value: name,
                type: 'dwr'
            }
        });

        this.dialogRefSub = dialogRef.afterClosed().subscribe(result => {
            if (result) {
                this.deleteDWRSub = this.removeDwr.req(id, this.wellId, this.svc).subscribe(res => {
                    if (res.header.status === 4000) {
                        this.dwrForm = null;
                        this.success('Saved successfully');
                        this.dbSvc.delete('dwr', id);
                        this.getDwrs();
                    } else {
                        this.successes = false;
                        this.error(res.header.summary);
                    }
                });
            }
        });
    }


    onSubmit(status) {
        this.submitted += 1;
        this.markFormGroupTouched(this.dwrForm);
        if (this.dwrForm.get('date').value) {
            this.dwrForm.get('date').clearValidators();
            this.dwrForm.get('date').setErrors(null);
            this.dwrForm.get('date').setValidators(null);
        }
        if (this.dwrForm.valid && this.dwrForm.value.date) {
            if (this.dwrForm.value.workDescription[0]) {
                this.setValueFromTo();
            }
            const user = JSON.parse(localStorage.getItem('userId'));
            if (status === 0) {
                this.dwrForm.get('managerSign').setValue(null);
                this.dwrForm.get('supervisorSign').setValue(null);
            }
            if (status === 2) {
                this.dwrForm.value.managerSign = {
                    name: `${user.firstName} ${user.lastName}`,
                    date: `${('0' + (new Date().getMonth() + 1)).slice(-2) + '.' + new Date().getDate() + '.' + new Date().getFullYear()}`,
                    phone: `${user.phone ? user.phone : ''}`
                };
            }
            if (status === 1) {
                this.dwrForm.get('assigneeAccessLevel').setValue(this.accessLevelEnum['Manager']);
                this.dwrForm.value.supervisorSign = {
                    name: `${user.firstName} ${user.lastName}`,
                    date: `${('0' + (new Date().getMonth() + 1)).slice(-2) + '.' + new Date().getDate() + '.' + new Date().getFullYear()}`,
                    companyName: 'JMR'
                };
            }
            this.dwrForm.value.status = status;
            if (!this.dwrForm.value.id) {
                delete this.dwrForm.value.id;
            }
            const date = this.dwrForm.get('date').value;
            this.dwrForm.value.date = +new Date(date);

            this.insertDWRSub = this.insertDwr.req(this.dwrForm.value, this.svc).subscribe(res => {
                if (res.header.status === 4000) {
                    this.successes = true;
                    this.dwrForm.value.id = res.body.key.id;
                    this.success('Saved successfully');
                    this.dbSvc.update('dwr', this.dwrForm.value);
                    this.getDwrs();
                    this.openDwr(this.dwrForm.value);
                } else {
                    this.successes = false;
                    this.error(res.header.summary);
                }
                this.insertDWRSub.unsubscribe();
            });
        }
    }
}
