import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';

import { Subject, BehaviorSubject } from 'rxjs';


@Injectable()
export class WellService {
  public wellData = new BehaviorSubject(null);

  constructor () {

  }

  setWellData (data) {
    this.wellData.next(data);
  }

  getWellData () {
    return this.wellData;
  }
}
