import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { Subject } from 'rxjs';
import { appConfig } from '../constants/app.config';
import { LoadingService } from './loading.service';
import { WsService } from './ws.service';


@Injectable()
export class CommunicationService {
  public wells = new Subject<any>();

  constructor(private loadingService: LoadingService,
              private svc: WsService) {

  }

  getWells() {

  }

  setWells() {

  }

}
