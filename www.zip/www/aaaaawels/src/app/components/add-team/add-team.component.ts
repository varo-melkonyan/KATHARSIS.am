import {Component, OnDestroy, OnInit} from '@angular/core';
import {HeaderService} from '../../services/header.service';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {appConfig} from '../../constants/app.config';
import {WsService} from '../../services/ws.service';
import {ActivatedRoute, Router} from '@angular/router';
import {AlertService} from '../../services/alert.service';
import {ISubscription} from 'rxjs/Subscription';
import {AddTeamService} from './add-team.service';
import {DbService} from '../../services/db.service';
import {LokiService} from '../../services/loki.service';

@Component({
    selector: 'app-add-team',
    templateUrl: './add-team.component.html',
    styleUrls: ['./add-team.component.scss']
})
export class AddTeamComponent implements OnInit, OnDestroy {
    public teamForm: FormGroup;
    public isOpenBar = false;
    public supervisors = [];
    public crewmenNames = [];
    public selectedCrewmen = [];
    private teamSub: ISubscription;
    private addTeamSub: ISubscription;
    public dbReady: ISubscription;
    private routerParams: ISubscription;
    public item;
    public routerSub: any;
    public isActive = appConfig.isActive;
    public setTeam: any;
    public getTeam: any;
    public setTeamSub: any;
    public getTeamSub: any;

    constructor(private headerSvc: HeaderService,
                private svc: WsService,
                private alertService: AlertService,
                private router: Router,
                private dbSvc: DbService,
                private addTeamSvc: AddTeamService,
                private route: ActivatedRoute,
                private fb: FormBuilder,
                private lokiSrc: LokiService) {
        this.addTeamSub = this.lokiSrc.returnCallSub().subscribe(coll => {
            if (coll) {
                this.setTeam = coll.by('name', 'insertTeam');
                this.getTeam = coll.by('name', 'getTeam');
                this.setTeamSub = this.setTeam.req('', this.svc).subscribe(res => {
                    res.body = {
                        record: {
                            name: '',
                            supervisorName: '',
                            crewmanNames: ['', '', '']
                        }
                    };
                });
            }
        });
        this.headerSvc.setUrlParams('Add New Rig');
        this.routerSub = router.events.subscribe(event => {
            if (this.router.url.length < 6) {
                this.headerSvc.setUrlParams('Add New Rig');
                this.item = null;
                this.initForm();
            }
        });
        this.dbReady = this.dbSvc.getDbReady().subscribe(ready => {
            if (ready) {
                this.dbSvc.openDatabase().then(() => {
                    this.dbSvc.getAll('users').then(
                        users => {
                            const l = users.length;
                            for (let i = 0; i < l; i++) {
                                if (users[i].accessLevel === 2) {
                                    this.supervisors.push(users[i]);
                                }
                                if (users[i].accessLevel === 3) {
                                    this.crewmenNames.push(users[i]);
                                }
                            }
                        },
                        error => {
                        }
                    );
                });
                this.routerParams = this.route.params.subscribe(params => {
                    let id = params['id'];
                    if (id) {
                        id = id.split(' ').join('/');
                        this.dbSvc.openDatabase().then(() => {
                            this.dbSvc.getByKey('teams', id).then(
                                team => {
                                    if (team) {
                                        this.item = team;
                                        this.headerSvc.setUrlParams(team.name);
                                    } else {
                                        this.router.navigate(['/']);
                                    }
                                    setTimeout(() => {
                                        this.initForm(this.item);
                                    });
                                },
                                error => {
                                }
                            );
                        });
                    } else {
                        this.item = null;
                        this.initForm();
                    }
                });
            }
        });
    }

    ngOnInit() {
        if (!localStorage.getItem('sign')) {
            this.router.navigate(['sign-in']);
        }
    }

    ngOnDestroy() {
        if (this.setTeamSub) {
            this.setTeamSub.unsubscribe();
        }
        if (this.getTeamSub) {
            this.getTeamSub.unsubscribe();
        }
        if (this.teamSub) {
            this.teamSub.unsubscribe();
        }
        if (this.addTeamSub) {
            this.addTeamSub.unsubscribe();
        }
        if (this.routerSub) {
            this.routerSub.unsubscribe();
        }
        if (this.routerParams) {
            this.routerParams.unsubscribe();
        }
        if (this.dbReady) {
            this.dbReady.unsubscribe();
        }
    }

    initForm(item?) {
        if (item) {
            this.selectedCrewmen = item.crewmen;
        }
        this.teamForm = this.fb.group({
            id: [item && item.id ? item.id : ''],
            name: [{
                value: item ? item.name : '',
                disabled: this.isActive
            }, Validators.required],
            supervisorId: [{
                value: item && item.supervisor ? item.supervisor.id : '',
                disabled: this.isActive
            }, Validators.required],
            crewmanIds: [{
                value: item && item.crewmen ? item.crewmen : [],
                disabled: this.isActive
            }, Validators.required],
            crewmenNameInp: [{
                value: '',
                disabled: this.isActive
            }],
        });
    }

    get f() {
        return this.teamForm.controls;
    }

    stopProp(e) {
        e.stopPropagation();
    }

    addTag(crewmenName) {
        const tag = crewmenName;
        const l = this.teamForm.get('crewmanIds').value.length;
        const elem = this.teamForm.get('crewmanIds').value;
        if (elem[0]) {
            for (let i = 0; i < l; i++) {
                if (tag === elem[i]) {
                    return false;
                } else if ((i + 1) === l) {
                    this.selectedCrewmen = this.selectedCrewmen.concat([tag]);
                }
            }
        } else {
            this.selectedCrewmen = this.selectedCrewmen.concat([tag]);
        }
        this.teamForm.get('crewmanIds').setValue(this.selectedCrewmen);
    }

    deleteTag(index) {
        this.selectedCrewmen.splice(index, 1);
        this.selectedCrewmen = Object.assign([], this.selectedCrewmen);
        this.teamForm.get('crewmanIds').setValue(this.selectedCrewmen);
    }

    markFormGroupTouched(formGroup: FormGroup) {
        (<any>Object).values(formGroup.controls).forEach(control => {
            control.markAsTouched();

            if (control.controls) {
                this.markFormGroupTouched(control);
            }
        });
    }


    success(message: string) {
        this.alertService.success(message);
    }

    error(message: string) {
        this.alertService.error(message);
    }

    filterName(event) {
        let value = event.target.value.replace(/\s\s+/g, ' ');
        value = value === ' ' ? '' : value;
        this.f['name'].setValue(value);
    }

    onSubmit() {
        this.markFormGroupTouched(this.teamForm);
        if (this.teamForm.valid) {
            if (!this.teamForm.value.id) {
                delete this.teamForm.value.id;
            }
            const l = this.teamForm.value.crewmanIds.length;
            const elems = Object.assign([], this.teamForm.value.crewmanIds);
            const crewmenNames = Object.assign([], []);
            for (let i = 0; i < l; i++) {
                crewmenNames.push(elems[i].id);
            }

            this.teamSub = this.setTeam.req(Object.assign({}, this.teamForm.value), this.svc).subscribe(res => {
                res.body.record = Object.assign({}, this.teamForm.value);
                delete res.body.record['crewmenNameInp'];
                res.body.record['crewmanIds'] = crewmenNames;
                this.setTeamSub = this.setTeam.req(res.body.record, this.svc).subscribe(res => {
                    if (res.header.status === 4000) {
                        this.getTeamSub = this.getTeam.req(this.svc).subscribe();
                        this.router.navigate(['list/team']);
                    } else {
                        this.error(res.header.summary);
                    }
                });
                this.teamSub.unsubscribe();
            });

        }
    }
}
