import {Component} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';

@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css']
})
export class ContentComponent {

  constructor(private router: Router,
              private route: ActivatedRoute) {
  }

  routeFn(url: Array<any>): void {
    this.router.navigate(url, {relativeTo: this.route}).then(res => {
      console.log(res, 'res');
    });
  }

}
