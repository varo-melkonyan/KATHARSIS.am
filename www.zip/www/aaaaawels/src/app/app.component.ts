import {Component, OnDestroy, OnInit} from '@angular/core';
import { WsService } from './services/ws.service';
import { appConfig } from './constants/app.config';
import { ActivatedRoute, Router } from '@angular/router';
import { HeaderService } from './services/header.service';
import { HttpClient } from '@angular/common/http';
import {LokiService} from './services/loki.service';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {
    title = 'JMR';
    public isBar = true;
    public sign = false;
    public openSub: any;
    public thisUserSub: any;
    public  getUserOneSub: any;
    public getUserOne: any;
    public returnOpenConnect: any;

    constructor(private wsService: WsService,
                private headerSvc: HeaderService,
                private route: ActivatedRoute,
                private http: HttpClient,
                private router: Router,
                private lokiSvc: LokiService) {
        this.getUserOneSub = this.lokiSvc.returnCallSub().subscribe(coll => {
            if (coll) {
                this.getUserOne = coll.by('name', 'getUserOne');
                this.returnOpenConnect = coll.by('name', 'connectionEstablished');
                if (!localStorage.getItem('sign')) {
                    this.sign = true;
                    this.router.navigate(['sign-in']);
                } else {
                    const userName = JSON.parse(localStorage.getItem('sign')).userName;
                    const password = JSON.parse(localStorage.getItem('sign')).password;
                    this.wsService.wsFn(userName, password);
                    this.openSub = this.returnOpenConnect.get(this.wsService).subscribe(res => {
                        if (res) {
                            /*this.router.navigate([appConfig.defaultHomePage], {relativeTo: this.route});*/
                            if (localStorage.getItem('sign')) {
                               this.getUserOneSub = this.getUserOne.req(JSON.parse(localStorage.getItem('sign')).userName, this.wsService).subscribe();
                            }
                        }
                    });
                }
                this.thisUserSub = this.getUserOne.req('', this.wsService).subscribe(user => {
                    localStorage.setItem('userId', JSON.stringify(user.body.record));
                    appConfig.accessLevel = user.body.record.accessLevel;
                    appConfig.isActive = !(user.body.record.accessLevel === 1 ||
                        user.body.record.accessLevel === 0);
                    this.headerSvc.setIsActive(!(user.body.record.accessLevel === 1 ||
                        user.body.record.accessLevel === 0));
                    appConfig.accessLevel = JSON.parse(localStorage.getItem('userId')) ?
                        JSON.parse(localStorage.getItem('userId')).accessLevel : '';
                    appConfig.isActive = JSON.parse(localStorage.getItem('userId')) ?
                        !(JSON.parse(localStorage.getItem('userId')).accessLevel === 1 ||
                            JSON.parse(localStorage.getItem('userId')).accessLevel === 0) : true;
                });
            }

        });
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            appConfig.mobileUser = true;
        } else {
            appConfig.mobileUser = false;
        }
        if (typeof window.orientation !== 'undefined') {
            this.isBar = false;
        }
        this.router.events
            .subscribe((event) => {
                if (this.router.url.indexOf('sign-in') > -1) {
                    this.sign = true;
                } else {
                    if (localStorage.getItem('sign')) {
                        this.sign = false;
                    }
                }
            });

    }

    ngOnInit() {
    }

    ngOnDestroy(): void {
        if (this.openSub) {
            this.openSub.unsubscribe();
        }
        if (this.thisUserSub) {
            this.thisUserSub.unsubscribe();
        }
        if (this.getUserOneSub) {
            this.getUserOneSub.unsubscribe();
        }
    }

    toggleBarFn(event) {
        this.isBar = event;
    }

    fret() {
    }
}
