import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ContentRoutingModule} from './content-routing.module';
import { NameComponent } from './name/name.component';
import { LnameComponent } from './lname/lname.component';
import { AgeComponent } from './age/age.component';
import {NameModule} from './name/name.module';
import {LnameModule} from './lname/lname.module';
import {AgeModule} from './age/age.module';


@NgModule({
  declarations: [NameComponent, LnameComponent, AgeComponent],
  imports: [
    CommonModule,
    ContentRoutingModule,
    NameModule,
    LnameModule,
    AgeModule
  ]
})
export class ContentModule {
}
