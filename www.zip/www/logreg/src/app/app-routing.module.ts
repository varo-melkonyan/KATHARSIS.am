import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {LoginComponent} from './login/login.component';
import {RegistrGuard} from './registr.guard';
import {ListComponent} from './list/list.component';

const routes: Routes = [
  {path: '', redirectTo: '/signin', pathMatch: 'full'},
  {
    path: 'signin', component: LoginComponent, canLoad: [RegistrGuard]
  },
  {path: 'list', component: ListComponent},
  {
    path: 'signup',
    loadChildren: () => import('./registr/registr.module').then(m => m.RegistrModule)
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
