import {Component, OnInit} from '@angular/core';
import * as loki from 'lokijs';
import * as lokiIndexed from 'lokijs/src/loki-indexed-adapter.js';
import {FormBuilder, FormGroup} from '@angular/forms';
import {AppService} from '../app.service';

@Component({
  selector: 'app-data',
  templateUrl: './data.component.html',
  styleUrls: ['./data.component.css'],
  providers: [AppService]
})
export class DataComponent implements OnInit {

  public dataForm: FormGroup;
  public id = this.appsrc.getId();

  constructor(public fb: FormBuilder, public appsrc: AppService) {
    this.appsrc.getData();
    this.appsrc.getId();
  }

  ngOnInit(): void {
    this.dataForm = this.fb.group({
      data: '',
      dataChange: ''
    });
  }

  // create(): void {
  //   const k = this.dataForm.controls.data.value.split(',');
  //   this.coll.insert({
  //     name: k[0],
  //     lastname: k[1],
  //   });
  //   this.db.saveDatabase();
  // }

  getData(): any {
    for (let i = 0; i < this.appsrc.db.getCollection('users').data.length; i++) {
      return this.appsrc.db.getCollection('users').data[this.id];
    }
  }

  remove(): void {
    this.appsrc.coll.remove();
    this.appsrc.db.saveDatabase();
  }


  change(): void {
    this.dataForm.controls.dataChange = this.dataForm.controls.data.value;
    const k = this.dataForm.controls.data.value.split(',');
    this.appsrc.coll.remove();
    this.appsrc.coll.insert({
      name: k[0],
      lastname: k[1],
      email: k[2],
      password: k[3]
    });
    this.appsrc.db.saveDatabase();
  }
}
