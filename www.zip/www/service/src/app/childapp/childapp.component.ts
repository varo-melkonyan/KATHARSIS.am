import {Component, OnDestroy} from '@angular/core';
import {ChildappService} from './childapp.service';

@Component({
  selector: 'app-childapp',
  templateUrl: './childapp.component.html',
  styleUrls: ['./childapp.component.css'],
  providers: [ChildappService]
})
export class ChildappComponent implements OnDestroy {

  public sub: any;

  constructor(public src: ChildappService) {
    this.sub = src.getData().subscribe(value => value);
  }

  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }

}
