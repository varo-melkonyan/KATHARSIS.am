import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'tableFilter'
})
export class ControllersFilterTable implements PipeTransform {
    transform(items: any, name: string, status: number, tag?: string) {
        if (items && items.length) {
            return items.filter(item => {
                if (item.name) {
                    if (this.validateEmail(item.name)) {
                        if (name && (item.firstName + ' ' + item.lastName).toLowerCase().indexOf(name.toLowerCase()) === -1) {
                            return false;
                        }
                    } else {
                        if (name && (item.name).toLowerCase().indexOf(name.toLowerCase()) === -1) {
                            return false;
                        }
                    }
                } else {
                    if (name && (item.firstName + ' ' + item.lastName).toLowerCase().indexOf(name.toLowerCase()) === -1) {
                        return false;
                    }
                }
                if (tag && item['metadata'] && !item['metadata'].tags) {
                    return false;
                }
                if (tag && item['metadata'] && item['metadata'].tags) {
                    const tags = tag.split(',');
                    const x = item['metadata'].tags.filter(function (e) {
                            return this.indexOf(e) > -1;
                        },
                        tags);
                    if (x && x.length === tags.length) {
                    } else {
                        return false;
                    }
                }
                /*if (tag && item['metadata'] && item['metadata'].tags
                  && item['metadata'].tags.toString().toLowerCase().indexOf(tag.toLowerCase()) === -1) {
                  return false;
                }*/
                if (item.accessLevel || item.accessLevel === 0) {
                    if ((status || status === 0) && item && item.accessLevel !== status) {
                        return false;
                    }
                }
                if (item.status || item.status === 0) {
                    if ((status || status === 0) && item && item.status !== status) {
                        return false;
                    }
                }
                return true;
            });
        } else {
            return items;
        }
    }

    validateEmail(email) {
        const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }
}
