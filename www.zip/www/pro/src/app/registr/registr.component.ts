import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {Router} from '@angular/router';
import {AppService} from '../app.service';


@Component({
  selector: 'app-registr',
  templateUrl: './registr.component.html',
  styleUrls: ['./registr.component.css'],
  providers: [AppService]
})
export class RegistrComponent implements OnInit {

  public registerForm: FormGroup;
  public isPassword = true;
  public idemail = '';

  constructor(private fb: FormBuilder, private router: Router, private appsrc: AppService) {
    this.appsrc.getData();
  }


  ngOnInit(): void {
    this.registerForm = this.fb.group({
      name: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9_-]{3,15}$')]],
      lastname: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9_-]{5,15}$')]],
      email: ['', [Validators.required, Validators.pattern('^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\\]?)$')]],
      password: ['', [Validators.required, Validators.pattern('^[a-z0-9_-]{6,15}$')]]
    });
  }

  data(): any {
    for (let i = 0; i < this.appsrc.db.getCollection('users').data.length; i++) {
      this.idemail += ' ' + (this.appsrc.db.getCollection('users').data[i]['email']);

    }
    const value = this.idemail.includes(this.registerForm.controls.email.value);
    return value;
  }

  getReg(): void {

    const data = {
      name: this.registerForm.controls.name.value,
      lastname: this.registerForm.controls.lastname.value,
      email: this.registerForm.controls.email.value,
      pass: this.registerForm.controls.password.value
    };
    if (this.registerForm.valid) {

      if (!this.data()) {

        this.appsrc.addData(data);
        this.router.navigateByUrl('/signin').then(x => x);
      } else {
        alert('This email busy!!');
      }
    } else {
      alert('Please fill in all the fields correctly!');
    }
  }

  showPassword(): void {
    this.isPassword = false;
  }

  hidePassword(): void {
    this.isPassword = true;
  }
}
