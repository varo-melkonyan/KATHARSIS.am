import {Component, OnDestroy, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {WellService} from './well.service';
import {ISubscription} from 'rxjs/Subscription';
import {MatDialog} from '@angular/material';
import {DeleteDialogComponent} from '../delete-dialog/delete-dialog.component';
import {WsService} from '../../services/ws.service';
import {appConfig} from '../../constants/app.config';
import {AlertService} from '../../services/alert.service';
import {HeaderService} from '../../services/header.service';
import {AddWellService} from '../add-well/add-well.service';
import {LokiService} from '../../services/loki.service';

@Component({
    selector: 'app-well',
    templateUrl: './well.component.html',
    styleUrls: ['./well.component.scss']
})
export class WellComponent implements OnInit, OnDestroy {
    public isOpenFilter = false;
    private wellDataSub: ISubscription;
    private dialogRefSub: ISubscription;
    private wellRemoveSub: ISubscription;
    public headerSub: ISubscription;

    public data: any;
    public nameFilter: string;
    public statusFilter: number;
    public groupsFilter: string;
    public teamFilter: string;
    public w3aFilter: number;
    public w3Filter: number;
    public dwrFilter: number;
    public isActive = appConfig.isActive;
    public accessLevel = appConfig.accessLevel;
    public getRemoveWellSub: any;
    public getRemoveWell: any;
    public getWells: any;
    public getTags: any;
    public getWellsSub: any;
    public getTagsSub: any;

    constructor(private router: Router,
                public dialog: MatDialog,
                private wsSvc: WsService,
                private alertService: AlertService,
                private headerSvc: HeaderService,
                private addWellSvc: AddWellService,
                private svc: WellService,
                private lokiSrc: LokiService) {

        this.getRemoveWellSub = this.lokiSrc.returnCallSub().subscribe(coll => {
            if (coll) {
                this.getRemoveWell = coll.by('name', 'removeWell');
                this.getWells = coll.by('name', 'getWell');
                this.getTags = coll.by('name', 'getTags');
                this.wellRemoveSub = this.getRemoveWell.req('', this.wsSvc).subscribe(res => {
                    if (res.header.status === 4000) {
                        this.getWellsSub = this.getWells.req(this.wsSvc).subscribe();
                        this.getTagsSub = this.getTags.req(this.wsSvc).subscribe();
                    } else {
                        this.error(res.header.summary);
                    }
                });
            }
        });
        this.headerSub = this.headerSvc.getIsActive().subscribe(isActive => {
            this.isActive = isActive;
        });
        this.wellDataSub = this.svc.getWellData().subscribe(data => {
            if (data) {
                this.data = data;
            }
        });

    }

    ngOnInit() {
        if (!localStorage.getItem('sign')) {
            this.router.navigate(['sign-in']);
        }
    }

    ngOnDestroy() {
        if (this.getWellsSub) {
            this.getWellsSub.unsubscribe();
        }
        if (this.getTagsSub) {
            this.getTagsSub.unsubscribe();
        }
        if (this.wellDataSub) {
            this.wellDataSub.unsubscribe();
        }
        if (this.getRemoveWellSub) {
            this.getRemoveWellSub.unsubscribe();
        }
        if (this.dialogRefSub) {
            this.dialogRefSub.unsubscribe();
        }
        if (this.headerSub) {
            this.headerSub.unsubscribe();
        }
        this.wellRemoveSub.unsubscribe();
    }

    success(message: string) {
        this.alertService.success(message);
    }

    error(message: string) {
        this.alertService.error(message);
    }

    setPage() {
        this.addWellSvc.setEditItemName(null);
        this.router.navigate(['well']);
    }

    setWellDataPage(id, name) {
        const sid = id.split('/').join(' ');
        this.headerSvc.setUrlParams(name);
        this.router.navigate(['well/well-form', sid]);
    }

    stopProp(e) {
        e.stopPropagation();
    }

    deleteItem(name, id) {
        const dialogRef = this.dialog.open(DeleteDialogComponent, {
            width: '31%',
            data: name
        });

        this.dialogRefSub = dialogRef.afterClosed().subscribe(result => {
            if (result) {
                this.getRemoveWellSub = this.getRemoveWell.req(id, this.wsSvc).subscribe();
            }
        });
    }

}
