import {Injectable} from '@angular/core';
import * as Loki from 'lokijs';
import * as LokiIndexedAdapter from 'lokijs/src/loki-indexed-adapter';
import {BehaviorSubject} from 'rxjs';
import {portalScheme} from '../constants/portal.scheme';

@Injectable({
  providedIn: 'root'
})
export class LokiService {
  public db: any;

  public collection: any;
  public collSub = new BehaviorSubject(null);
  private options = [
    {
      unique: ['name'],
      serializableIndices: false
    }
  ];

  constructor() {
    this.init('GS.db').then((db: any) => {
      this.db = db;
      this.collection = this.db.addCollection('wsScheme', this.options);
      this.collection.insert(portalScheme);
      this.collSub.next(this.collection);
    });
  }

  returnCallSub() {
    return this.collSub;
  }

  init(filename: string, opt?: any) {
    return new Promise(resolve => {
      opt = opt || {};
      resolve(new Loki(filename, opt));
    });
  }
}
