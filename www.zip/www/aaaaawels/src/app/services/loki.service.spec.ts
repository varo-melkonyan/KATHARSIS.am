import { TestBed } from '@angular/core/testing';

import { LokiService } from './loki.service';

describe('LokiService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LokiService = TestBed.get(LokiService);
    expect(service).toBeTruthy();
  });
});
