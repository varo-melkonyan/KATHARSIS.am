import {Component, OnDestroy, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {TeamService} from './team.service';
import {ISubscription} from 'rxjs/Subscription';
import {DeleteDialogComponent} from '../delete-dialog/delete-dialog.component';
import {MatDialog} from '@angular/material';
import {AlertService} from '../../services/alert.service';
import {WsService} from '../../services/ws.service';
import {appConfig} from '../../constants/app.config';
import {HeaderService} from '../../services/header.service';
import {LokiService} from '../../services/loki.service';

@Component({
    selector: 'app-team',
    templateUrl: './team.component.html',
    styleUrls: ['./team.component.scss']
})
export class TeamComponent implements OnInit, OnDestroy {
    private teamDataSub: ISubscription;
    private dialogRefSub: ISubscription;
    private teamRemoveSub: ISubscription;
    private headerSub: ISubscription;

    public data: any;
    public isOpenFilter = false;
    public teamName: string;
    public supervisorName: string;
    public membersName: string;
    public isActive = appConfig.isActive;
    public getRemoveTeamSub: any;
    public getRemoveTeam: any;
    public getTeam: any;
    public getTeamSub: any;

    constructor(private router: Router,
                public dialog: MatDialog,
                private svc: TeamService,
                private wsSvc: WsService,
                private headerSvc: HeaderService,
                private alertService: AlertService,
                private lokiSrc: LokiService) {
        this.getRemoveTeamSub = this.lokiSrc.returnCallSub().subscribe(coll => {
            if (coll) {
                this.getRemoveTeam = coll.by('name', 'removeTeam');
                this.getTeam = coll.by('name', 'getTeam');
                this.teamRemoveSub = this.getRemoveTeam.req('', this.wsSvc).subscribe(res => {
                    if (res.header.status === 4000) {
                        this.getTeamSub = this.getTeam.req(this.wsSvc).subscribe();
                    } else {
                        this.error(res.header.summary);
                    }
                });
            }
        });
        this.headerSub = this.headerSvc.getIsActive().subscribe(isActive => {
            this.isActive = isActive;
        });

        this.teamDataSub = this.svc.getTeamData().subscribe(data => {
            if (data) {
                this.data = data;
            }
        });

    }

    ngOnInit() {
        if (!localStorage.getItem('sign')) {
            this.router.navigate(['sign-in']);
        }
    }

    ngOnDestroy() {
        if (this.teamDataSub) {
            this.teamDataSub.unsubscribe();
        }
        if (this.getTeamSub) {
            this.getTeamSub.unsubscribe();
        }
        if (this.teamRemoveSub) {
            this.teamRemoveSub.unsubscribe();
        }
        if (this.headerSub) {
            this.headerSub.unsubscribe();
        }
    }

    success(message: string) {
        this.alertService.success(message);
    }

    error(message: string) {
        this.alertService.error(message);
    }


    setPage() {
        this.router.navigate(['team']);
    }

    stopProp(e) {
        e.stopPropagation();
    }

    setWellDataPage(id, name) {
        this.headerSvc.setUrlParams(name);
        this.router.navigate(['team', id]);
    }

    deleteItem(name, id) {
        const dialogRef = this.dialog.open(DeleteDialogComponent, {
            width: '31%',
            data: name
        });

        this.dialogRefSub = dialogRef.afterClosed().subscribe(result => {
            if (result) {
                this.getRemoveTeamSub = this.getRemoveTeam.req(id, this.wsSvc).subscribe();
            }
        });
    }

}
