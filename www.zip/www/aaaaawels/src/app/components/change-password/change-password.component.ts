import {Component, OnDestroy, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {AlertService} from '../../services/alert.service';
import {HeaderService} from '../../services/header.service';
import {WsService} from '../../services/ws.service';
import {ActivatedRoute, Router} from '@angular/router';
import hexToBase64 from '../../constants/hexBase64';
import * as sha256 from 'sha256';
import {appConfig} from '../../constants/app.config';
import {LokiService} from '../../services/loki.service';

@Component({
    selector: 'app-change-password',
    templateUrl: './change-password.component.html',
    styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit, OnDestroy {
    public passEyeCurrentPass = true;
    public passEyePass = true;
    public passEyeConfirmPass = true;
    public changePassForm: FormGroup;
    public changePassSub: any;
    public changePassword: any;
    public changePasswordSub: any;

    constructor(private fb: FormBuilder,
                private headerSvc: HeaderService,
                private wsSvc: WsService,
                private router: Router,
                private alertService: AlertService,
                private lokiSrc: LokiService) {
        this.headerSvc.setUrlParams('Change Password');
        this.changePasswordSub = this.lokiSrc.returnCallSub().subscribe(coll => {
            this.changePassword = coll.by('name', 'changePassword');
        });
    }

    ngOnInit() {
        if (!localStorage.getItem('sign')) {
            this.router.navigate(['sign-in']);
        }
        this.initForm();
    }

    ngOnDestroy() {
        if (this.changePassSub) {
            this.changePassSub.unsubscribe();
        }
    }

    initForm() {
        this.changePassForm = this.fb.group({
            currentPassword: ['', [Validators.required, Validators.minLength(6)]],
            password: ['', [Validators.required, Validators.minLength(6)]],
            confirmPassword: ['', [Validators.required, Validators.minLength(6)]],
        });
    }

    get f() {
        return this.changePassForm.controls;
    }

    markFormGroupTouched(formGroup: FormGroup) {
        (<any>Object).values(formGroup.controls).forEach(control => {
            control.markAsTouched();

            if (control.controls) {
                this.markFormGroupTouched(control);
            }
        });
    }

    success(message: string) {
        this.alertService.success(message);
    }

    error(message: string) {
        this.alertService.error(message);
    }

    onSubmit() {
        this.markFormGroupTouched(this.changePassForm);

        if (this.changePassForm.valid && (this.changePassForm.get('confirmPassword').value === this.changePassForm.get('password').value)) {
            const data = {
                oldPassword: hexToBase64(sha256(this.changePassForm.value.currentPassword)),
                newPassword: hexToBase64(sha256(this.changePassForm.value.password))
            };
            this.changePassSub = this.changePassword.req(data, this.wsSvc).subscribe(res => {
                if (res.header.status === 4000) {
                    const sign = JSON.parse(localStorage.getItem('sign'));
                    localStorage.setItem('sign', JSON.stringify({
                        userName: sign.userName,
                        password: hexToBase64(sha256(this.changePassForm.value.password))
                    }));
                    this.router.navigate(['list/employee']);
                } else {
                    this.error(res.header.summary);
                }
                this.changePassSub.unsubscribe();
            });
        }
    }

}
