import {Component, OnDestroy, OnInit} from '@angular/core';
import {FormArray, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {LoadingService} from '../../../services/loading.service';
import {AddWellService} from '../add-well.service';
import {appConfig} from '../../../constants/app.config';
import {WsService} from '../../../services/ws.service';
import {Router} from '@angular/router';
import {AlertService} from '../../../services/alert.service';
import {saveAs} from 'file-saver';
import {DbService} from '../../../services/db.service';
import {OnlineService} from '../../../services/online.service';
import UID from '../../../constants/uid';
import {AccessLevel, FormType} from '../../../constants/app.enums';
import {MatSnackBar} from '@angular/material/snack-bar';
import {LokiService} from '../../../services/loki.service';

@Component({
    selector: 'app-w3a-form',
    templateUrl: './w3a-form.component.html',
    styleUrls: ['./w3a-form.component.scss']
})
export class W3aFormComponent implements OnInit, OnDestroy {
    public accessLevelEnum = AccessLevel;
    private typeOfWellSub: any;
    private hasNoticeOfIntentToPlugBeenSub: any;
    private anticipatedPluggingDateDataSub: any;
    private lngVal: any;
    private latVal: any;
    private wellId: string;
    private addWellSub: any;
    private insertW3ASub: any;

    public w3aForm: FormGroup;
    public formType = FormType;
    public sizes = [
        '1-1/2',
        '2',
        '2-1/16',
        '2-7/8',
        '3-1/2',
        '4',
        '4-1/2',
        '5',
        '5-1/2',
        '6-5/8',
        '7',
        '7-5/8',
        '8-5/8',
        '8-5/8 24#',
        '8-5/8 32#',
        '9-5/8',
        '10-3/4',
        '11',
        '11-3/4',
        '13-3/8',
        '16',
        '18-5/8',
        '20 Liner',
        '1-1/2 Liner',
        '2 Liner',
        '2-1/16 Liner',
        '2-7/8 Liner',
        '3-1/2 Liner',
        '4 Liner',
        '4-1/2 Liner',
        '5 Liner',
        '5-1/2 Liner',
        '6-5/8 Liner',
        '7 Liner',
        '7-5/8 Liner',
        '8-5/8 Liner',
        '8-5/8 24# Liner',
        '8-5/8 32# Liner',
        '9-5/8 Liner',
        '10-3/4 Liner',
        '11 Liner',
        '11-3/4 Liner',
        '13-3/8 Liner',
        '16 Liner',
        '18-5/8 Liner',
        '20 Liner'
    ];
    public drilledHoleSizes = [
        '3-3/4',
        '3-7/8',
        '4-1/4',
        '4-3/4',
        '4-5/8',
        '5-5/8',
        '6',
        '6-1/2',
        '6-1/4',
        '6-1/8',
        '6-3/4',
        '7-7/8',
        '8-1/2',
        '8-3/4',
        '8-5/8',
        '9-7/8',
        '11',
        '12-1/4',
        '14-1/2',
        '17-1/2'
    ];
    public accessLevel = appConfig.accessLevel;
    public successes = false;
    public mobileUser = appConfig.mobileUser;
    public isOnline: boolean;
    public transferSub: any;
    public dbReady: any;
    public autoSaveInterval: any;
    public transSub: any;
    public setTransfer: any;
    public insertW3A: any;
    public getWells: any;
    public selectW3A: any;
    public getWellsSub: any;
    public selectW3ASub: any;

    constructor(private fb: FormBuilder,
                private svc: WsService,
                private dbSvc: DbService,
                private router: Router,
                private isOnlineSvc: OnlineService,
                private addWellSvc: AddWellService,
                private alertService: AlertService,
                private snackBar: MatSnackBar,
                private loadingSvc: LoadingService,
                private lokiSvc: LokiService) {
        this.isOnlineSvc.getIsOnline().subscribe(isOnline => {
            this.isOnline = isOnline;
        });
        this.dbReady = this.dbSvc.getDbReady().subscribe(ready => {
            if (ready) {
                this.addWellSub = this.addWellSvc.getEditItemName().subscribe(id => {
                    if (id) {
                        this.wellId = id.split(' ').join('/');
                        setTimeout(() => {
                            this.dbSvc.openDatabase().then(() => {
                                this.dbSvc.getByIndex('w3a', 'wellId', this.wellId).then(
                                    w3a => {
                                        if (this.typeOfWellSub) {
                                            this.typeOfWellSub.unsubscribe();
                                        }
                                        if (this.hasNoticeOfIntentToPlugBeenSub) {
                                            this.hasNoticeOfIntentToPlugBeenSub.unsubscribe();
                                        }
                                        if (this.anticipatedPluggingDateDataSub) {
                                            this.anticipatedPluggingDateDataSub.unsubscribe();
                                        }
                                        if (w3a) {
                                            setTimeout(() => {
                                                this.initForm(w3a);
                                            });
                                        } else {
                                            this.initForm();
                                        }
                                    },
                                    error => {
                                    }
                                );
                            });
                        });
                    }
                });
            }
        });
        this.transSub = this.lokiSvc.returnCallSub().subscribe(coll => {
            if (coll) {
                this.setTransfer = coll.by('name', 'setTransferForm');
                this.insertW3A = coll.by('name', 'insertW3A');
                this.getWells = coll.by('name', 'getWell');
                this.selectW3A = coll.by('name', 'selectW3A');
            }
        });
    }

    ngOnInit() {
    }

    ngOnDestroy() {
        if (this.transSub) {
            this.transSub.unsubscribe();
        }
        if (this.autoSaveInterval) {
            clearInterval(this.autoSaveInterval);
        }
        if (this.selectW3ASub) {
            this.selectW3ASub.unsubscribe();
        }
        if (this.getWellsSub) {
            this.getWellsSub.unsubscribe();
        }
        if (this.typeOfWellSub) {
            this.typeOfWellSub.unsubscribe();
        }
        if (this.hasNoticeOfIntentToPlugBeenSub) {
            this.hasNoticeOfIntentToPlugBeenSub.unsubscribe();
        }
        if (this.anticipatedPluggingDateDataSub) {
            this.anticipatedPluggingDateDataSub.unsubscribe();
        }
        if (this.addWellSub) {
            this.addWellSub.unsubscribe();
        }
        if (this.insertW3ASub) {
            this.insertW3ASub.unsubscribe();
        }
        if (this.transferSub) {
            this.transferSub.unsubscribe();
        }
        if (this.dbReady) {
            this.dbReady.unsubscribe();
        }
    }

    initForm(item?) {
        if (this.autoSaveInterval) {
            clearInterval(this.autoSaveInterval);
        }
        this.successes = (item && (item.supervisorSign || item.managerSign));
        this.w3aForm = this.fb.group({
            assigneeAccessLevel: item && (item.assigneeAccessLevel || item.assigneeAccessLevel === 0) ?
                item.assigneeAccessLevel : this.accessLevel,
            status: [item ? item.status : null],
            supervisorSign: item ? item.supervisorSign : null,
            managerSign: item ? item.managerSign : null,
            wellId: [this.wellId],
            id: [item ? item.id : ''],
            operatorsNameAddress: [item ? item.operatorsNameAddress : ''],
            rrcOperatorNumber: [item ? item.rrcOperatorNumber : null],
            rrcDistrictNumber: [item ? item.rrcDistrictNumber : ''],
            countryWellSite: [item ? item.countryWellSite : ''],
            apiNumber: [item ? item.apiNumber : ''],
            drillingPermitNumber: [item ? item.drillingPermitNumber : ''],
            rule37CaseNumber: [item ? item.rule37CaseNumber : null],
            oilLeaseNumberOrGasWellIdNumber: [item ? item.oilLeaseNumberOrGasWellIdNumber : null],
            wellNumber: [item ? item.wellNumber : ''],
            fieldNameExactlyAsShownRrcRecords: [item ? item.fieldNameExactlyAsShownRrcRecords : ''],
            leaseName: [item ? item.leaseName : ''],
            location: this.fb.group({
                longitude: [item ? item.location.longitude : null, [Validators.min(-180), Validators.max(+180)]],
                latitude: [item ? item.location.latitude : null, [Validators.min(-90), Validators.max(+90)]],
            }),
            selectNumber: [item ? item.selectNumber : ''],
            blockNumber: [item ? item.blockNumber : ''],
            survey: [item ? item.survey : ''],
            number: [item ? item.number : ''],
            abstractNumber: [item ? item.abstractNumber : ''],
            distanceDirectionNearby: [item ? item.distanceDirectionNearby : ''],
            typeOfWell: [item ? item.typeOfWell : 0],
            otherTypeOfWell: (item && item.typeOfWell === 4) ? [item ? item.otherTypeOfWell : '', [Validators.required]] : '',
            typeOfCompletion: [item ? item.typeOfCompletion : 0],
            totalDepth: [item ? item.totalDepth : ''],
            depthOf: [item ? item.depthOf : null],
            from1: [item ? item.from1 : null],
            to1: [item ? item.to1 : null],
            from2: [item ? item.from2 : null],
            to2: [item ? item.to2 : null],
            stateDepthOfZone1: [item ? item.stateDepthOfZone1 : ''],
            stateDepthOfZone2: [item ? item.stateDepthOfZone2 : ''],
            casingRecord: item ? this.casingRecordFn(item.casingRecord) :
                this.fb.array([this.casingRecordFn()]),
            fieldPlugTimestamp: [(item && item.fieldPlugTimestamp) ? !!item.fieldPlugTimestamp : null],
            hasNoticeOfIntentToPlugBeenDate: [(item && item.fieldPlugTimestamp) ?
                new Date(+new Date(item.fieldPlugTimestamp)).toISOString().substring(0, 10) : '',
                (item && item.fieldPlugTimestamp) ? [Validators.required] : []],
            pluggingProposal: item ? this.pluggingProposalFn(item.pluggingProposal) : this.fb.array([this.pluggingProposalFn()]),
            recordPerforatedIntervals1: this.fb.group({
                perforations: [item ? item.recordPerforatedIntervals1.perforations : ''],
                open: [item ? item.recordPerforatedIntervals1.open : false],
                plugged: [item ? item.recordPerforatedIntervals1.plugged : false],
                pluggingMethod: [item ? item.recordPerforatedIntervals1.pluggingMethod : '']
            }),
            recordPerforatedIntervals2: this.fb.group({
                perforations: [item ? item.recordPerforatedIntervals2.perforations : ''],
                open: [item ? item.recordPerforatedIntervals2.open : false],
                plugged: [item ? item.recordPerforatedIntervals2.plugged : false],
                pluggingMethod: [item ? item.recordPerforatedIntervals2.pluggingMethod : '']
            }),
            recordPerforatedIntervals3: this.fb.group({
                perforations: [item ? item.recordPerforatedIntervals3.perforations : ''],
                open: [item ? item.recordPerforatedIntervals3.open : false],
                plugged: [item ? item.recordPerforatedIntervals3.plugged : false],
                pluggingMethod: [item ? item.recordPerforatedIntervals3.pluggingMethod : '']
            }),
            recordPerforatedIntervals4: this.fb.group({
                perforations: [item ? item.recordPerforatedIntervals4.perforations : ''],
                open: [item ? item.recordPerforatedIntervals4.open : false],
                plugged: [item ? item.recordPerforatedIntervals4.plugged : false],
                pluggingMethod: [item ? item.recordPerforatedIntervals4.pluggingMethod : '']
            }),
            nameAddressCementingCompany: [item ? item.nameAddressCementingCompany : ''],
            anticipatedPluggingDate: [(item && item.anticipatedPluggingDate) ? !!item.anticipatedPluggingDate : null],
            anticipatedPluggingDateData: [(item && item.anticipatedPluggingDate) ?
                new Date(+new Date(item.anticipatedPluggingDate)).toISOString().substring(0, 10) : '',
                (item && item.anticipatedPluggingDate) ? [Validators.required] : []]
        });
        setTimeout(() => {
            if (item && item.fieldPlugTimestamp) {
                this.w3aForm.get('hasNoticeOfIntentToPlugBeenDate').enable();
            } else {
                this.w3aForm.get('hasNoticeOfIntentToPlugBeenDate').disable();
            }
            if (item && item.typeOfWell === 4) {
                this.w3aForm.get('otherTypeOfWell').enable();
            } else {
                this.w3aForm.get('otherTypeOfWell').disable();
            }
            if (item && item.anticipatedPluggingDate) {
                this.w3aForm.get('anticipatedPluggingDateData').enable();
            } else {
                this.w3aForm.get('anticipatedPluggingDateData').disable();
            }
        });
        this.typeOfWellSub = this.w3aForm.get('typeOfWell').valueChanges.subscribe(value => {
            if (value === 4) {
                this.w3aForm.get('otherTypeOfWell').enable();
                this.w3aForm.get('otherTypeOfWell').setValidators(Validators.required);
                this.w3aForm.get('otherTypeOfWell').setErrors({'required': true});
            } else {
                this.w3aForm.get('otherTypeOfWell').setValue('');
                this.w3aForm.get('otherTypeOfWell').disable();
                this.w3aForm.get('otherTypeOfWell').setValidators(null);
                this.w3aForm.get('otherTypeOfWell').setErrors({'required': false});
            }
        });
        this.hasNoticeOfIntentToPlugBeenSub = this.w3aForm.get('fieldPlugTimestamp').valueChanges.subscribe(value => {
            if (value === null) {
                this.w3aForm.get('hasNoticeOfIntentToPlugBeenDate').setValue('');
                this.w3aForm.get('hasNoticeOfIntentToPlugBeenDate').disable();
                this.w3aForm.get('hasNoticeOfIntentToPlugBeenDate').setValidators(null);
                this.w3aForm.get('hasNoticeOfIntentToPlugBeenDate').setErrors({'required': false});
            } else {
                this.w3aForm.get('hasNoticeOfIntentToPlugBeenDate').enable();
                this.w3aForm.get('hasNoticeOfIntentToPlugBeenDate').setValidators(Validators.required);
                this.w3aForm.get('hasNoticeOfIntentToPlugBeenDate').setErrors({'required': true});
            }
        });
        this.anticipatedPluggingDateDataSub = this.w3aForm.get('anticipatedPluggingDate').valueChanges.subscribe(value => {
            if (value === null) {
                this.w3aForm.get('anticipatedPluggingDateData').setValue('');
                this.w3aForm.get('anticipatedPluggingDateData').disable();
                this.w3aForm.get('anticipatedPluggingDateData').setValidators(null);
                this.w3aForm.get('anticipatedPluggingDateData').setErrors({'required': false});
            } else {
                this.w3aForm.get('anticipatedPluggingDateData').enable();
                this.w3aForm.get('anticipatedPluggingDateData').setValidators(Validators.required);
                this.w3aForm.get('anticipatedPluggingDateData').setErrors({'required': true});
            }
        });
        this.loadingSvc.endLoading();
        if (this.accessLevel === this.f['assigneeAccessLevel'].value) {
            this.autoSaveInterval = setInterval(() => {
                this.onSubmit(0);
            }, 180000);
        } /*else {
            this.openSnackBar('Your autosave is not working because you do not have access to save', 'skip')
        }*/
    }

    openSnackBar(message: string, action: string) {
        this.snackBar.open(message, action);
    }

    setLngValue(event) {
        this.lngVal = event.target.value;
        this.checkLocationValidation();
    }

    setLatValue(event) {
        this.latVal = event.target.value;
        this.checkLocationValidation();
    }

    checkLocationValidation() {
        if (this.latVal && !this.lngVal) {
            this.w3aForm.get('location').get('longitude').setValidators([Validators.required, Validators.min(-180), Validators.max(+180)]);
            this.w3aForm.get('location').get('longitude').setErrors({'required': true});
            this.w3aForm.get('location').get('longitude').setErrors({'min': true});
            this.w3aForm.get('location').get('longitude').setErrors({'max': true});
        } else {
            if (!this.lngVal) {
                this.w3aForm.get('location').get('latitude').setValidators(null);
                this.w3aForm.get('location').get('latitude').setErrors({'required': false});
                this.w3aForm.get('location').get('longitude').setValidators(null);
                this.w3aForm.get('location').get('longitude').setErrors({'required': false});
            }
        }
        if (this.lngVal && !this.latVal) {
            this.w3aForm.get('location').get('latitude').setValidators([Validators.required, Validators.min(-90), Validators.max(+90)]);
            this.w3aForm.get('location').get('latitude').setErrors({'required': true});
            this.w3aForm.get('location').get('latitude').setErrors({'min': true});
            this.w3aForm.get('location').get('latitude').setErrors({'max': true});
        } else {
            if (!this.latVal) {
                this.w3aForm.get('location').get('latitude').setValidators(null);
                this.w3aForm.get('location').get('latitude').setErrors({'required': false});
                this.w3aForm.get('location').get('longitude').setValidators(null);
                this.w3aForm.get('location').get('longitude').setErrors({'required': false});
            }
        }
    }


    casingRecordFn(array?) {
        if (array) {
            const l = array.length;
            const arr = this.fb.array([]);
            for (let i = 0; i < l; i++) {
                arr.push(this.fb.group({
                    size: [array[i].size],
                    depth: [array[i].depth],
                    cement: [array[i].cement],
                    drilledHoleSize: [array[i].drilledHoleSize],
                    topOfCement: [array[i].topOfCement],
                    temperSurvey: [array[i].temperSurvey],
                    calculated: [array[i].calculated],
                    cementBondLog: [array[i].cementBondLog],
                    anticipatedCasingRecovery: [array[i].anticipatedCasingRecovery]
                }));
            }
            return arr;
        } else {
            return this.fb.group({
                size: [''],
                depth: [null],
                cement: [null],
                drilledHoleSize: [''],
                topOfCement: [''],
                temperSurvey: [false],
                calculated: [false],
                cementBondLog: [false],
                anticipatedCasingRecovery: ['']
            });
        }
    }

    pluggingProposalFn(array?) {
        if (array) {
            const l = array.length;
            const arr = this.fb.array([]);
            for (let i = 0; i < l; i++) {
                arr.push(this.fb.group({
                    numberOfSacks: [array[i].numberOfSacks],
                    depthInFeet: [array[i].depthInFeet]
                }));
            }
            return arr;
        } else {
            return this.fb.group({
                numberOfSacks: [null],
                depthInFeet: ['']
            });
        }
    }

    addCasingRecord() {
        const casingRecord = this.formData(this.w3aForm.get('casingRecord'));
        casingRecord.push(this.casingRecordFn());
    }

    deleteCasingRecord(index) {
        const casingRecord = this.formData(this.w3aForm.get('casingRecord'));
        casingRecord.removeAt(index);
    }

    addPluggingProposal() {
        const pluggingProposal = this.formData(this.w3aForm.get('pluggingProposal'));
        pluggingProposal.push(this.pluggingProposalFn());
    }

    deletePluggingProposal(index) {
        const pluggingProposal = this.formData(this.w3aForm.get('pluggingProposal'));
        pluggingProposal.removeAt(index);
    }

    formData(arr) {
        return <FormArray>arr;
    }

    get f() {
        return this.w3aForm.controls;
    }

    markFormGroupTouched(formGroup: FormGroup) {
        (<any>Object).values(formGroup.controls).forEach(control => {
            control.markAsTouched();

            if (control.controls) {
                this.markFormGroupTouched(control);
            }
        });
    }

    success(message: string) {
        this.alertService.success(message);
    }

    error(message: string) {
        this.alertService.error(message);
    }

    tableToExcel(name) {
        const casingRecordL = this.w3aForm.value.casingRecord.length;
        const casingRecord = this.w3aForm.value.casingRecord;
        let casingRecordElems = '';
        for (let i = 0; i < casingRecordL; i++) {
            casingRecordElems +=
                `<Row ss:AutoFitHeight="0" ss:Height="14.75">
        <Cell ss:StyleID="s163"><NamedCell ss:Name="Print_Area"/></Cell>
        <Cell ss:MergeAcross="1" ss:StyleID="s195"><Data ss:Type="String">${casingRecord[i].size ? casingRecord[i].size : ''}</Data><NamedCell
          ss:Name="Print_Area"/></Cell>
        <Cell ss:StyleID="s150"><Data ss:Type="String">set @</Data><NamedCell
          ss:Name="Print_Area"/></Cell>
        <Cell ss:MergeAcross="2" ss:StyleID="s124"><Data ss:Type="${casingRecord[i].depth !== null ? 'Number' : 'String'}">${casingRecord[i].depth ? casingRecord[i].depth : ''}</Data><NamedCell
          ss:Name="Print_Area"/></Cell>
        <Cell ss:StyleID="s197"><Data ss:Type="String">w/</Data><NamedCell
          ss:Name="Print_Area"/></Cell>
        <Cell ss:StyleID="s198"><Data ss:Type="${casingRecord[i].cement !== null ? 'Number' : 'String'}">${casingRecord[i].cement ? casingRecord[i].cement : ''}</Data><NamedCell
          ss:Name="Print_Area"/></Cell>
        <Cell ss:StyleID="s199"><NamedCell ss:Name="Print_Area"/></Cell>
        <Cell ss:MergeAcross="2" ss:StyleID="s195"><Data ss:Type="String">${casingRecord[i].drilledHoleSize ? casingRecord[i].drilledHoleSize : ''}</Data><NamedCell
          ss:Name="Print_Area"/></Cell>
        <Cell ss:StyleID="s199"><NamedCell ss:Name="Print_Area"/></Cell>
        <Cell ss:StyleID="s198"><Data ss:Type="String">${casingRecord[i].topOfCement ? casingRecord[i].topOfCement : ''}</Data><NamedCell
          ss:Name="Print_Area"/></Cell>
        <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
        <Cell ss:StyleID="s200"><Data ss:Type="String">${casingRecord[i].temperSurvey ? 'X' : ''}</Data><NamedCell
          ss:Name="Print_Area"/></Cell>
        <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
        <Cell ss:StyleID="s201"><NamedCell ss:Name="Print_Area"/></Cell>
        <Cell ss:StyleID="s202"><Data ss:Type="String">${casingRecord[i].calculated ? 'X' : ''}</Data><NamedCell
          ss:Name="Print_Area"/></Cell>
        <Cell ss:StyleID="s201"><NamedCell ss:Name="Print_Area"/></Cell>
        <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
        <Cell ss:StyleID="s203"><Data ss:Type="String">${casingRecord[i].cementBondLog ? 'X' : ''}</Data><NamedCell
          ss:Name="Print_Area"/></Cell>
        <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
        <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
        <Cell ss:MergeAcross="1" ss:StyleID="s124"><Data ss:Type="String">${casingRecord[i].anticipatedCasingRecovery ? casingRecord[i].anticipatedCasingRecovery : ''}</Data><NamedCell
          ss:Name="Print_Area"/></Cell>
        <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
        <Cell ss:Index="31" ss:StyleID="s70"/>
        <Cell ss:StyleID="s71"/>
       </Row>`;
        }
        const pluggingProposalL = this.w3aForm.value.pluggingProposal.length;
        const pluggingProposal = this.w3aForm.value.pluggingProposal;
        let pluggingProposalElems = '';
        for (let i = 0; i < pluggingProposalL; i++) {
            pluggingProposalElems += ``;
        }

        const template = `<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:html="http://www.w3.org/TR/REC-html40">
 <DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">
  <Created>2017-12-12T13:08:34Z</Created>
  <LastSaved>2019-02-16T07:42:32Z</LastSaved>
  <Version>16.00</Version>
 </DocumentProperties>
 <OfficeDocumentSettings xmlns="urn:schemas-microsoft-com:office:office">
  <AllowPNG/>
  <RemovePersonalInformation/>
  <Colors>
   <Color>
    <Index>16</Index>
    <RGB>#8080FF</RGB>
   </Color>
   <Color>
    <Index>17</Index>
    <RGB>#802060</RGB>
   </Color>
   <Color>
    <Index>18</Index>
    <RGB>#FFFFC0</RGB>
   </Color>
   <Color>
    <Index>19</Index>
    <RGB>#A0E0E0</RGB>
   </Color>
   <Color>
    <Index>20</Index>
    <RGB>#600080</RGB>
   </Color>
   <Color>
    <Index>22</Index>
    <RGB>#0080C0</RGB>
   </Color>
   <Color>
    <Index>23</Index>
    <RGB>#C0C0FF</RGB>
   </Color>
   <Color>
    <Index>33</Index>
    <RGB>#69FFFF</RGB>
   </Color>
   <Color>
    <Index>36</Index>
    <RGB>#A6CAF0</RGB>
   </Color>
   <Color>
    <Index>37</Index>
    <RGB>#CC9CCC</RGB>
   </Color>
   <Color>
    <Index>39</Index>
    <RGB>#E3E3E3</RGB>
   </Color>
   <Color>
    <Index>42</Index>
    <RGB>#339933</RGB>
   </Color>
   <Color>
    <Index>43</Index>
    <RGB>#999933</RGB>
   </Color>
   <Color>
    <Index>44</Index>
    <RGB>#996633</RGB>
   </Color>
   <Color>
    <Index>45</Index>
    <RGB>#996666</RGB>
   </Color>
   <Color>
    <Index>48</Index>
    <RGB>#3333CC</RGB>
   </Color>
   <Color>
    <Index>49</Index>
    <RGB>#336666</RGB>
   </Color>
   <Color>
    <Index>52</Index>
    <RGB>#663300</RGB>
   </Color>
   <Color>
    <Index>55</Index>
    <RGB>#424242</RGB>
   </Color>
  </Colors>
 </OfficeDocumentSettings>
 <ExcelWorkbook xmlns="urn:schemas-microsoft-com:office:excel">
  <WindowHeight>18000</WindowHeight>
  <WindowWidth>28800</WindowWidth>
  <WindowTopX>32767</WindowTopX>
  <WindowTopY>32767</WindowTopY>
  <ProtectStructure>False</ProtectStructure>
  <ProtectWindows>False</ProtectWindows>
 </ExcelWorkbook>
 <Styles>
  <Style ss:ID="Default" ss:Name="Normal">
   <Alignment ss:Vertical="Bottom"/>
   <Borders/>
   <Font ss:FontName="Arial"/>
   <Interior/>
   <NumberFormat/>
   <Protection/>
  </Style>
  <Style ss:ID="m105553158800232">
   <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="m105553158800420">
   <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="11" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="m105553158800500">
   <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="m105553158811860">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="m105553158811900">
   <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="11" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="m105553158811940">
   <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="11" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="m105553158803124">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="m105553158803164">
   <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="11" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="m105553158803204">
   <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="11" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="m105553158802916">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="m105553158802956">
   <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="11" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="m105553158802996">
   <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="11" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="m105553158803352">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="m105553158803392">
   <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="11" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="m105553158803432">
   <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="11" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="m105553158809572">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="m105553158809592">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="m105553158809612">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="m105553158809632">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="m105553158895860">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <NumberFormat ss:Format="@"/>
   <Protection/>
  </Style>
  <Style ss:ID="m105553158895880">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="m105553158895900">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"/>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="m105553158895920">
   <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"/>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s62">
   <Font ss:FontName="Arial" x:Family="Swiss"/>
  </Style>
  <Style ss:ID="s63">
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <NumberFormat/>
  </Style>
  <Style ss:ID="s64">
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="14" ss:Color="#FF0000"
    ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s65">
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#FF0000"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s66">
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s67">
   <Alignment ss:Horizontal="CenterAcrossSelection" ss:Vertical="Bottom"/>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s68">
   <Alignment ss:Horizontal="CenterAcrossSelection" ss:Vertical="Bottom"/>
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s69">
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="18" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s70">
   <Borders/>
   <Font ss:FontName="Arial" x:Family="Swiss"/>
  </Style>
  <Style ss:ID="s71">
   <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
   <Borders/>
   <Font ss:FontName="Arial" x:Family="Swiss"/>
  </Style>
  <Style ss:ID="s72">
   <Alignment ss:Vertical="Top"/>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s73">
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s74">
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s75">
   <Alignment ss:Vertical="Top"/>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s76">
   <Alignment ss:Horizontal="CenterAcrossSelection" ss:Vertical="Bottom"/>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s77">
   <Borders>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s78">
   <Alignment ss:Vertical="Center"/>
   <Borders>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s79">
   <Borders>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s80">
   <Borders>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s81">
   <Alignment ss:Vertical="Center"/>
   <Borders>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s82">
   <Alignment ss:Vertical="Center"/>
   <Borders>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s83">
   <Alignment ss:Vertical="Center"/>
   <Borders>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s84">
   <Borders>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s86">
   <Alignment ss:Horizontal="Center" ss:Vertical="Center" ss:WrapText="1"/>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s98">
   <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
   <Borders/>
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <NumberFormat ss:Format="mm/dd/yy_)"/>
   <Protection/>
  </Style>
  <Style ss:ID="s99">
   <Alignment ss:Vertical="Center"/>
   <Borders>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s100">
   <Alignment ss:Vertical="Center"/>
   <Borders>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s101">
   <Alignment ss:Vertical="Center"/>
   <Borders>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s102">
   <Borders>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s116">
   <Alignment ss:Horizontal="Right" ss:Vertical="Bottom"/>
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <NumberFormat/>
  </Style>
  <Style ss:ID="s117">
   <Alignment ss:Vertical="Center"/>
   <Borders>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s118">
   <Alignment ss:Vertical="Center"/>
   <Borders/>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s119">
   <Alignment ss:Vertical="Center"/>
   <Borders>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s120">
   <Borders>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s121">
   <Borders>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s122">
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s123">
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s124">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s126">
   <Alignment ss:Horizontal="CenterAcrossSelection" ss:Vertical="Bottom"/>
   <Borders/>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s127">
   <Alignment ss:Vertical="Center"/>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s128">
   <Alignment ss:Vertical="Center"/>
   <Borders>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s129">
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
  </Style>
  <Style ss:ID="s130">
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s133">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s145">
   <Borders>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s146">
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s148">
   <Alignment ss:Horizontal="Center" ss:Vertical="Center" ss:WrapText="1"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s150">
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s151">
   <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s153">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
  </Style>
  <Style ss:ID="s155">
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s156">
   <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s157">
   <Borders>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s158">
   <Borders>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s160">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Color="#000000"
    ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s162">
   <Borders>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s163">
   <Borders>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s164">
   <Borders>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s165">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"/>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s166">
   <Alignment ss:Horizontal="CenterAcrossSelection" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"/>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s168">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders/>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="11" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s169">
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s170">
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s171">
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s172">
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s173">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s175">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s178">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s180">
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s181">
   <Borders>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s182">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s183">
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s184">
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s185">
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s186">
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s187">
   <Borders>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s188">
   <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s189">
   <Borders>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s191">
   <Borders>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s193">
   <Alignment ss:Horizontal="Left" ss:Vertical="Top"/>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s195">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <NumberFormat ss:Format="#\\ ?/?"/>
   <Protection/>
  </Style>
  <Style ss:ID="s197">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s198">
   <Alignment ss:Horizontal="CenterAcrossSelection" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s199">
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s200">
   <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s201">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders/>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s202">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s203">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s207">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <NumberFormat ss:Format="@"/>
   <Protection/>
  </Style>
  <Style ss:ID="s210">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s212">
   <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <NumberFormat ss:Format="#\\ ?/?"/>
   <Protection/>
  </Style>
  <Style ss:ID="s214">
   <Borders>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s215">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s218">
   <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <NumberFormat ss:Format="@"/>
   <Protection/>
  </Style>
  <Style ss:ID="s220">
   <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s221">
   <Alignment ss:Horizontal="CenterAcrossSelection" ss:Vertical="Bottom"/>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s222">
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Color="#FF0000"
    ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s223">
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="9" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s224">
   <Alignment ss:Horizontal="Right" ss:Vertical="Top"/>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s225">
   <Alignment ss:Horizontal="CenterAcrossSelection" ss:Vertical="Top"/>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s226">
   <Alignment ss:Horizontal="CenterAcrossSelection" ss:Vertical="Bottom"/>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s227">
   <Alignment ss:Horizontal="CenterAcrossSelection" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s230">
   <Alignment ss:Horizontal="Right" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s235">
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Color="#FF0000"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s240">
   <Alignment ss:Vertical="Bottom"/>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s241">
   <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
   <Borders/>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s242">
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s243">
   <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
   <Borders/>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="11" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s244">
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s245">
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="11" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s246">
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s247">
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s248">
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s249">
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s251">
   <Alignment ss:Horizontal="Center" ss:Vertical="Center" ss:WrapText="1"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s252">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s253">
   <Borders>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s254">
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s255">
   <Borders>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
    <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s257">
   <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
  </Style>
  <Style ss:ID="s266">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
    <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s268">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <NumberFormat ss:Format="@"/>
   <Protection/>
  </Style>
  <Style ss:ID="s272">
   <Font ss:FontName="Arial" x:Family="Swiss"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <NumberFormat ss:Format="@"/>
   <Protection/>
  </Style>
  <Style ss:ID="s273">
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="24"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s275">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"
     ss:Color="#000000"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s277">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
   </Borders>
   <Font ss:FontName="Arial" x:Family="Swiss" ss:Bold="1"/>
   <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
   <Protection/>
  </Style>
  <Style ss:ID="s279">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom" ss:WrapText="1"/>
   <Font ss:FontName="Consolas" x:Family="Swiss" ss:Size="11.5" ss:Color="#000000"/>
  </Style>
 </Styles>
 <Worksheet ss:Name="Sheet1">
  <Names>
   <NamedRange ss:Name="Print_Area" ss:RefersTo="=Sheet1!R1C1:R69C28"/>
  </Names>
  <Table ss:ExpandedColumnCount="32" ss:ExpandedRowCount="99" x:FullColumns="1"
   x:FullRows="1" ss:StyleID="s62" ss:DefaultColumnWidth="75"
   ss:DefaultRowHeight="13">
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="18"/>
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="51"/>
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="33"/>
   <Column ss:StyleID="s62" ss:Width="25"/>
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="29"/>
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="45"/>
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="27"/>
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="24"/>
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="45"/>
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="21" ss:Span="1"/>
   <Column ss:Index="12" ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="55"/>
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="25"/>
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="23"/>
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="46"/>
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="34"/>
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="26"/>
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="38"/>
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="21"/>
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="25"/>
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="22"/>
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="15"/>
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="27"/>
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="15" ss:Span="1"/>
   <Column ss:Index="26" ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="45"/>
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="27"/>
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="60"/>
   <Column ss:Index="30" ss:StyleID="s63" ss:AutoFitWidth="0"/>
   <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="124"/>
   <Row ss:AutoFitHeight="0" ss:Height="22.75">
    <Cell ss:StyleID="s64"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s65"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s67"><Data ss:Type="String">RAILROAD COMMISSION OF TEXAS</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s69"><Data ss:Type="String">Form W-3A</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16">
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s67"><Data ss:Type="String">Oil and Gas Division</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s72"><Data ss:Type="String">Rev.1/1/83</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16">
    <Cell ss:StyleID="s73"><Data ss:Type="String">Type or print only</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s74"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s74"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s74"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s74"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s67"><Data ss:Type="String">Notice of Intention to Plug and Abandon</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s75"><Data ss:Type="String">483-024</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0">
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16">
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s76"><Data ss:Type="String">Operators must comply with RRC plugging procedures as outlined on the reverse side.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="14">
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0">
    <Cell ss:StyleID="s77"><Data ss:Type="String">1.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s78"><Data ss:Type="String">Operator's Name and Address (Exactly as shown on Form P-5, Organization Report)</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s80"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s81"><Data ss:Type="String"> 3. RRC District No.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s82"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s82"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s82"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s83"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s81"><Data ss:Type="String">  4. Country of Well Site</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s82"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s82"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s82"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s82"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s82"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s82"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s80"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="17">
    <Cell ss:StyleID="s84"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="13" ss:MergeDown="2" ss:StyleID="s86"><Data
      ss:Type="String">${this.w3aForm.value.operatorsNameAddress}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="4" ss:StyleID="m105553158895860"><Data ss:Type="String"
      x:Ticked="1">${this.w3aForm.value.rrcDistrictNumber}</Data><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="7" ss:StyleID="m105553158895880"><Data ss:Type="String">${this.w3aForm.value.countryWellSite}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s98"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16">
    <Cell ss:StyleID="s84"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="16" ss:StyleID="s99"><Data ss:Type="String">5. API No.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s100"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s100"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s100"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s100"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s101"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s99"><Data ss:Type="String">6. Drilling Permit No.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s100"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s100"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s100"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s100"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s100"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s102"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s98"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16">
    <Cell ss:StyleID="s84"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="16" ss:MergeAcross="5" ss:StyleID="m105553158895900"><Data
      ss:Type="String">${this.w3aForm.value.apiNumber}</Data><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="6" ss:StyleID="m105553158895920"><Data ss:Type="String">${this.w3aForm.value.drillingPermitNumber}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="30" ss:StyleID="s116"/>
    <Cell ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0">
    <Cell ss:StyleID="s84"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s81"><Data ss:Type="String">7. Rule 37 Case No.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s80"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s117"><Data ss:Type="String">8. Oil Lease No. or</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s118"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s118"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s118"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s119"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s117"><Data ss:Type="String">9. Well No.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s118"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s118"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s118"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s118"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s118"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="30" ss:StyleID="s116"/>
    <Cell ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="15.25">
    <Cell ss:StyleID="s121"><Data ss:Type="String">2.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s122"><Data ss:Type="String">RRC Operator Number</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="2" ss:StyleID="s124"><Data ss:Type="${this.w3aForm.value.rrcOperatorNumber ? 'Number' : 'String'}">${this.w3aForm.value.rrcOperatorNumber ? this.w3aForm.value.rrcOperatorNumber : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s84"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s126"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s75"><Data ss:Type="String">Gas Well ID No.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s127"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s127"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s127"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s127"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s119"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s128"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s127"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s127"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s127"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s129"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s127"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="30" ss:StyleID="s116"/>
    <Cell ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="14.75">
    <Cell ss:StyleID="s84"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="4" ss:StyleID="s133"><Data ss:Type="${this.w3aForm.value.rule37CaseNumber ? 'Number' : 'String'}" x:Ticked="1">${this.w3aForm.value.rule37CaseNumber ? this.w3aForm.value.rule37CaseNumber : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="5" ss:StyleID="m105553158809572"><Data ss:Type="${this.w3aForm.value.oilLeaseNumberOrGasWellIdNumber ? 'Number' : 'String'}"
      x:Ticked="1">${this.w3aForm.value.oilLeaseNumberOrGasWellIdNumber ? this.w3aForm.value.oilLeaseNumberOrGasWellIdNumber : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="6" ss:StyleID="m105553158809592"><Data ss:Type="String">${this.w3aForm.value.wellNumber}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0">
    <Cell ss:StyleID="s81"><Data ss:Type="String">10. Field Name (Exactly as shown on RRC records)</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s82"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s82"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s82"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s82"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s82"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s82"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s82"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s82"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s81"><Data ss:Type="String">11. Lease Name</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s80"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="17">
    <Cell ss:MergeAcross="11" ss:StyleID="m105553158809612"><Data ss:Type="String">${this.w3aForm.value.fieldNameExactlyAsShownRrcRecords}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="15" ss:StyleID="m105553158809632"><Data ss:Type="String">${this.w3aForm.value.leaseName}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0">
    <Cell ss:StyleID="s77"><Data ss:Type="String">12. Location</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><Data ss:Type="String">DATUM 83   X-LOG -${this.w3aForm.value.location.longitude ? this.w3aForm.value.location.longitude : ''}     Y-LAT - ${this.w3aForm.value.location.latitude ? this.w3aForm.value.location.latitude : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16">
    <Cell ss:StyleID="s84"><Data ss:Type="String">      .</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">Section No.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="1" ss:StyleID="s148"><Data ss:Type="String">${this.w3aForm.value.selectNumber}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">Block No.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="2" ss:StyleID="s124"><Data ss:Type="String">${this.w3aForm.value.blockNumber}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">Survey</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="4" ss:StyleID="s124"><Data ss:Type="String">${this.w3aForm.value.survey}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">No.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="2" ss:StyleID="s124"><Data ss:Type="String">${this.w3aForm.value.number}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">Abstract No.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="2" ss:StyleID="s124"><Data ss:Type="String">${this.w3aForm.value.abstractNumber}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16">
    <Cell ss:StyleID="s84"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">Distance (in miles) and direction from a nearby town in this country (name the town).</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s151"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="11" ss:StyleID="s153"><Data ss:Type="String">${this.w3aForm.value.distanceDirectionNearby}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="4">
    <Cell ss:StyleID="s155"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0">
    <Cell ss:StyleID="s156"><Data ss:Type="String">13. Type of well</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s158"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s77"><Data ss:Type="String">14. Type of completion</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s77"><Data ss:Type="String">15. Total depth</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s80"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16">
    <Cell ss:StyleID="s121"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">1. oil</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">3. disposal</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">5 - other (specify)</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="4" ss:StyleID="s160"><Data ss:Type="String">${this.w3aForm.value.otherTypeOfWell ? this.w3aForm.value.otherTypeOfWell : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s162"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s163"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s164"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s122"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16">
    <Cell ss:StyleID="s121"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">2. gas</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">4. injection</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">Enter appropriate no. in box</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s165"><Data ss:Type="String">${this.w3aForm.value.typeOfWell + 1}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s162"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s121"><Data ss:Type="String">Single</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s166"><Data ss:Type="String">${!this.w3aForm.value.typeOfCompletion ? 'X' : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">  Multiple</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s166"><Data ss:Type="String">${this.w3aForm.value.typeOfCompletion ? 'X' : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s163"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="1" ss:StyleID="s168"><Data ss:Type="String">${this.w3aForm.value.totalDepth}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s71"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="4">
    <Cell ss:StyleID="s169"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s171"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s169"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s169"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s172"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s71"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0">
    <Cell ss:StyleID="s77"><Data ss:Type="String">16. Usable-quality water strata  (as determined by the Texas Dept. of Water Resources)  occur to a</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s80"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s71"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16">
    <Cell ss:StyleID="s163"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">depth of </Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="2" ss:StyleID="s124"><Data ss:Type="${this.w3aForm.value.depthOf ? 'Number' : 'String'}">${this.w3aForm.value.depthOf ? this.w3aForm.value.depthOf : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">feet and in deeper strata from</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="1" ss:StyleID="s124"><Data ss:Type="${this.w3aForm.value.from1 ? 'Number' : 'String'}">${this.w3aForm.value.from1 ? this.w3aForm.value.from1 : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s173"><Data ss:Type="String">to</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="1" ss:StyleID="s124"><Data ss:Type="${this.w3aForm.value.to1 ? 'Number' : 'String'}">${this.w3aForm.value.to1 ? this.w3aForm.value.to1 : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">feet; and from</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="2" ss:StyleID="s124"><Data ss:Type="${this.w3aForm.value.from2 ? 'Number' : 'String'}">${this.w3aForm.value.from2 ? this.w3aForm.value.from2 : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">to</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="2" ss:StyleID="s124"><Data ss:Type="${this.w3aForm.value.to2 ? 'Number' : 'String'}">${this.w3aForm.value.to2 ? this.w3aForm.value.to2 : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">feet.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s71"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="4">
    <Cell ss:StyleID="s169"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s172"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s71"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16">
    <Cell ss:StyleID="s156"><Data ss:Type="String">17.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><Data ss:Type="String">If there are wells in this area which are producing from or have produced from a shallower zone, state depth of zone</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="4" ss:StyleID="s175"><Data ss:Type="String">${this.w3aForm.value.stateDepthOfZone1}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s80"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s71"/>
    <Cell ss:StyleID="s98"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16">
    <Cell ss:StyleID="s163"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">If there are wells into which salt water is being or has been disposed of into a shallower zone, state depth of zone</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="4" ss:StyleID="s178"><Data ss:Type="String">${this.w3aForm.value.stateDepthOfZone2}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="5">
    <Cell ss:StyleID="s163"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s180"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s180"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s180"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s180"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s180"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16">
    <Cell ss:StyleID="s77"><Data ss:Type="String">18. Casing record (list all casing in well)</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s181"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s182"><Data ss:Type="String">Drilled </Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s181"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s181"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s182"><Data ss:Type="String">Top</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s183"><Data ss:Type="String">Top of cement determined by:</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s184"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s185"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s185"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s185"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s185"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s185"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s185"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s186"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><Data ss:Type="String">     Anticipated</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s80"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="14.75">
    <Cell ss:StyleID="s121"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s173"><Data ss:Type="String">hole </Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s173"><Data ss:Type="String">of</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s187"><Data ss:Type="String">        Temper.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s188"><Data ss:Type="String">Cement </Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s189"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">        casing </Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="14.75">
    <Cell ss:StyleID="s121"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">Size (inches)</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">Depth (feet)</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">Cement</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s173"><Data ss:Type="String">size (inches)</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s173"><Data ss:Type="String">Cement</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s187"><Data ss:Type="String">        Survey</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">Calculated</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s188"><Data ss:Type="String" x:Ticked="1">   bond</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s189"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">       recovery</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s71"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="14.75">
    <Cell ss:StyleID="s121"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s75"><Data ss:Type="String">(sacks)</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s173"><Data ss:Type="String">(feet)</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s191"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s193"><Data ss:Type="String" x:Ticked="1">     log</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s189"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s75"><Data ss:Type="String">          (feet)</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   ${casingRecordElems}
   <Row ss:AutoFitHeight="0" ss:Height="4">
    <Cell ss:StyleID="s163"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0">
    <Cell ss:StyleID="s156"><Data ss:Type="String">19. Has notice of intent to plug been filed previously for this well?</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s158"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s77"><Data ss:Type="String">20.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><Data ss:Type="String">Plugging proposal (List all bridge and cement plugs.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s80"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="12">
    <Cell ss:StyleID="s84"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s214"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">Load the hole with at least 9.5 lbs. per gallon mud.) </Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s122"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s122"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s122"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s122"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s122"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s122"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s122"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="15.75">
    <Cell ss:StyleID="s84"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s215"><Data ss:Type="String">${this.w3aForm.value.fieldPlugTimestamp ? 'X' : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s122"><Data ss:Type="String">   Yes</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="2" ss:StyleID="s218"><Data ss:Type="String" x:Ticked="1">${this.w3aForm.value.fieldPlugTimestamp ? ('0' + (new Date(this.w3aForm.value.hasNoticeOfIntentToPlugBeenDate).getMonth() + 1)).slice(-2) + '/' + new Date(this.w3aForm.value.hasNoticeOfIntentToPlugBeenDate).getDate() + '/' + new Date(this.w3aForm.value.hasNoticeOfIntentToPlugBeenDate).getFullYear() : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s220"><Data ss:Type="String">${!this.w3aForm.value.fieldPlugTimestamp ? 'X' : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s122"><Data ss:Type="String">    No</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s84"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="12">
    <Cell ss:StyleID="s84"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s221"><Data ss:Type="String">mo/day/yr</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s221"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s221"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s84"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s122"><Data ss:Type="String">P&amp;S: DENOTES PERF &amp; SQZ IF CASING NOT PULLED</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="12">
    <Cell ss:StyleID="s155"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s172"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s84"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">No. of sacks</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s122"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s122"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s122"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s146"><Data ss:Type="String">Depth in feet (top &amp; bottom)</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s122"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s122"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s122"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s122"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s122"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s71"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16">
    <Cell ss:StyleID="s156"><Data ss:Type="String">21.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><Data ss:Type="String">Record of perforated intervals or open hole.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s158"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s164"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s222"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s223"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16">
    <Cell ss:StyleID="s163"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s75"><Data ss:Type="String">Perforations</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s129"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s224"><Data ss:Type="String">Open</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s75"><Data ss:Type="String">           Plugged</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s225"><Data ss:Type="String">Plugging method</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s68"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s226"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s227"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s84"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16">
    <Cell ss:StyleID="s163"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="4" ss:StyleID="s124"><Data ss:Type="String">${this.w3aForm.value.recordPerforatedIntervals1.perforations}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s202"><Data ss:Type="String">${this.w3aForm.value.recordPerforatedIntervals1.open ? 'X' : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s202"><Data ss:Type="String">${this.w3aForm.value.recordPerforatedIntervals1.plugged ? 'X' : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="3" ss:StyleID="m105553158803352"><Data ss:Type="String">${this.w3aForm.value.recordPerforatedIntervals1.pluggingMethod}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s230"><Data ss:Type="String">1.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="2" ss:StyleID="s124"><Data ss:Type="${this.w3aForm.value.pluggingProposal[0] && this.w3aForm.value.pluggingProposal[0].numberOfSacks ? 'Number' : 'String'}">${this.w3aForm.value.pluggingProposal[0] && this.w3aForm.value.pluggingProposal[0].numberOfSacks ? this.w3aForm.value.pluggingProposal[0].numberOfSacks : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="6" ss:StyleID="m105553158803392"><Data ss:Type="String">${this.w3aForm.value.pluggingProposal[0] && this.w3aForm.value.pluggingProposal[0].depthInFeet ? this.w3aForm.value.pluggingProposal[0].depthInFeet : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16">
    <Cell ss:StyleID="s163"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s199"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s162"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s230"><Data ss:Type="String">2.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s235"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="2" ss:StyleID="s124"><Data ss:Type="${this.w3aForm.value.pluggingProposal[1] && this.w3aForm.value.pluggingProposal[1].numberOfSacks ? 'Number' : 'String'}">${this.w3aForm.value.pluggingProposal[1] && this.w3aForm.value.pluggingProposal[1].numberOfSacks ? this.w3aForm.value.pluggingProposal[1].numberOfSacks : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="6" ss:StyleID="m105553158803432"><Data ss:Type="String">${this.w3aForm.value.pluggingProposal[1] && this.w3aForm.value.pluggingProposal[1].depthInFeet ? this.w3aForm.value.pluggingProposal[1].depthInFeet : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16">
    <Cell ss:StyleID="s163"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="4" ss:StyleID="s124"><Data ss:Type="String">${this.w3aForm.value.recordPerforatedIntervals2.perforations}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s202"><Data ss:Type="String">${this.w3aForm.value.recordPerforatedIntervals2.open ? 'X' : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s202"><Data ss:Type="String">${this.w3aForm.value.recordPerforatedIntervals2.plugged ? 'X' : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="3" ss:StyleID="m105553158802916"><Data ss:Type="String">${this.w3aForm.value.recordPerforatedIntervals2.pluggingMethod}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s230"><Data ss:Type="String">3.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s235"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="2" ss:StyleID="s124"><Data ss:Type="${this.w3aForm.value.pluggingProposal[2] && this.w3aForm.value.pluggingProposal[2].numberOfSacks ? 'Number' : 'String'}">${this.w3aForm.value.pluggingProposal[2] && this.w3aForm.value.pluggingProposal[2].numberOfSacks ? this.w3aForm.value.pluggingProposal[2].numberOfSacks : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="6" ss:StyleID="m105553158802956"><Data ss:Type="String">${this.w3aForm.value.pluggingProposal[2] && this.w3aForm.value.pluggingProposal[2].depthInFeet ? this.w3aForm.value.pluggingProposal[2].depthInFeet : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16">
    <Cell ss:StyleID="s163"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s199"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s240"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s162"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s230"><Data ss:Type="String">4.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s222"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="2" ss:StyleID="s124"><Data ss:Type="${this.w3aForm.value.pluggingProposal[3] && this.w3aForm.value.pluggingProposal[3].numberOfSacks ? 'Number' : 'String'}">${this.w3aForm.value.pluggingProposal[3] && this.w3aForm.value.pluggingProposal[3].numberOfSacks ? this.w3aForm.value.pluggingProposal[3].numberOfSacks : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="6" ss:StyleID="m105553158802996"><Data ss:Type="String">${this.w3aForm.value.pluggingProposal[3] && this.w3aForm.value.pluggingProposal[3].depthInFeet ? this.w3aForm.value.pluggingProposal[3].depthInFeet : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s71"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16.5">
    <Cell ss:StyleID="s163"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="4" ss:StyleID="s124"><Data ss:Type="String">${this.w3aForm.value.recordPerforatedIntervals3.perforations}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s202"><Data ss:Type="String">${this.w3aForm.value.recordPerforatedIntervals3.open ? 'X' : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s202"><Data ss:Type="String">${this.w3aForm.value.recordPerforatedIntervals3.plugged ? 'X' : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="3" ss:StyleID="m105553158803124"><Data ss:Type="String">${this.w3aForm.value.recordPerforatedIntervals3.pluggingMethod}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s230"><Data ss:Type="String">5.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s222"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="2" ss:StyleID="s124"><Data ss:Type="${this.w3aForm.value.pluggingProposal[4] && this.w3aForm.value.pluggingProposal[4].numberOfSacks ? 'Number' : 'String'}">${this.w3aForm.value.pluggingProposal[4] && this.w3aForm.value.pluggingProposal[4].numberOfSacks ? this.w3aForm.value.pluggingProposal[4].numberOfSacks : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="6" ss:StyleID="m105553158803164"><Data ss:Type="String">${this.w3aForm.value.pluggingProposal[4] && this.w3aForm.value.pluggingProposal[4].depthInFeet ? this.w3aForm.value.pluggingProposal[4].depthInFeet : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16">
    <Cell ss:StyleID="s163"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s75"><Data ss:Type="String">Open Hole</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s162"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s230"><Data ss:Type="String">6.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s129"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="2" ss:StyleID="s124"><Data ss:Type="${this.w3aForm.value.pluggingProposal[5] && this.w3aForm.value.pluggingProposal[5].numberOfSacks ? 'Number' : 'String'}">${this.w3aForm.value.pluggingProposal[5] && this.w3aForm.value.pluggingProposal[5].numberOfSacks ? this.w3aForm.value.pluggingProposal[5].numberOfSacks : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="6" ss:StyleID="m105553158803204"><Data ss:Type="String">${this.w3aForm.value.pluggingProposal[5] && this.w3aForm.value.pluggingProposal[5].depthInFeet ? this.w3aForm.value.pluggingProposal[5].depthInFeet : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16">
    <Cell ss:StyleID="s163"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="4" ss:StyleID="s124"><Data ss:Type="String">${this.w3aForm.value.recordPerforatedIntervals4.perforations}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s202"><Data ss:Type="String">${this.w3aForm.value.recordPerforatedIntervals4.open ? 'X' : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s202"><Data ss:Type="String">${this.w3aForm.value.recordPerforatedIntervals4.plugged ? 'X' : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="3" ss:StyleID="m105553158811860"><Data ss:Type="String">${this.w3aForm.value.recordPerforatedIntervals4.pluggingMethod}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s230"><Data ss:Type="String">7.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s129"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="2" ss:StyleID="s124"><Data ss:Type="${this.w3aForm.value.pluggingProposal[6] && this.w3aForm.value.pluggingProposal[6].numberOfSacks ? 'Number' : 'String'}">${this.w3aForm.value.pluggingProposal[6] && this.w3aForm.value.pluggingProposal[6].numberOfSacks ? this.w3aForm.value.pluggingProposal[6].numberOfSacks : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s241"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="6" ss:StyleID="m105553158811900"><Data ss:Type="String">${this.w3aForm.value.pluggingProposal[6] && this.w3aForm.value.pluggingProposal[6].depthInFeet ? this.w3aForm.value.pluggingProposal[6].depthInFeet : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="17">
    <Cell ss:StyleID="s169"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s242"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s242"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s242"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s242"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s170"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s171"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s230"><Data ss:Type="String">8.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s129"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="2" ss:StyleID="s124"><Data ss:Type="${this.w3aForm.value.pluggingProposal[7] && this.w3aForm.value.pluggingProposal[7].numberOfSacks ? 'Number' : 'String'}">${this.w3aForm.value.pluggingProposal[7] && this.w3aForm.value.pluggingProposal[7].numberOfSacks ? this.w3aForm.value.pluggingProposal[7].numberOfSacks : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s241"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="6" ss:StyleID="m105553158811940"><Data ss:Type="String">${this.w3aForm.value.pluggingProposal[7] && this.w3aForm.value.pluggingProposal[7].depthInFeet ? this.w3aForm.value.pluggingProposal[7].depthInFeet : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16">
    <Cell ss:StyleID="s77"><Data ss:Type="String">22.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s145"><Data ss:Type="String">Name and address of cementing company or contractor</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s157"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s158"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s230"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="2" ss:StyleID="s124"><Data ss:Type="${this.w3aForm.value.pluggingProposal[8] && this.w3aForm.value.pluggingProposal[8].numberOfSacks ? 'Number' : 'String'}">${this.w3aForm.value.pluggingProposal[8] && this.w3aForm.value.pluggingProposal[8].numberOfSacks ? this.w3aForm.value.pluggingProposal[8].numberOfSacks : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s243"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="6" ss:StyleID="m105553158800420"><Data ss:Type="String">${this.w3aForm.value.pluggingProposal[8] && this.w3aForm.value.pluggingProposal[8].depthInFeet ? this.w3aForm.value.pluggingProposal[8].depthInFeet : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="14.75">
    <Cell ss:StyleID="s163"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s129"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s129"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s129"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s129"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s129"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s129"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s150"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s162"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s155"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s244"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s245"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s246"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s246"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s247"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s247"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s247"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s247"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s247"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s247"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s248"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s249"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s71"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="14.75">
    <Cell ss:StyleID="s163"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="13" ss:MergeDown="2" ss:StyleID="s251"><Data
      ss:Type="String">${this.w3aForm.value.nameAddressCementingCompany}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s252"><Data ss:Type="String">23.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s253"><Data ss:Type="String">Anticipated plugging date for this well is:</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s80"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="17">
    <Cell ss:StyleID="s163"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="16" ss:StyleID="s84"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s123"><Data ss:Type="String">CLASS &quot;C&quot; CEMENT</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:MergeAcross="2" ss:StyleID="s124"><Data ss:Type="String">${this.w3aForm.value.anticipatedPluggingDate ? ('0' + (new Date(this.w3aForm.value.anticipatedPluggingDateData).getMonth() + 1)).slice(-2) + '/' + new Date(this.w3aForm.value.anticipatedPluggingDateData).getDate() + '/' + new Date(this.w3aForm.value.anticipatedPluggingDateData).getFullYear() : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="17">
    <Cell ss:StyleID="s155"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="16" ss:StyleID="s155"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s242"><Data ss:Type="String">ONLY</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s254"><Data ss:Type="String">     mo/day/yr</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s172"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0">
    <Cell ss:StyleID="s255"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s79"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:StyleID="s80"><NamedCell ss:Name="Print_Area"/></Cell>
    <Cell ss:Index="31" ss:StyleID="s70"/>
    <Cell ss:StyleID="s71"/>
   </Row>
   <Row ss:AutoFitHeight="0" ss:Height="16">
    <Cell ss:MergeAcross="13" ss:StyleID="s257"><Data ss:Type="String"> ${(this.w3aForm.value.status === 2) && this.w3aForm.value.managerSign ? this.w3aForm.value.managerSign.name : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:MergeAcross="12" ss:StyleID="m105553158800500"><Data ss:Type="String">${(this.w3aForm.value.status === 2) && this.w3aForm.value.managerSign ? 'Manager' : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:StyleID="s214"><Data ss:Type="String">  Typed or printed name of operator's representative</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s122"><Data ss:Type="String">Title of person</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:StyleID="s84"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0" ss:Height="14.75">
      <Cell ss:MergeAcross="6" ss:StyleID="s266"><Data ss:Type="String">${(this.w3aForm.value.status === 2) && this.w3aForm.value.managerSign && this.w3aForm.value.managerSign.phone ? this.w3aForm.value.managerSign.phone : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:MergeAcross="5" ss:StyleID="s268"><Data ss:Type="String" x:Ticked="1">${(this.w3aForm.value.status === 2) && this.w3aForm.value.managerSign ? ('0' + (new Date(this.w3aForm.value.managerSign.date).getMonth() + 1)).slice(-2) + '/' + new Date(this.w3aForm.value.managerSign.date).getDate() + '/' + new Date(this.w3aForm.value.managerSign.date).getFullYear() : ''}</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:MergeAcross="12" ss:StyleID="m105553158800232"><Data ss:Type="String"></Data><NamedCell
      ss:Name="Print_Area"/></Cell>
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:StyleID="s214"><Data ss:Type="String">Telephone:  Area Code   Number</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s122"><Data ss:Type="String">Date: </Data><NamedCell
      ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s122"><Data ss:Type="String">mo.</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s272"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s122"><Data ss:Type="String">day</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s122"><Data ss:Type="String">   year</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s122"><Data ss:Type="String">Signature</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s120"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:Index="31" ss:StyleID="s71"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0" ss:Height="14">
      <Cell ss:StyleID="s155"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s130"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s172"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0" ss:Height="21.25">
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s122"><Data ss:Type="String">RRC District Office Action</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0" ss:Height="20.25">
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s273"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s146"><Data ss:Type="String">Expiration date</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:MergeAcross="3" ss:StyleID="s124"><Data ss:Type="String"></Data><NamedCell
      ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:MergeAcross="10" ss:StyleID="s275"><Data ss:Type="String"></Data><NamedCell
      ss:Name="Print_Area"/></Cell>
      <Cell ss:MergeAcross="1" ss:StyleID="s277"><Data ss:Type="String"></Data><NamedCell
      ss:Name="Print_Area"/></Cell>
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0" ss:Height="13.5">
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s122"><Data ss:Type="String">mo.   day   year</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s122"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s122"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s122"><Data ss:Type="String">District Director</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><Data ss:Type="String">Date</Data><NamedCell
      ss:Name="Print_Area"/></Cell>
      <Cell ss:StyleID="s66"><NamedCell ss:Name="Print_Area"/></Cell>
      <Cell ss:Index="31" ss:StyleID="s71"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s71"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="5" ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="5" ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="5" ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="5" ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="5" ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:Index="31" ss:StyleID="s71"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="5" ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:StyleID="s279"/>
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s71"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s71"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s71"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s71"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s71"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s71"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      <Row ss:AutoFitHeight="0">
      <Cell ss:Index="31" ss:StyleID="s70"/>
      <Cell ss:StyleID="s71"/>
      </Row>
      </Table>
      <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
       <DoNotDisplayGridlines/>
      <PageSetup>
      <Layout x:CenterHorizontal="1" x:CenterVertical="1"/>
      <Header x:Margin="0"/>
      <Footer x:Margin="0"/>
      <PageMargins x:Bottom="0" x:Left="0.25" x:Right="0.28999999999999998"
      x:Top="0"/>
      </PageSetup>
      <Unsynced/>
      <FitToPage/>
      <Print>
      <FitHeight>0</FitHeight>
      <ValidPrinterInfo/>
      <Scale>68</Scale>
      <HorizontalResolution>600</HorizontalResolution>
      <VerticalResolution>600</VerticalResolution>
      </Print>
      <Selected/>
      <TopRowVisible>12</TopRowVisible>
      <Panes>
      <Pane>
      <Number>3</Number>
      <ActiveRow>44</ActiveRow>
      <ActiveCol>13</ActiveCol>
      </Pane>
      </Panes>
      <ProtectObjects>False</ProtectObjects>
      <ProtectScenarios>False</ProtectScenarios>
      </WorksheetOptions>
      </Worksheet>
      </Workbook>
      `;
        const blob = new Blob([template], {type: 'text/csv'});
        saveAs(blob, `${name}.xml`);
    }

    transfer() {
        if (this.transferSub) {
            this.transferSub.unsubscribe();
        }

        this.transferSub = this.setTransfer.req(this.f['id'].value, this.wellId, this.formType['W3'], this.svc).subscribe(res => {
            if (res.header.status === 4000) {
                this.w3aForm.get('assigneeAccessLevel').setValue(this.accessLevelEnum['Supervisor']);
                this.w3aForm.get('supervisorSign').setValue(null);
                this.w3aForm.get('managerSign').setValue(null);
                this.selectW3ASub = this.selectW3A.req(this.svc).subscribe();
                this.getWellsSub = this.getWells.req(this.svc).subscribe();
            }
        });
    }

    onSubmit(status) {
        this.markFormGroupTouched(this.w3aForm);
        if (this.w3aForm.valid) {
            const user = JSON.parse(localStorage.getItem('userId'));
            if (status === 2) {
                this.w3aForm.value.managerSign = {
                    name: `${user.firstName} ${user.lastName}`,
                    date: `${('0' + (new Date().getMonth() + 1)).slice(-2) + '.' + new Date().getDate() + '.' + new Date().getFullYear()}`,
                    phone: `${user.phone ? user.phone : ''}`
                };
            }
            if (status === 1) {
                this.w3aForm.get('assigneeAccessLevel').setValue(this.accessLevelEnum['Manager']);
                this.w3aForm.value.supervisorSign = {
                    name: `${user.firstName} ${user.lastName}`,
                    date: `${('0' + (new Date().getMonth() + 1)).slice(-2) + '.' + new Date().getDate() + '.' + new Date().getFullYear()}`,
                    companyName: 'JMR'
                };
            }
            if (status === 0) {
                this.w3aForm.get('managerSign').setValue(null);
                this.w3aForm.get('supervisorSign').setValue(null);
            }
            this.w3aForm.value.otherTypeOfWell = this.w3aForm.get('otherTypeOfWell').value;
            this.w3aForm.value.status = status;
            if (this.w3aForm.value.anticipatedPluggingDate) {
                this.w3aForm.value.anticipatedPluggingDate = +new Date(this.w3aForm.get('anticipatedPluggingDateData').value);
            }
            if (this.w3aForm.value.fieldPlugTimestamp) {
                this.w3aForm.value.fieldPlugTimestamp = +new Date(this.w3aForm.get('hasNoticeOfIntentToPlugBeenDate').value);
            }
            if (!this.w3aForm.value.id) {
                delete this.w3aForm.value.id;
            }

            // Disable Offline Mode

            this.insertW3ASub = this.insertW3A.req(this.w3aForm.value, this.svc).subscribe(res => {
                if (res.header.status === 4000) {
                    this.successes = true;
                    this.selectW3ASub = this.selectW3A.req(this.svc).subscribe();
                    this.getWellsSub = this.getWells.req(this.svc).subscribe();
                    if (status > 0) {
                        this.router.navigate(['list/well']);
                    } else {
                        this.w3aForm.get('id').setValue(res.body.key.id);
                        this.success('Saved successfully');
                        this.dbSvc.update('w3a', this.w3aForm.value);
                    }
                } else {
                    this.successes = false;
                    this.error(res.header.summary);
                }
                this.insertW3ASub.unsubscribe();
            });
        }
    }
}
