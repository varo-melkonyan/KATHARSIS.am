import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-delete-dialog',
  templateUrl: './delete-dialog.component.html',
  styleUrls: ['./delete-dialog.component.scss']
})
export class DeleteDialogComponent implements OnInit {
  public name: string;
  public isDatePipe: boolean;

  constructor (public dialogRef: MatDialogRef<DeleteDialogComponent>,
               @Inject(MAT_DIALOG_DATA) public dialogData) {
    if (this.dialogData && typeof this.dialogData !== 'object') {
      this.name = this.dialogData;
      this.isDatePipe = false;
    }
    if (this.dialogData && typeof this.dialogData === 'object') {
      this.name = this.dialogData;
      if (this.dialogData.type === 'dwr') {
        this.isDatePipe = true;
      }
    }
  }

  ngOnInit() {
  }

  onNoClick (answer): void {
    this.dialogRef.close(answer);
  }

}
