import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { Alert, AlertType } from '../model';
import { AlertService } from '../services/alert.service';
import { Subscription } from 'rxjs';


@Component({
    selector: 'app-alert',
    templateUrl: 'alert.component.html'
})

export class AlertComponent implements OnInit, OnDestroy {
    @Input() id: string;
    private alertServiceUnSubscribe: Subscription;
    public isMore = {};
    alerts: Alert[] = [];

    constructor (private alertService: AlertService) {
    }

    ngOnInit () {
        this.alertServiceUnSubscribe = this.alertService.getAlert(this.id).subscribe((alert: Alert) => {
            if (!alert.message) {
                this.alerts = [];
                return;
            }

            this.alerts.push(alert);

            setTimeout(() => {
              if (alert) {
                   alert['open'] = !alert['open'];
                   this.removeAlert(alert);
                }
            }, 7000);
        });
    }


    ngOnDestroy () {
        this.alertServiceUnSubscribe.unsubscribe();
    }

    removeAlert (alert: Alert) {
        setTimeout(() => {
          this.alerts = this.alerts.filter(x => x !== alert);
        }, 300);
    }

    cssClass (alert: Alert) {
        if (!alert) {
            return;
        }

        // return css class based on alert type
        switch (alert.type) {
            case AlertType.Success:
                return 'alert alert-success';
            case AlertType.Error:
                return 'alert alert-danger';
            case AlertType.Info:
                return 'alert alert-info';
            case AlertType.Warning:
                return 'alert alert-warning';
        }
    }
}
