import {Component, OnDestroy, OnInit} from '@angular/core';
import {FormArray, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {HeaderService} from '../../services/header.service';
import {appConfig} from '../../constants/app.config';
import {WsService} from '../../services/ws.service';
import {ActivatedRoute, Router} from '@angular/router';
import {ISubscription} from 'rxjs/Subscription';
import {AlertService} from '../../services/alert.service';
import {AddEmployeeService} from './add-employee.service';
import * as sha256 from 'sha256';
import hexToBase64 from '../../constants/hexBase64';
import {DbService} from '../../services/db.service';
import {LokiService} from '../../services/loki.service';

@Component({
    selector: 'app-add-employee',
    templateUrl: './add-employee.component.html',
    styleUrls: ['./add-employee.component.scss']
})
export class AddEmployeeComponent implements OnInit, OnDestroy {
    public employeeForm: FormGroup;
    public userRole = appConfig.userRole;
    private userSub: ISubscription;
    private addUserSub: ISubscription;
    public dbReady: ISubscription;
    private routerParams: ISubscription;
    public item;
    private oldName = '';
    private routerSub: any;
    public isActive = appConfig.isActive;
    public insertUser: any;
    public insertUserSub: any;
    public getUser: any;
    public getUserSub: any;

    constructor(private headerSvc: HeaderService,
                private fb: FormBuilder,
                private router: Router,
                private alertService: AlertService,
                private svc: WsService,
                private dbSvc: DbService,
                private route: ActivatedRoute,
                private addUserSvc: AddEmployeeService,
                private lokiSrc: LokiService) {

        this.addUserSub = this.lokiSrc.returnCallSub().subscribe(coll => {
            if (coll)  {
                this.insertUser = coll.by('name', 'insertUser');
                this.getUser = coll.by('name', 'getUser');
            }
        });
        this.headerSvc.setUrlParams('Add New Employee');
        this.routerSub = router.events.subscribe(event => {
            if (this.router.url.length < 10) {
                this.headerSvc.setUrlParams('Add New Employee');
                this.item = null;
                this.initForm();
            }
        });
        this.dbReady = this.dbSvc.getDbReady().subscribe(ready => {
            if (ready) {
                this.routerParams = this.route.params.subscribe(params => {
                    let id = params['id'];
                    if (id) {
                        id = id.split(' ').join('/');
                        this.dbSvc.openDatabase().then(() => {
                            this.dbSvc.getByKey('users', id).then(
                                user => {
                                    if (user) {
                                        this.item = user;
                                        this.headerSvc.setUrlParams(`${this.item.firstName}  ${this.item.lastName}`);
                                        setTimeout(() => {
                                            this.initForm(this.item);
                                        });
                                    } else {
                                        this.router.navigate(['/']);
                                    }
                                },
                                error => {
                                }
                            );
                        });
                    } else {
                        this.item = null;
                        this.initForm();
                    }
                });
            }
        });
    }

    ngOnInit() {
        if (!localStorage.getItem('sign')) {
            this.router.navigate(['sign-in']);
        }
    }

    ngOnDestroy() {
        if (this.insertUserSub) {
            this.insertUserSub.unsubscribe();
        }
        if (this.getUserSub) {
            this.getUserSub.unsubscribe();
        }
        if (this.userSub) {
            this.userSub.unsubscribe();
        }
        if (this.addUserSub) {
            this.addUserSub.unsubscribe();
        }
        if (this.routerSub) {
            this.routerSub.unsubscribe();
        }
        if (this.routerParams) {
            this.routerParams.unsubscribe();
        }
        if (this.dbReady) {
            this.dbReady.unsubscribe();
        }
    }

    initForm(item?) {
        this.oldName = item ? item.id : '';
        this.employeeForm = this.fb.group({
            id: [item ? item.id : ''],
            email: item && item.accessLevel === 3 ? [item ? item.email : ''] : [{
                value: item ? item.email : '',
                disabled: this.isActive
            }, [Validators.required, Validators.email]],
            firstName: [{
                value: item ? item.firstName : '',
                disabled: this.isActive
            }, Validators.required],
            lastName: [{
                value: item ? item.lastName : '',
                disabled: this.isActive
            }, Validators.required],
            accessLevel: [{
                value: item ? item.accessLevel : '',
                disabled: this.isActive
            }, Validators.required],
            phone: [item ? item.phone : ''],
            commissionEmail: [item ? item.commisionEmail : ''],
            autoSendToCommission: [item ? item.autoSendToCommision : ''],
            password: [item ? null : '']
        });
    }

    get f() {
        return this.employeeForm.controls;
    }

    changeAccessLevel(e) {
        const val = e.target.value;
        if (val === '3') {
            this.employeeForm.get('email').disable();
            this.employeeForm.get('email').setValidators(null);
            this.employeeForm.get('email').setErrors({'required': false});
        } else {
            if (!this.employeeForm.get('email').value) {
                this.employeeForm.get('email').enable();
                this.employeeForm.get('email').setValidators([Validators.required, Validators.email]);
                this.employeeForm.get('email').setErrors({'required': true});
            }
        }
    }

    changeToLowerCase(e) {
        const value = e.target.value.toLowerCase();
        this.employeeForm.get('email').setValue(value);
    }

    success(message: string) {
        this.alertService.success(message);
    }

    error(message: string) {
        this.alertService.error(message);
    }

    markFormGroupTouched(formGroup: FormGroup) {
        (<any>Object).values(formGroup.controls).forEach(control => {
            control.markAsTouched();

            if (control.controls) {
                this.markFormGroupTouched(control);
            }
        });
    }

    filterName(event, name) {
        let value = event.target.value.replace(/\s\s+/g, ' ');
        value = value === ' ' ? '' : value;
        this.f[name].setValue(value);
    }

    onSubmit() {
        this.markFormGroupTouched(this.employeeForm);
        if (this.employeeForm.valid) {
            this.employeeForm.value.accessLevel = +this.employeeForm.value.accessLevel;
            this.employeeForm.value.firstName = this.employeeForm.value.firstName.trim();
            this.employeeForm.value.lastName = this.employeeForm.value.lastName.trim();
            if (!this.employeeForm.value.id) {
                delete this.employeeForm.value.id;
            }
            if (!this.employeeForm.value.phone) {
                delete this.employeeForm.value.phone;
            }
            if (!this.employeeForm.value.password) {
                this.employeeForm.value.password = hexToBase64(sha256(appConfig.userRole[this.employeeForm.value.accessLevel - 1].name));
            }
            if (!this.employeeForm.value.commissionEmail) {
                delete this.employeeForm.value.commissionEmail;
            }
            if (!this.employeeForm.value.autoSendToCommission) {
                delete this.employeeForm.value.autoSendToCommission;
            }

            this.insertUserSub = this.insertUser.req(this.employeeForm.value, this.svc).subscribe(res => {
                if (res.header.status === 4000) {
                    this.getUserSub = this.getUser.req(this.svc).subscribe();
                    this.router.navigate(['list/employee']);
                } else {
                    this.error(res.header.summary);
                }
            });
        }
    }

}
