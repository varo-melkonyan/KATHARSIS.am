import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {RegistrGuard} from '../registr.guard';
import {ActivatedRoute, Router} from '@angular/router';
import {AppService} from '../app.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [RegistrGuard, AppService]
})
export class LoginComponent implements OnInit {

  public loginForm: FormGroup;

  constructor(private fb: FormBuilder, private router: Router,
              private route: ActivatedRoute, private appsrc: AppService) {
    this.appsrc.getData();
  }

  ngOnInit(): void {
    document.getElementById('signup').hidden = false;
    document.getElementById('signin').hidden = false;
    document.getElementById('signout').hidden = true;
    this.loginForm = this.fb.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  routeFn(url: Array<any>): void {
    this.router.navigate(url, {relativeTo: this.route}).then(res => {
      console.log(res, 'res');
    });
  }

  getId(id): any {
    return id;
  }

  getUser(): any {
    if (this.loginForm.controls.email.value && this.loginForm.controls.password.value) {
      for (let i = 0; i < this.appsrc.db.getCollection('users').data.length; i++) {
        if (this.appsrc.db.getCollection('users').data[i]['email'] === this.loginForm.controls.email.value &&
          this.appsrc.db.getCollection('users').data[i]['pass'] === this.loginForm.controls.password.value) {
          this.appsrc.setId(i);
          // this.routeFn(['people', i]);
        }
      }

    } else {
      alert('Please fill in all the fields correctly!');
    }
  }

  getLogin(): void {
    this.getUser();
  }
}
