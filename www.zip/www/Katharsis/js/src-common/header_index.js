$(window).on('load', function() {

    $window = $(window);

	$window.scroll(function() {
	    if ( $window.scrollTop() >= 1 ) {
	        $('#nav-btn').addClass('scroll');
	    } else {
	    	$('#nav-btn').removeClass('scroll');
	    };
	});

	$('#nav .content .container-prLink ul .link-projects span').html($('#nav .content .container-contentLink .wrapper-el .el-projects ul li').length);
	$('#nav-mobile .wrapper .container-linkPr ul li span').html($('#nav .content .container-contentLink .wrapper-el .el-projects ul li').length);

})

$('#nav-btn').click(function(){
	if (!$('#nav-btn').hasClass('disable')) {
		$('#nav-btn').addClass('disable');
		if ($('#nav-btn').hasClass('active')) {
			$('#nav-btn').removeClass('active');
			$('#nav').removeClass('show');
			$('#nav .content').removeClass('active');
			setTimeout(function() {
				$('#nav-btn').removeClass('disable');
				$('#nav').removeClass('displayBlock');

			}, 500);
		} else {
			$('#nav-btn').addClass('active');
			$('#nav').addClass('displayBlock').outerWidth();
			$('#nav').addClass('show');
			$('#nav .content').addClass('active');
			setTimeout(function() {
				$('#nav-btn').removeClass('disable');
			}, 1000);
		}

	}
	
})

$('#nav .content .container-prLink ul li a').mouseenter(function(){
	if (window.matchMedia("(min-width: 1000px)").matches) {
		$('#nav .content .container-contentLink .wrapper-el .el').removeClass('displayBlock show');
		$('#nav .content .container-contentLink .wrapper-el .' + $(this).data('content')).addClass('displayBlock').outerWidth();
		$('#nav .content .container-contentLink .wrapper-el .' + $(this).data('content')).addClass('show').outerWidth();
	}
})




