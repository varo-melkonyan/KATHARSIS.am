import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { AppRoutingModule } from './app-routing.module';
import { NavComponent } from './components/nav/nav.component';
import { HeaderComponent } from './components/header/header.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { OngoingFilter } from './pipes/ongoing-filter';
import { FilterPipe } from './pipes/filter';
import { FormsModule } from '@angular/forms';
import { ControllersFilterTable } from './pipes/controllers-filter-table';
import { HeaderService } from './services/header.service';
import { WellService } from './components/well/well.service';
import { TeamService } from './components/team/team.service';
import { EmployeeService } from './components/employee/employee.service';
import { DeleteDialogComponent } from './components/delete-dialog/delete-dialog.component';
import { WsService } from './services/ws.service';
import { LoadingService } from './services/loading.service';
import { MatDialogModule, MatProgressSpinnerModule } from '@angular/material';
import { LoadingPopComponent } from './components/loading-pop/loading-pop.component';
import { AlertComponent } from './_directives/alert.component';
import { AlertService } from './services/alert.service';
import { AddEmployeeService } from './components/add-employee/add-employee.service';
import { AddTeamService } from './components/add-team/add-team.service';
import { AddWellService } from './components/add-well/add-well.service';
import { SharedModule } from './shared/shared.module';
import { SigninComponent } from './components/signin/signin.component';
import { ChangePasswordComponent } from './components/change-password/change-password.component';
import { OnlineService } from './services/online.service';
import { ListComponent } from './components/list/list.component';
import { EmployeeComponent } from './components/employee/employee.component';
import { TeamComponent } from './components/team/team.component';
import { WellComponent } from './components/well/well.component';
import { SettingsComponent } from './components/settings/settings.component';
import { AmazingTimePickerModule } from 'amazing-time-picker';
import { AddWellComponent } from './components/add-well/add-well.component';
import { WellFormComponent } from './components/add-well/well-form/well-form.component';
import { DwrFormComponent } from './components/add-well/dwr-form/dwr-form.component';
import { W3FormComponent } from './components/add-well/w3-form/w3-form.component';
import { W3aFormComponent } from './components/add-well/w3a-form/w3a-form.component';
import { MembersFilter } from './components/add-team/members-filter';
import { AddTeamComponent } from './components/add-team/add-team.component';
import { AddEmployeeComponent } from './components/add-employee/add-employee.component';
import { DbService } from './services/db.service';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { TimepickerComponent } from './components/timepicker/timepicker.component';
import { SelectPickerComponent } from './components/select-picker/select-picker.component';
import { ClickStopPropagationDirective } from './_directives/click-stop-propagation/click-stop-propagation.directive';
import {FilterPicker} from './pipes/filter-picker';
import {LokiService} from './services/loki.service';


@NgModule({
    declarations: [
        AppComponent,
        NavComponent,
        HeaderComponent,
        OngoingFilter,
        FilterPipe,
        ControllersFilterTable,
        DeleteDialogComponent,
        LoadingPopComponent,
        AlertComponent,
        SigninComponent,
        ChangePasswordComponent,
        FilterPicker,
        /*list page*/
        ListComponent,
        EmployeeComponent,
        TeamComponent,
        WellComponent,
        /*Settings Page*/
        SettingsComponent,
/*add-well page*/
        AddWellComponent,
        WellFormComponent,
        DwrFormComponent,
        W3FormComponent,
        W3aFormComponent,
        AddTeamComponent,
        MembersFilter,
        AddEmployeeComponent,
        TimepickerComponent,
        SelectPickerComponent,
        ClickStopPropagationDirective
    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        BrowserAnimationsModule,
        FormsModule,
        MatDialogModule,
        MatProgressSpinnerModule,
        SharedModule,
        AmazingTimePickerModule,
        ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production })
    ],
    exports: [
        OngoingFilter,
        FilterPipe,
        ControllersFilterTable,
        MatDialogModule,
        MatProgressSpinnerModule,
        MembersFilter
    ],
    providers: [
        HeaderService,
        WellService,
        TeamService,
        EmployeeService,
        WsService,
        OnlineService,
        LoadingService,
        AlertService,
        AddEmployeeService,
        AddTeamService,
        AddWellService,
        DbService,
        LokiService
    ],
    entryComponents: [
        DeleteDialogComponent,
        LoadingPopComponent
    ],
    bootstrap: [AppComponent]
})
export class AppModule {
}
