import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { W3FormComponent } from './w3-form.component';

describe('W3FormComponent', () => {
  let component: W3FormComponent;
  let fixture: ComponentFixture<W3FormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ W3FormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(W3FormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
