import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'employeeFilter'
})
export class EmployeeFilterPipe implements PipeTransform {
  transform(items: any, name: string, role: number, email: string) {
    if (items && items.length) {
      return items.filter(item => {
        if (name && (item.firstName + ' ' + item.lastName)
            .toLowerCase().indexOf(name.toLowerCase()) === -1) {
          return false;
        }
        if (role && +role !== +item.accessLevel) {
          return false;
        }
        if (email && item.name.toLowerCase().indexOf(email.toLowerCase()) === -1) {
          return false;
        }
        return true;
      });
    } else {
      return items;
    }
  }
}
