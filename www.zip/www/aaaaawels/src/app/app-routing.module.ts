import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { appConfig } from './constants/app.config';
import { SigninComponent } from './components/signin/signin.component';
import { ChangePasswordComponent } from './components/change-password/change-password.component';
import { ListComponent } from './components/list/list.component';
import { WellComponent } from './components/well/well.component';
import { TeamComponent } from './components/team/team.component';
import { EmployeeComponent } from './components/employee/employee.component';
import { SettingsComponent } from './components/settings/settings.component';
import { AddWellComponent } from './components/add-well/add-well.component';
import { WellFormComponent } from './components/add-well/well-form/well-form.component';
import { RoutingIdComponent } from './components/routing-id/routing-id.component';
import { W3aFormComponent } from './components/add-well/w3a-form/w3a-form.component';
import { W3FormComponent } from './components/add-well/w3-form/w3-form.component';
import { DwrFormComponent } from './components/add-well/dwr-form/dwr-form.component';
import { AddTeamComponent } from './components/add-team/add-team.component';
import { AddEmployeeComponent } from './components/add-employee/add-employee.component';

const appRoutes: Routes = [
    {
        path: 'list',
        /*loadChildren: './components/list/list.module#ListModule'*/
        component: ListComponent,
        children: [
            { path: '', redirectTo: 'well', pathMatch: 'full' },
            { path: 'well', component: WellComponent },
            { path: 'team', component: TeamComponent },
            { path: 'employee', component: EmployeeComponent }
        ]
    },
    {
        path: 'settings',
        /*loadChildren: './components/settings/settings.module#SettingsModule'*/
        component: SettingsComponent
    },
    {
        path: 'well',
        /*loadChildren: './components/add-well/add-well.module#AddWellModule'*/
        component: AddWellComponent,
        children: [
            {path: '', redirectTo: 'well-form', pathMatch: 'full'},
            {
                path: 'well-form', component: WellFormComponent,
                children: [
                    {path: ':id', component: RoutingIdComponent}
                ]
            },
            {
                path: 'w3a-form',
                /*loadChildren: './w3a-form/w3a-form.module#W3aFormModule'*/
                component: W3aFormComponent,
                children: [
                    { path: ':id', component: RoutingIdComponent }
                ]
            },
            {
                path: 'dwr-form',
                /*loadChildren: './dwr-form/dwr-form.module#DwrFormModule'*/
                component: DwrFormComponent,
                children: [
                    { path: ':id', component: RoutingIdComponent }
                ]
            },
            {
                path: 'w3-form',
                /*loadChildren: './w3-form/w3-form.module#W3FormModule'*/
                component: W3FormComponent,
                children: [
                    { path: ':id', component: RoutingIdComponent }
                ]
            },
        ]
    },
    {
        path: 'team',
        /*loadChildren: './components/add-team/add-team.module#AddTeamModule'*/
        component: AddTeamComponent,
    },
    { path: 'team/:id', component: AddTeamComponent },
    {
        path: 'employee',
        /*loadChildren: './components/add-employee/add-employee.module#AddEmployeeModule'*/
        component: AddEmployeeComponent,
    },
    { path: 'employee/:id', component: AddEmployeeComponent },
    {
        path: 'sign-in',
        component: SigninComponent
    },
    {
        path: 'change-password',
        component: ChangePasswordComponent
    },
    {path: '**', redirectTo: appConfig.defaultHomePage}
];

@NgModule({
    imports: [RouterModule.forRoot(appRoutes)],
    exports: [RouterModule]
})
export class AppRoutingModule {
}
