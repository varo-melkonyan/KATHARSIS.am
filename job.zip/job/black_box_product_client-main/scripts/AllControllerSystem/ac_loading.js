const ac_loading = {
    openLoading : () => {
        document.getElementById("popup_container").style.display = "block";
    },

    closeLoading : () => {
        document.getElementById("popup_container").style.display = "none";
    }
}