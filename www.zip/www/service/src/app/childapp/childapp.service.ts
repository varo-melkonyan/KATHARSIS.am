import {Injectable} from '@angular/core';
import {BehaviorSubject} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ChildappService {

  public data: BehaviorSubject<any> = new BehaviorSubject<any>(null);

  constructor() {
  }


  setData(value: any): void {
    this.data.next(value);
  }

  getData(): any {
    return this.data;
  }
}
