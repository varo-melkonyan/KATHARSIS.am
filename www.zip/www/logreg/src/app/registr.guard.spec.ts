import { TestBed } from '@angular/core/testing';

import { RegistrGuard } from './registr.guard';

describe('RegistrGuard', () => {
  let guard: RegistrGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(RegistrGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
