import { TestBed } from '@angular/core/testing';

import { ChildappService } from './childapp.service';

describe('ChildappService', () => {
  let service: ChildappService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ChildappService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
