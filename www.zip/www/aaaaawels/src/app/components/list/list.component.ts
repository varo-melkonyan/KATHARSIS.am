import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HeaderService } from '../../services/header.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit, OnDestroy {

  public active = null;
  public routerSub: any;

  constructor(private router: Router,
              private headerSvc: HeaderService) {
    this.headerSvc.setUrlParams('List View');
    this.routerSub = router.events.subscribe(event => {
      this.pageSwitch();
    });
    this.pageSwitch();
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.routerSub.unsubscribe();
  }
  pageSwitch() {
    switch (this.router.url) {
      case '/list/well':
        this.active = 0;
        break;
      case '/list/team':
        this.active = 1;
        break;
      case '/list/employee':
        this.active = 2;
        break;
      default:
    }
  }

  setPage (page) {
    this.router.navigate([`list/${page}`]);
  }
}
