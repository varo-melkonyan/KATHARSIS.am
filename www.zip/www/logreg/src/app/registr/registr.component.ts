import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {Router} from '@angular/router';
import * as loki from 'lokijs';
import * as lokiIndexed from 'lokijs/src/loki-indexed-adapter.js';
import {RegistrService} from './registr.service';


@Component({
  selector: 'app-registr',
  templateUrl: './registr.component.html',
  styleUrls: ['./registr.component.css'],
  providers: [RegistrService]
})
export class RegistrComponent implements OnInit {

  constructor(private fb: FormBuilder, private router: Router, private regsrc: RegistrService) {

  }

  public registerForm: FormGroup;
  public isPassword = true;

  ngOnInit(): void {
    this.registerForm = this.fb.group({
      name: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9_-]{3,15}$')]],
      lastname: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9_-]{5,15}$')]],
      email: ['', [Validators.required, Validators.pattern('^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\\]?)$')]],
      password: ['', [Validators.required, Validators.pattern('^[a-z0-9_-]{6,15}$')]]
    });
  }


  getReg(): void {
    if (this.registerForm.valid) {
      this.regsrc.collname.insertOne({name: 'awg', lastname: 'egs', email: 'wag'});
      this.regsrc.db.saveDatabase();
      console.log(this.regsrc.collname);
      this.router.navigate(['/signin']).then(r => r);
    } else {
      alert('Please fill in all the fields correctly!');
    }
  }

  showPassword(): void {

    this.isPassword = false;

  }

  hidePassword(): void {

    this.isPassword = true;

  }
}
