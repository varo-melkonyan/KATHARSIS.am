import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TagInputModule } from 'ngx-chips';
import { OrderBy } from '../pipes/orderBy';
import { PrecisionFilter } from '../pipes/precision-filter';
import { LoadingPopComponent } from '../components/loading-pop/loading-pop.component';
import { RoutingIdComponent } from '../components/routing-id/routing-id.component';
import { WellFilterPipe } from '../components/well/well-filter-pipe';
import { TeamFilterPipe } from '../components/team/team-filter-pipe';
import { EmployeeFilterPipe } from '../components/employee/employee-filter-pipe';
import { AutosizeModule } from 'ngx-autosize';

import { FormatPipe } from '../pipes/format-pipe';
// Material
import {
    MatButtonModule,
    MatCheckboxModule,
    MatInputModule, MatNativeDateModule
} from '@angular/material';
/*import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatSliderModule } from '@angular/material/slider';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatListModule } from '@angular/material/list';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatCardModule } from '@angular/material/card';
import { MatStepperModule } from '@angular/material/stepper';
import { MatTabsModule } from '@angular/material/tabs';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatChipsModule } from '@angular/material/chips';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTableModule } from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import { MatPaginatorModule } from '@angular/material/paginator';*/
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatDialogModule } from '@angular/material/dialog';
import { MatMenuModule } from '@angular/material/menu';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { NavUserFilterPipe } from '../pipes/nav-user-filter-pipe';
import { MatSnackBarModule } from '@angular/material/snack-bar';


/*const materialComponents = [
    MatCheckboxModule,
    MatButtonModule,
    MatInputModule,
    MatAutocompleteModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatRadioModule,
    MatSelectModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatMenuModule,
    MatSidenavModule,
    MatToolbarModule,
    MatListModule,
    MatGridListModule,
    MatNativeDateModule,
    MatCardModule,
    MatStepperModule,
    MatTabsModule,
    MatExpansionModule,
    MatButtonToggleModule,
    MatChipsModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatProgressBarModule,
    MatDialogModule,
    MatTooltipModule,
    MatSnackBarModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule
];*/


@NgModule({
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    HttpClientModule,
    RouterModule,
    TagInputModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    MatMenuModule,
    MatDialogModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatInputModule,
    MatNativeDateModule,
    AutosizeModule
    /*...materialComponents*/
  ],
  declarations: [
    PrecisionFilter,
    OrderBy,
    RoutingIdComponent,
    WellFilterPipe,
    TeamFilterPipe,
    EmployeeFilterPipe,
    FormatPipe,
    NavUserFilterPipe
  ],
  providers: [],
  entryComponents: [
  ],
  exports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    HttpClientModule,
    RouterModule,
    PrecisionFilter,
    OrderBy,
    TagInputModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    MatMenuModule,
    MatDialogModule,
    WellFilterPipe,
    TeamFilterPipe,
    EmployeeFilterPipe,
    FormatPipe,
    NavUserFilterPipe,
    MatDatepickerModule,
    MatFormFieldModule,
    MatInputModule,
    MatNativeDateModule,
    AutosizeModule,
    MatSnackBarModule
    /* ...materialComponents,*/
  ],
})
export class SharedModule {
}
