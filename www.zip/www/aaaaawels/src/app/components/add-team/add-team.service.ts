import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';

import { Subject, BehaviorSubject } from 'rxjs';


@Injectable()
export class AddTeamService {
  public editItemName = new Subject<string>();


  constructor () {

  }

  setEditItemName (id) {
    this.editItemName.next(id);
  }

  getEditItemName () {
    return this.editItemName;
  }
}
