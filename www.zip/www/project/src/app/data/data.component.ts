import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-data',
  templateUrl: './data.component.html',
  styleUrls: ['./data.component.css']
})
export class DataComponent implements OnInit {
  public id: number;
  public name: string;
  names: Array<string> = ['Name1', 'name2', 'name3', 'name4', 'name5'];
  lastname: Array<string> = ['lastname1', 'lastname2', 'lastname3', 'lastname4', 'lastname5'];
  email: Array<string> = ['Email1', 'Email2', 'Email3', 'Email4', 'Email5'];


  constructor() {
  }

  ngOnInit(): void {
  }

}
