import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'membersFilter'
})
export class MembersFilter implements PipeTransform {
  transform(items: any, name: string, activeMembers: any) {
    if (items && items.length) {
      return items.filter(item => {
        if (name && (item.firstName + ' ' + item.lastName).toLowerCase().indexOf(name.toLowerCase()) === -1) {
          return false;
        }
        const l = activeMembers.length;
        let coincidence = false;
        for (let i = 0; i < l; i++) {
          if ((item.id) === (activeMembers[i].id)) {
            coincidence = true;
          }
        }
        if (coincidence) {
          return false;
        }
        return true;
      });
    } else {
      return items;
    }
  }
}
