import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'userFilter'
})
export class NavUserFilterPipe implements PipeTransform {
    transform(items: any, name: string, status: number, tag?: string) {
        if (items && items.length) {
            return items.filter(item => {
                if (name && (item.firstName + ' ' + item.lastName).toLowerCase().indexOf(name.toLowerCase()) === -1) {
                    return false;
                }
                return !((status || status === 0) && status !== item.accessLevel);
            });
        } else {
            return items;
        }
    }
}
