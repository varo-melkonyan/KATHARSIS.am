import {Injectable} from '@angular/core';
import 'rxjs/add/operator/map';
import {QueueingSubject} from 'queueing-subject';
import webSocketConnect from 'rxjs-websockets';
import {mapTo} from 'rxjs/operators';
import {BehaviorSubject, fromEvent, merge, Observable, of, Subject} from 'rxjs';
import {OnlineService} from './online.service';
import {Router} from '@angular/router';
import {LoadingService} from './loading.service';
import {appConfig} from '../constants/app.config';
import {LokiService} from './loki.service';

const input = new QueueingSubject<string>();

@Injectable()
export class WsService {
    onlineSub: any;
    messagesSub: any;
    connectionStatusSub: any;
    online$: Observable<boolean>;
    private isOnline: boolean;
    private wsConnect: any;
    private start = false;
    public response: any = {};
    public close = new Subject<any>();
    public connectEstablished;
    public connectStatus: number;
    public sub = new Subject;
    public connectionEstablishedSub: any;

    constructor(private loadingSvc: LoadingService,
                private isOnlineSvc: OnlineService,
                private router: Router,
                private lokiSrc: LokiService) {
        this.online$ = merge(
            of(navigator.onLine),
            fromEvent(window, 'online').pipe(mapTo(true)),
            fromEvent(window, 'offline').pipe(mapTo(false))
        );
        this.connectionEstablishedSub = this.lokiSrc.returnCallSub().subscribe(coll => {
            if (coll) {
                this.connectEstablished = coll.by('name','ConnectionEstablished');
            }
        })
    }

    wsFn(userName, pass) {
        this.wsConnect = webSocketConnect(`wss://ayrarat.am:4012/?userName=${userName}&password=${pass}`, input);
        this.connectionStatusSub = this.wsConnect.connectionStatus.subscribe(connectStatus => {
                this.connectStatus = connectStatus;
                if (connectStatus === -1) {
                    this.closeConnect();
                    this.router.navigate(['sign-in']).then(() => {
                        if (!this.isOnline) {
                            this.close.next({
                                isError: true,
                                msgs: 'No Internet Connection'
                            });
                        }
                    });
                }
            },
            err => console.log(err.toString()),
            () => console.log('complete'));
        this.onlineSub = this.online$.subscribe(online => {
            this.isOnline = online;
            this.isOnlineSvc.setIsOnline(online);
            if (!online) {
                this.closeConnect();
            } else {
                this.messagesSubData();
            }
        });
    }

    closeConnect() {
        this.loadingSvc.endLoading();
        if (this.messagesSub) {
            this.messagesSub.unsubscribe();
        }
    }

    messagesSubData() {
        this.messagesSub = this.wsConnect.messages.subscribe(data => {
                data = JSON.parse(data);
                this.loadingSvc.endLoading();
                setTimeout(() => {
                    if (!this.response[data.header.name]) {
                        this.response[data.header.name] = new BehaviorSubject<any>(data);
                    } else {
                        this.response[data.header.name].next(data);
                    }
                });
                if (data.header.name !== appConfig.connectionEstablished) {
                    if (data.header.name.indexOf('LTR') < 0) {
                        this.loadingSvc.endLoading();
                    }
                    setTimeout(() => {
                        this.start = true;
                    }, 500);
                }
            },
            (err) => {
                this.close.next(true);
                setTimeout(() => {
                    this.router.navigate(['sign-in']).then(() => {
                        if (this.isOnline) {
                            this.close.next({
                                isError: true,
                                msgs: 'That email / password combination is not valid'
                            });
                        } else {
                            this.close.next({
                                isError: true,
                                msgs: 'No Internet Connection'
                            });
                        }
                        this.closeConnect();
                    });
                });
            });
    }

    getData(type: string | number, subjectType?: boolean) {
        this.loadingSvc.endLoading();
        if (!this.response[type]) {
            if (subjectType) {
                this.response[type] = new BehaviorSubject<any>(null);
            } else {
                this.response[type] = new Subject<any>();
            }
        }
        return this.response[type];
    }

    setParams(params: any, type: string | number, subscribeType: number | boolean) {
        if (this.connectStatus && (this.connectStatus > 0) && this.isOnline) {
            this.loadingSvc.startLoading();
        }
        input.next(JSON.stringify(params));
        if (!this.response[type]) {
            this.response[type] = subscribeType ? new BehaviorSubject<any>(null) : new Subject<any>();
        }
    }

    returnCloseConnect() {
        return this.close;
    }
}
