import {Component, OnDestroy, OnInit} from '@angular/core';
import {FormArray, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {ISubscription} from 'rxjs/Subscription';
import {appConfig} from '../../../constants/app.config';
import {AlertService} from '../../../services/alert.service';
import {Router} from '@angular/router';
import {AddWellService} from '../add-well.service';
import {WsService} from '../../../services/ws.service';
import {LoadingService} from '../../../services/loading.service';
import {HeaderService} from '../../../services/header.service';
import {DbService} from '../../../services/db.service';
import {FormType} from '../../../constants/app.enums';
import {LokiService} from '../../../services/loki.service'

@Component({
    selector: 'app-well-form',
    templateUrl: './well-form.component.html',
    styleUrls: ['./well-form.component.scss']
})
export class WellFormComponent implements OnInit, OnDestroy {
    private statusSub: ISubscription;
    private wellSub: ISubscription;
    private addWellSub: ISubscription;
    private headerSub: ISubscription;

    public wellForm: FormGroup;
    public teams;
    public showAnyTeam = true;
    public item;
    public wellsStatus = appConfig.wellsStatus;
    private oldName = '';
    public isActive = appConfig.isActive;
    public formType = FormType;
    public subWell: any;
    public insertWell: any;
    public insertWellSub: any;
    public updateWellUserMetadata: any;
    public getWells: any;
    public getTags: any;
    public getWellsSub: any;
    public getTagsSub: any;
    public updateWellUserMetadataSub: any;

    constructor(private fb: FormBuilder,
                private svc: WsService,
                private dbSvc: DbService,
                private alertService: AlertService,
                private router: Router,
                private loadingSvc: LoadingService,
                private headerSvc: HeaderService,
                private addWellSvc: AddWellService,
                private lokiSrc: LokiService) {
        this.headerSub = this.headerSvc.getIsActive().subscribe(isActive => {
            this.isActive = isActive;
        });
        this.dbSvc.openDatabase().then(() => {
            this.dbSvc.getAll('teams').then(
                teams => {
                    if (teams && teams[0]) {
                        this.teams = teams;
                    }
                },
                error => {
                }
            );
        });
        this.addWellSub = this.addWellSvc.getSelectedWell().subscribe(well => {
            this.item = well;
            setTimeout(() => {
                this.initForm(this.item);
            });
        });
        this.subWell = this.lokiSrc.returnCallSub().subscribe(coll => {
            if (coll) {
                this.insertWell = coll.by('name', 'insertWell');
                this.updateWellUserMetadata = coll.by('name', 'updateWellUserMetadata');
                this.getWells = coll.by('name', 'getWell');
                this.getTags = coll.by('name', 'getTags');
            }
        });
    }

    ngOnInit() {
        this.initForm();
    }

    ngOnDestroy() {

        if (this.getWellsSub) {
            this.getWellsSub.unsubscribe();
        }
        if (this.updateWellUserMetadataSub) {
            this.updateWellUserMetadataSub.unsubscribe();
        }
        if (this.getTagsSub) {
            this.getTagsSub.unsubscribe();
        }
        if (this.wellSub) {
            this.wellSub.unsubscribe();
        }
        if (this.statusSub) {
            this.statusSub.unsubscribe();
        }
        if (this.insertWellSub) {
            this.insertWellSub.unsubscribe();
        }
        if (this.headerSub) {
            this.headerSub.unsubscribe();
        }
        if (this.addWellSub) {
            this.addWellSub.unsubscribe();
        }
    }

    initForm(item?) {
        this.oldName = item ? item.name : '';
        this.wellForm = this.fb.group({
            id: [item ? item.id : ''],
            name: [{
                value: item ? item.name : '',
                disabled: this.isActive
            }, Validators.required],
            status: [{
                value: item ? item.status : 0,
                disabled: this.isActive
            }, Validators.required],
            teamId: [{
                value: item ? item.team === null ? 'any' : item.team.id : 'any',
                disabled: this.isActive
            }, Validators.required],
            location: this.fb.group({
                longitude: [{
                    value: item ? item.location.longitude : null,
                    disabled: this.isActive
                }, [Validators.required, Validators.min(-180), Validators.max(+180)]],
                latitude: [{
                    value: item ? item.location.latitude : null,
                    disabled: this.isActive
                }, [Validators.required, Validators.min(-90), Validators.max(+90)]]
            }),
            customerName: [{
                value: item ? item.customerName : '',
                disabled: this.isActive
            }],
            customerNumber: [{
                value: item ? item.customerNumber : null,
                disabled: this.isActive
            }],
            pluggersUnitNumber: [{
                value: item ? item.pluggersUnitNumber : null,
                disabled: this.isActive
            }],
            jobNumber: [{
                value: item ? item.jobNumber : null,
                disabled: this.isActive
            }],
            api: [{
                value: item ? item.api : '',
                disabled: this.isActive
            }],
            countryState: [{
                value: item ? item.countryState : '',
                disabled: this.isActive
            }],
            field: [{
                value: item ? item.field : '',
                disabled: this.isActive
            }],
            legalDescriptionLease: [{
                value: item ? item.legalDescriptionLease : '',
                disabled: this.isActive
            }],
            tagInput: '',
            tags: (item && item.metadata && item.metadata.tags && item.metadata.tags[0]) ? [{
                value: item.metadata.tags,
                disabled: this.isActive
            }] : [[]]
        });

        this.statusSub = this.wellForm.get('status').valueChanges.subscribe(value => {
            if (+value === 0) {
                this.showAnyTeam = true;
                if (!this.wellForm.get('teamId').value) {
                    this.wellForm.get('teamId').setValue('any');
                }
            } else {
                this.showAnyTeam = false;
                if (this.wellForm.get('teamId').value === 'any') {
                    this.wellForm.get('teamId').setValue('');
                }
            }
        });
        this.loadingSvc.endLoading();
    }

    get f() {
        return this.wellForm.controls;
    }

    stopProp(e) {
        e.stopPropagation();
    }

    filterName(event) {
        let value = event.target.value.replace(/\s\s+/g, ' ');
        value = value === ' ' ? '' : value;
        this.f['name'].setValue(value);
    }

    addTag(event) {
        if (!event.target.value || (event.target.value.split(' ').join('') === '')) {
            return false;
        }
        const tag = event.target.value.toLowerCase().replace(/\s\s+/g, ' ');
        const l = this.wellForm.get('tags').value && this.wellForm.get('tags').value[0] ? this.wellForm.get('tags').value.length : 0;
        const elem = this.wellForm.get('tags').value;
        if (elem && elem[0]) {
            for (let i = 0; i < l; i++) {
                if (tag === elem[i]) {
                    return false;
                } else if ((i + 1) === l) {
                    this.wellForm.get('tags').value.push(tag);
                    this.wellForm.get('tagInput').setValue('');
                }
            }
        } else {
            this.wellForm.get('tags').value.push(tag);
            this.wellForm.get('tagInput').setValue('');
        }
    }

    deleteTag(index) {
        this.wellForm.get('tags').value.splice(index, 1);
    }

    markFormGroupTouched(formGroup: FormGroup) {
        (<any>Object).values(formGroup.controls).forEach(control => {
            control.markAsTouched();

            if (control.controls) {
                this.markFormGroupTouched(control);
            }
        });
    }

    success(message: string) {
        this.alertService.success(message);
    }

    error(message: string) {
        this.alertService.error(message);
    }


    onSubmit() {
        this.markFormGroupTouched(this.wellForm);
        if (this.wellForm.valid) {
            this.wellForm.markAsTouched();
            if (!this.wellForm.value.id) {
                delete this.wellForm.value.id;
            }
            if (this.wellForm.value.teamId === 'any') {
                this.wellForm.value.teamId = null;
            }
            delete this.wellForm.value.tagInput;

            this.wellSub = this.insertWell.req(this.wellForm.value, this.svc).subscribe(res => {

                if (this.item) {
                    res.body.filter = {
                        name: {'$eq': this.oldName}
                    };
                }
                if (res.header.status === 4000) {
                    this.updateWellUserMetadataSub = this.updateWellUserMetadata.req(res.body.key.id, ((this.wellForm.value.tags &&
                        this.wellForm.value.tags.length > 0) ? this.wellForm.value.tags :
                        ['any']), this.svc).subscribe(resMeta => {
                        if (resMeta.header.status === 4000) {
                            this.getWellsSub = this.getWells.req(this.svc).subscribe();
                            this.getTagsSub = this.getTags.req(this.svc).subscribe();
                            this.router.navigate(['list/well']);
                        } else {
                            this.error(res.header.summary);
                        }
                    });
                } else {
                    this.error(res.header.summary);
                }
            });
        }
    }
}
