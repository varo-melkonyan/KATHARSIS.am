import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';

import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {LoginComponent} from './login/login.component';
import {RegistrComponent} from './registr/registr.component';
import {ReactiveFormsModule} from '@angular/forms';
import {RegistrModule} from './registr/registr.module';
import {RegistrGuard} from './registr.guard';
import { ListComponent } from './list/list.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrComponent,
    ListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    RegistrModule
  ],
  providers: [RegistrGuard],
  bootstrap: [AppComponent]
})
export class AppModule {
}
