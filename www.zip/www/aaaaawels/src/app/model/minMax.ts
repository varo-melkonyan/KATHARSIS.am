export class MinMax {
    constructor(public min: number,
                public max: number) {
    }
}
