import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {HeaderService} from '../../services/header.service';
import {WellService} from '../well/well.service';
import {ISubscription} from 'rxjs/Subscription';
import {TeamService} from '../team/team.service';
import {EmployeeService} from '../employee/employee.service';
import {WsService} from '../../services/ws.service';
import {appConfig} from '../../constants/app.config';
import {LoadingService} from '../../services/loading.service';
import {AddTeamService} from '../add-team/add-team.service';
import {AddEmployeeService} from '../add-employee/add-employee.service';
import {AddWellService} from '../add-well/add-well.service';
import {OnlineService} from '../../services/online.service';
import {DbService} from '../../services/db.service';
import {LokiService} from '../../services/loki.service';

@Component({
    selector: 'app-nav',
    templateUrl: './nav.component.html',
    styleUrls: ['./nav.component.scss']
})
export class NavComponent implements OnInit, OnDestroy {
    @Output() toggleBar: EventEmitter<any> = new EventEmitter();
    @Input() isBar: boolean;

    private wellSub: ISubscription;
    private wellMetaSub: ISubscription;
    private teamSub: ISubscription;
    private employeeSub: ISubscription;
    private dwrSub: ISubscription;
    private w3aSub: ISubscription;
    private w3Sub: ISubscription;
    private tagsSub: ISubscription;
    private headerSub: ISubscription;
    private isOnline: boolean;

    public toggleSection1 = false;
    public toggleSection2 = false;
    public toggleSection3 = false;
    public toggleSection4 = false;
    public activeTags = [];
    public wells = [];
    public wellUserMetadata: any;
    public teams = [];
    public users = [];
    public tags: any;
    public activeWellTags = {};
    public activeWellStatus = null;
    public activeEmployeeGroups = null;
    public wellNameFilter = '';
    public teamNameFilter = '';
    public employeeNameFilter = '';
    public wellsStatus = appConfig.wellsStatus;
    public employeeGroups = appConfig.userRole;
    public isActive = appConfig.isActive;
    public db: any;
    private dataKeys = [
        'wells',
        'teams',
        'users',
        'dwr',
        'w3a',
        'w3'
    ];
    public getWells: any;
    public getAllWellsSub: any;
    public getWellUserMetadata: any;
    public getTags: any;
    public getUser: any;
    public getTeam: any;
    public getSelectDWR: any;
    public getSelectW3A: any;
    public getSelectW3: any;
    public insertDWR: any;
    public insertW3A: any;
    public insertW3: any;
    public getWellsSub: any;
    public getWellUserMetadataSub: any;
    public getTeamSub: any;
    public getUserSub: any;
    public getTagsSub: any;
    public getSelectDWRSub: any;
    public getSelectW3ASub: any;
    public getSelectW3Sub: any;
    public insertDWRSub: any;
    public insertW3ASub: any;
    public insertW3Sub: any;


    constructor(private router: Router,
                private headerSvc: HeaderService,
                private route: ActivatedRoute,
                private wellSvc: WellService,
                private teamSvc: TeamService,
                private employeeSvc: EmployeeService,
                private svc: WsService,
                private dbSvc: DbService,
                private addUserSvc: AddEmployeeService,
                private addTeamSvc: AddTeamService,
                private addWellSvc: AddWellService,
                private isOnlineSvc: OnlineService,
                private loadingSvc: LoadingService,
                private lokiSrc: LokiService) {

        this.getAllWellsSub = this.lokiSrc.returnCallSub().subscribe(coll => {
            if (coll) {
                this.getWells = coll.by('name', 'getWell');
                this.getWellUserMetadata = coll.by('name', 'getWellUserMetaData');
                this.getTags = coll.by('name', 'getTags');
                this.getUser = coll.by('name', 'getUser');
                this.getTeam = coll.by('name', 'getTeam');
                this.getSelectDWR = coll.by('name', 'selectDWR');
                this.getSelectW3A = coll.by('name', 'selectW3A');
                this.getSelectW3 = coll.by('name', 'selectW3');
                this.insertDWR = coll.by('name', 'insertDWR');
                this.insertW3A = coll.by('name', 'insertW3A');
                this.insertW3 = coll.by('name', 'insertW3');
                this.switchData();
                this.getEditedItems();
            }
        });

        this.headerSub = this.headerSvc.getIsActive().subscribe(isActive => {
            this.isActive = isActive;
        });


    }

    ngOnInit() {
    }

    ngOnDestroy() {

        if (this.insertDWRSub) {
            this.insertDWRSub.unsubscribe();
        }
        if (this.getWellsSub) {
            this.getWellsSub.unsubscribe();
        }
        if (this.insertW3ASub) {
            this.insertW3ASub.unsubscribe();
        }
        if (this.insertW3Sub) {
            this.insertW3Sub.unsubscribe();
        }
        if (this.getTeamSub) {
            this.getTeamSub.unsubscribe();
        }
        if (this.getUserSub) {
            this.getUserSub.unsubscribe();
        }
        if (this.getTagsSub) {
            this.getTagsSub.unsubscribe();
        }
        if (this.getSelectDWRSub) {
            this.getSelectDWRSub.unsubscribe();
        }
        if (this.getSelectW3ASub) {
            this.getSelectW3ASub.unsubscribe();
        }
        if (this.getSelectW3Sub) {
            this.getSelectW3Sub.unsubscribe();
        }
        if (this.wellSub) {
            this.wellSub.unsubscribe();
        }

        if (this.getAllWellsSub) {
            this.getAllWellsSub.unsubscribe();
        }
        if (this.teamSub) {
            this.teamSub.unsubscribe();
        }
        if (this.employeeSub) {
            this.employeeSub.unsubscribe();
        }
        if (this.dwrSub) {
            this.dwrSub.unsubscribe();
        }
        if (this.w3Sub) {
            this.w3Sub.unsubscribe();
        }
        if (this.w3aSub) {
            this.w3aSub.unsubscribe();
        }
        if (this.tagsSub) {
            this.tagsSub.unsubscribe();
        }
        if (this.headerSub) {
            this.headerSub.unsubscribe();
        }
    }

    toggleBarFn() {
        this.toggleBar.emit(!this.isBar);
    }

    setPage(page) {
        this.router.navigate([page]);
    }

    stopProp(e) {
        e.stopPropagation();
    }

    selectedTags(tag, isActive) {
        if (isActive) {
            this.activeTags.push(tag);
        } else {
            const l = this.activeTags.length;
            for (let i = 0; i < l; i++) {
                if (this.activeTags[i] === tag) {
                    this.activeTags.splice(i, 1);
                }
            }
        }
    }

    setActiveWellStatus(i) {
        if (this.activeWellStatus === i) {
            this.activeWellStatus = null;
        } else {
            this.activeWellStatus = i;
        }
    }

    setActiveEmployeeStatus(i) {
        if (this.activeEmployeeGroups === i) {
            this.activeEmployeeGroups = null;
        } else {
            this.activeEmployeeGroups = i;
        }
    }

    setDataInDb(key) {
        const l = this[key].length;
        this.dbSvc.openDatabase().then(() => {
            for (let i = 0; i < l; i++) {
                this[key][i].isEdit = 0;
                if (key === 'wells') {
                    this.wells[i].metadata = this.wellUserMetadata[i].metadata;
                }
                this.dbSvc.update(key, this[key][i]).then(
                    (e) => {
                    },
                    error => {
                    }
                );
            }
        });
    }

    switchData() {
        let count = 0;
        this.wellSub = this.getWells.req(this.svc).subscribe(wells => {
            if (wells) {
                count++;
                this.wells = wells.body.records;
                if (this.wellUserMetadata && (this.wellUserMetadata.length === this.wells.length)) {
                    this.setDataInDb('wells');
                }
                this.wellSvc.setWellData(this.wells);
                if (count >= 8) {
                    this.dbSvc.setDbReady();
                    count = 0;
                }
            }
            this.loadingSvc.endLoading();
        });

        this.wellMetaSub = this.getWellUserMetadata.req(this.svc).subscribe(wellUserMetadata => {
            if (wellUserMetadata) {
                count++;
                this.wellUserMetadata = wellUserMetadata.body.records;
                if (this.wells && this.wells[0] && !this.wells[0].metadata) {
                    this.setDataInDb('wells');
                }
                if (count >= 8) {
                    this.dbSvc.setDbReady();
                    count = 0;
                }
            }
            this.loadingSvc.endLoading();
        });

        this.tagsSub = this.getTags.req(this.svc).subscribe(tags => {
            if (tags) {
                count++;
                this.tags = tags.body.tags;
                if (count >= 8) {
                    this.dbSvc.setDbReady();
                    count = 0;
                }
            }
            this.loadingSvc.endLoading();
        });

        this.teamSub = this.getTeam.req(this.svc).subscribe(teams => {
            if (teams) {
                count++;
                this.teams = teams.body.records;
                this.teamSvc.setTeamData(this.teams);
                this.setDataInDb('teams');
                if (count >= 8) {
                    this.dbSvc.setDbReady();
                    count = 0;
                }
            }
            this.loadingSvc.endLoading();
        });

        this.employeeSub = this.getUser.req(this.svc).subscribe(users => {
            if (users) {
                count++;
                this.users = users.body.records;
                this.employeeSvc.setEmployeeData(this.users);
                this.setDataInDb('users');
                if (count >= 8) {
                    this.dbSvc.setDbReady();
                    count = 0;
                }
            }
            this.loadingSvc.endLoading();
        });

        this.dwrSub = this.getSelectDWR.req(this.svc).subscribe(dwr => {
            if (dwr) {
                count++;
                const l = dwr.body.records.length;
                this.dbSvc.openDatabase().then(() => {
                    for (let i = 0; i < l; i++) {
                        dwr.body.records[i].isEdit = 0;
                        this.dbSvc.update('dwr', dwr.body.records[i]).then(
                            (e) => {
                            },
                            error => {
                            }
                        );
                    }
                });
                if (count >= 8) {
                    this.dbSvc.setDbReady();
                    count = 0;
                }
            }
            this.loadingSvc.endLoading();
        });
        this.w3aSub = this.getSelectW3A.req(this.svc).subscribe(w3a => {
            if (w3a) {
                count++;
                const l = w3a.body.records.length;
                this.dbSvc.openDatabase().then(() => {
                    for (let i = 0; i < l; i++) {
                        w3a.body.records[i].isEdit = 0;
                        this.dbSvc.update('w3a', w3a.body.records[i]).then(
                            (e) => {
                            },
                            error => {
                            }
                        );
                    }
                });
                if (count >= 8) {
                    this.dbSvc.setDbReady();
                    count = 0;
                }
            }
            this.loadingSvc.endLoading();
        });

        this.w3Sub = this.getSelectW3.req(this.svc).subscribe(w3 => {
            if (w3) {
                count++;
                const l = w3.body.records.length;
                this.dbSvc.openDatabase().then(() => {
                    for (let i = 0; i < l; i++) {
                        w3.body.records[i].isEdit = 0;

                        this.dbSvc.update('w3', w3.body.records[i]).then(
                            (e) => {
                            },
                            error => {
                            }
                        );
                    }
                });

                if (count >= 8) {
                    this.dbSvc.setDbReady();
                    count = 0;
                }
            }
            this.loadingSvc.endLoading();
        });
    }

    getOfflineData() {
        this.dbSvc.openDatabase().then(() => {
            this.dbSvc.getAll('wells').then(
                wells => {
                    this.wells = wells;
                    this.wellSvc.setWellData(this.wells);
                },
                error => {
                }
            );
            this.dbSvc.getAll('teams').then(
                teams => {
                    this.teams = teams;
                    this.teamSvc.setTeamData(this.teams);
                },
                error => {
                }
            );
            this.dbSvc.getAll('users').then(
                users => {
                    this.users = users;
                    this.employeeSvc.setEmployeeData(this.users);
                },
                error => {
                }
            );
        });
    }

    setWellDataPage(id, name) {
        const sid = id.split('/').join(' ');
        this.headerSvc.setUrlParams(name);
        this.router.navigate(['well/well-form', sid]);
    }

    setTeamDataPage(id, name) {
        const sid = id.split('/').join(' ');
        this.headerSvc.setUrlParams(name);
        this.router.navigate(['team', sid]);
    }

    setEmployeeDataPage(id, name) {
        const sid = id.split('/').join(' ');
        this.headerSvc.setUrlParams(name);
        this.router.navigate(['employee', sid]);
    }

    setHeaderTitle(title, page) {
        this.headerSvc.setUrlParams(title);
        switch (page) {
            case 'well':
                this.addWellSvc.setEditItemName(null);
                break;
            case 'team':
                this.addTeamSvc.setEditItemName(null);
                break;
            case 'user':
                this.addUserSvc.setEditItemName(null);
                break;
            default:
        }
    }

    getEditedItems() {
        const l = this.dataKeys.length;
        this.dbSvc.openDatabase().then(() => {
            for (let i = 0; i < l; i++) {
                this.dbSvc.getAllByIndexAndValue(this.dataKeys[i], 'isEdit', 1)
                    .then(
                        res => {
                            if (res[0]) {
                                const rl = res.length;
                                switch (this.dataKeys[i]) {
                                    case 'wells':
                                        break;
                                    case 'teams':
                                        break;
                                    case 'users':
                                        break;
                                    case 'dwr':
                                        for (let x = 0; x < rl; x++) {
                                            const id = res[x].id;
                                            if (typeof res[x].id === 'number') {
                                                delete res[x].id;
                                            }
                                            this.insertDWRSub = this.insertDWR.req(res[x], this.svc).subscribe(res => {
                                                console.log(res, 'navInsertDwr');
                                            });
                                            this.dbSvc.delete('dwr', id);
                                        }
                                        break;
                                    case 'w3a':
                                        for (let x = 0; x < rl; x++) {
                                            const id = res[x].id;
                                            if (typeof res[x].id === 'number') {
                                                delete res[x].id;
                                            }
                                            this.insertW3ASub = this.insertW3A.req(res[x], this.svc).subscribe(res => {
                                                console.log(res, 'navInsertW3A');
                                            });
                                            this.dbSvc.delete('w3a', id);
                                        }
                                        break;
                                    case 'w3':
                                        for (let x = 0; x < rl; x++) {
                                            const id = res[x].id;
                                            if (typeof res[x].id === 'number') {
                                                delete res[x].id;
                                            }
                                            this.insertW3Sub = this.insertW3.req(res[x], this.svc).subscribe(res => {
                                                console.log(res, 'navInsertW3');
                                            });
                                            this.dbSvc.delete('w3', id);
                                        }
                                        break;
                                }
                            }
                        },
                        error => {
                        }
                    );
            }
            this.getWellsSub = this.getWells.req(this.svc).subscribe();
            this.getWellUserMetadataSub = this.getWellUserMetadata.req(this.svc).subscribe();
            this.getTeamSub = this.getTeam.req(this.svc).subscribe();
            this.getUserSub = this.getUser.req(this.svc).subscribe();
            this.getTagsSub = this.getTags.req(this.svc).subscribe();
            this.getSelectDWRSub = this.getSelectDWR.req(this.svc).subscribe();
            this.getSelectW3ASub = this.getSelectW3A.req(this.svc).subscribe();
            this.getSelectW3Sub = this.getSelectW3.req(this.svc).subscribe();
        });
    }
}
