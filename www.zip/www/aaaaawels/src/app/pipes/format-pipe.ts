import { Pipe, PipeTransform } from '@angular/core';


@Pipe({
  name: 'customFormat'
})
export class FormatPipe implements PipeTransform {
  transform(number: number) {
    if (number) {
      return number.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
    } else {
      if (number === 0) {
        return number;
      }
    }
  }
}
