import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DwrFormComponent } from './dwr-form.component';

describe('DwrFormComponent', () => {
  let component: DwrFormComponent;
  let fixture: ComponentFixture<DwrFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DwrFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DwrFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
