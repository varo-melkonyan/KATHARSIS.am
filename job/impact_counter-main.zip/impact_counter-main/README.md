# impact_counter
Impact counter tool
