import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';

import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {LoginComponent} from './login/login.component';
import {RegistrComponent} from './registr/registr.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {RegistrModule} from './registr/registr.module';
import {RegistrGuard} from './registr.guard';
import { DataComponent } from './data/data.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrComponent,
    DataComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    RegistrModule,
    FormsModule
  ],
  providers: [RegistrGuard],
  bootstrap: [AppComponent]
})
export class AppModule {
}
