import {Component, OnDestroy, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import hexToBase64 from '../../constants/hexBase64';
import * as sha256 from 'sha256';
import {ActivatedRoute, Router} from '@angular/router';
import {appConfig} from '../../constants/app.config';
import {WsService} from '../../services/ws.service';
import {AlertService} from '../../services/alert.service';
import {LokiService} from '../../services/loki.service';


@Component({
    selector: 'app-signin',
    templateUrl: './signin.component.html',
    styleUrls: ['./signin.component.scss']
})
export class SigninComponent implements OnInit, OnDestroy {
    public signForm: FormGroup;
    private closeSub: any;
    private openSub: any;
    private thisUserSub: any;
    public getUserOne: any;
    public returnOpenConnect: any;
    public getUserOneSub: any;

    constructor(private fb: FormBuilder,
                private alertService: AlertService,
                private wsSvc: WsService,
                private route: ActivatedRoute,
                private router: Router,
                private lokiSvc: LokiService) {
        this.closeSub = this.lokiSvc.returnCallSub().subscribe(coll => {
                if (coll) {
                    this.getUserOne = coll.by('name', 'getUserOne');
                    this.returnOpenConnect = coll.by('name', 'connectionEstablished');
                }
            }
        );
    }

    ngOnInit() {
        localStorage.removeItem('sign');
        localStorage.removeItem('userId');
        this.initForm();
    }

    ngOnDestroy() {
        if (this.getUserOneSub) {
            this.getUserOneSub.unsubscribe();
        }
        if (this.closeSub) {
            this.closeSub.unsubscribe();
        }
        if (this.openSub) {
            this.openSub.unsubscribe();
        }
        if (this.thisUserSub) {
            this.thisUserSub.unsubscribe();
        }
    }

    initForm() {
        this.signForm = this.fb.group({
            userName: ['', [Validators.required, Validators.email]],
            password: ['', Validators.required]
        });
    }

    get f() {
        return this.signForm.controls;
    }

    markFormGroupTouched(formGroup: FormGroup) {
        (<any>Object).values(formGroup.controls).forEach(control => {
            control.markAsTouched();

            if (control.controls) {
                this.markFormGroupTouched(control);
            }
        });
    }

    success(message: string) {
        this.alertService.success(message);
    }

    error(message: string) {
        this.alertService.error(message);
    }

    onSubmit() {
        this.markFormGroupTouched(this.signForm);
        if (this.signForm.valid) {
            const pass = hexToBase64(sha256(this.signForm.value.password));
            this.wsSvc.wsFn(this.signForm.value.userName, pass);
            this.closeSub = this.wsSvc.returnCloseConnect().subscribe(res => {
                if (res) {
                    this.error('That email / password combination is not valid');
                }
                this.closeSub.unsubscribe();
            });
            this.openSub = this.returnOpenConnect.get(this.wsSvc).subscribe(res => {
                if (res) {
                    const sign = this.signForm.value;
                    localStorage.setItem('sign', JSON.stringify({userName: sign.userName, password: pass}));
                    this.getUserOneSub = this.getUserOne.req(sign.userName, this.wsSvc).subscribe();
                    setTimeout(() => {
                        this.router.navigate([appConfig.defaultHomePage]);
                    });
                }
                this.openSub.unsubscribe();
            });
        }
    }

}
