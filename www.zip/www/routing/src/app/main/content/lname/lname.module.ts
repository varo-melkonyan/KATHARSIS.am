import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {LnameRoutingModule} from './lname-routing.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    LnameRoutingModule
  ]
})
export class LnameModule { }
