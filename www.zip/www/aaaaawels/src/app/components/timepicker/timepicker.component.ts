import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';

@Component({
    selector: 'app-timepicker',
    templateUrl: './timepicker.component.html',
    styleUrls: ['./timepicker.component.scss']
})
export class TimepickerComponent implements OnInit, OnChanges {
    @Input() inputForm: any;
    @Output() outTime: EventEmitter<any> = new EventEmitter<any>();
    public hour: string;
    public min: any;
    public showTimePiker = false;
    public selected = false;
    public selectedHour: string = null;
    public selectedMin: string = null;
    public hours: string[] = [];
    public minutes: string[] = ['00', '30'];
    public ampm = 0;

    constructor() {
        document.body.addEventListener('click', () => {
            this.showTimePiker = false;
        });
    }

    ngOnInit() {
        for (let i = 0; i < 13; i++) {
            this.hours.push(i < 10 ? `0${i}` : i.toString());
        }
    }

    ngOnChanges(changes: SimpleChanges) {
        if (changes.inputForm.currentValue.value[0] > 12) {
            this.ampm = 1;
        } else {
            this.ampm = 0;
        }
        const val = this.valueSanitizer(Object.assign([], typeof changes.inputForm.currentValue.value === 'string' ?
            changes.inputForm.currentValue.value.split(':') : changes.inputForm.currentValue.value));
        this.hour = this.selectedHour = val[0];
        this.min = this.selectedMin = val[1];
        this.outputValue();
    }

    selectHour(index: string) {
        this.selectedHour = index;
    }

    selectMin(index: string) {
        this.selectedMin = index;
    }

    toggle() {
        this.showTimePiker = !this.showTimePiker;
    }

    validValue(event) {
        return event.charCode >= 48 && event.charCode <= 57;
    }

    calcValue(event, isHour, max) {
        if (+event.target.value > max) {
            isHour ? event.target.value = this.hour = max : event.target.value = this.min = max;
        }
        if (event.target.value.length === 1) {
            isHour ? event.target.value = this.hour = `0${event.target.value}` : event.target.value = this.min = `0${event.target.value}`;
        }
        if (event.target.value.length > 2 && event.target.value[0] === '0') {
            isHour ? event.target.value = this.hour = event.target.value.substring(1) :
                event.target.value = this.min = event.target.value.substring(1);
        }
        this.selectedHour = this.hour;
        this.selectedMin = this.min;
    }

    sanitizerAfterFocus(event: any, isHour = true) {
        event = this.initSanitize(event, isHour);
        this.outputValue();
    }

    valueSanitizer(value: any) {
        if (Array.isArray(value)) {
            const l = value.length;
            for (let i = 0; i < l; i++) {
                value[i] = this.initSanitize(value[i], i === 0);
            }
        }
        return value;
    }

    initSanitize(value: any, isHour = true) {
        value = value !== undefined ? value.toString() : value;
        if (isHour) {
            value = this.calculateAmPm(value);
        }
        if (value.length === 1) {
            value = `0${value}`;
        }
        return value;
    }

    calculateAmPm(value: any) {
        if (+value > 12) {
            if (+this.min > 0) {
                this.ampm = 1;
            }
            value = (value - 12).toString();
        }
        return value;
    }

    outputValue() {
        let value: any = [];
        value[0] = this.hour;
        value[1] = this.min;
        if (this.ampm > 0) {
            value[0] = (+value[0] + 12).toString();
        }
        value[0] = (!value[0] && value[1]) ? '00' : value[0];
        value[1] = (value[0] && !value[1]) ? '00' : value[1];
        if (!value[0] && !value[1]) {
            value = '';
        } else {
            value = value.join(':');
        }
        this.outTime.emit(value);
    }

    setValue() {
        this.hour =  this.selectedHour;
        this.min = this.selectedMin;
        this.outputValue();
    }
}
