import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/shared.module';
import { WellRoutingModule } from './well-routing.module';

@NgModule({
  imports: [
    SharedModule,
    WellRoutingModule
  ],
  declarations: [],
  exports: [],
  providers: []
})
export class WellModule {
}
