import {Component, OnInit} from '@angular/core';
import {ChildappService} from './childapp/childapp.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [ChildappService]
})
export class AppComponent {

  constructor(public src: ChildappService) {
    this.src.getData();
  }


  setData(): void {
    this.src.setData(console.log(54));
  }

}
