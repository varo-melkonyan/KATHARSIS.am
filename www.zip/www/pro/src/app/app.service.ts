import {Injectable} from '@angular/core';
import * as loki from 'lokijs';
import * as lokiIndexed from 'lokijs/src/loki-indexed-adapter.js';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  public idbAdapter;
  public db;
  public coll;
  public id;

  constructor() {
    this.idbAdapter = new lokiIndexed('data');
    this.db = new loki('register', {adapter: this.idbAdapter});
  }

  getData(): any {
    this.db.loadDatabase({}, () => {
      this.coll = this.db.getCollection('users');
      if (!this.coll) {
        this.coll = this.db.addCollection('users', {unique: ['name']}, {unique: ['lastname']}, {unique: ['email']}, {unique: ['pass']});
      }
      return this.coll;
    });
  }

  addData(data): void {
    this.coll.insert(data);
    this.db.saveDatabase();
  }

  setId(id): void {
    this.id = id;
  }

  getId(): any {
    return this.id;
  }
}
