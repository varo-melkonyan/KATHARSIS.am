import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'teamFilter'
})
export class TeamFilterPipe implements PipeTransform {
  transform(items: any, name: string, supervisor: string, tag: string) {
    if (items && items.length) {
      return items.filter(item => {
        if (name && item.name.toLowerCase().indexOf(name.toLowerCase()) === -1) {
          return false;
        }
        if (supervisor && (item.supervisor.firstName + ' ' + item.supervisor.lastName)
            .toLowerCase().indexOf(supervisor.toLowerCase()) === -1) {
          return false;
        }
        if (tag) {
          const l = item.crewmen.length;
          item.cewmenNames = [];
          for (let i = 0; i < l; i++) {
            item.cewmenNames.push(item.crewmen[i].firstName + ' ' + item.crewmen[i].lastName);
          }
        }
        if (tag && item.cewmenNames && item.cewmenNames.toString().toLowerCase().indexOf(tag.toLowerCase()) === -1) {
          return false;
        }
        return true;
      });
    } else {
      return items;
    }
  }
}
