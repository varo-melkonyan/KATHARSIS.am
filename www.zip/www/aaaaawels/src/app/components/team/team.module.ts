import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/shared.module';
import { TeamRoutingModule } from './team-routing.module';




@NgModule({
  imports: [
    SharedModule,
    TeamRoutingModule,
  ],
  declarations: [],
  providers: []
})
export class TeamModule {
}
