import {Component, OnDestroy, OnInit} from '@angular/core';
import {FormArray, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {LoadingService} from '../../../services/loading.service';
import {AddWellService} from '../add-well.service';
import {appConfig} from '../../../constants/app.config';
import {WsService} from '../../../services/ws.service';
import {Router} from '@angular/router';
import {AlertService} from '../../../services/alert.service';
import {saveAs} from 'file-saver';
import {DbService} from '../../../services/db.service';
import {OnlineService} from '../../../services/online.service';
import UID from '../../../constants/uid';
import {AccessLevel, FormType} from '../../../constants/app.enums';
import {MatSnackBar} from '@angular/material/snack-bar';
import {LokiService} from '../../../services/loki.service';

@Component({
    selector: 'app-w3-form',
    templateUrl: './w3-form.component.html',
    styleUrls: ['./w3-form.component.scss']
})
export class W3FormComponent implements OnInit, OnDestroy {
    public accessLevelEnum = AccessLevel;
    private nonDriableMaterialSub: any;
    private rrcRulesSub: any;
    private logReleasedToSub: any;
    private addWellSub: any;
    private wellId: string;
    private insertW3Sub: any;
    private dbReady: any;

    public w3Form: FormGroup;
    public formType = FormType;
    public sizeOfHoleValues = [
        '4-1/2',
        '5',
        '5-1/2',
        '6-5/8',
        '7',
        '7-5/8',
        '8-5/8',
        '9-5/8',
        '10-3/4',
        '11-3/4',
        '13-3/8',
        '16',
        '18-5/8',
        '20'
    ];
    public typeCement = [
        'C',
        'S',
        'A',
        'F',
        'H',
        'S̅',
    ];
    public leftInWell = [
        '3-7/8',
        '3-3/4',
        '4-1/4',
        '4-3/4',
        '4-5/8',
        '5-5/8',
        '6',
        '6-1/2',
        '6-1/4',
        '6-1/8',
        '6-3/4',
        '7-7/8',
        '8-1/2',
        '8-3/4',
        '8-5/8',
        '9-7/8',
        '11',
        '12-1/4',
        '17-1/2'
    ];
    public accessLevel = appConfig.accessLevel;
    public managerSign: any;
    public supervisorSign: any;
    public successes = true;
    public mobileUser = appConfig.mobileUser;
    public isOnline: boolean;
    public transferSub: any;
    public autoSaveInterval: any;
    public setTransfer: any;
    public transSub: any;
    public insertW3: any;
    public getWells: any;
    public selectW3: any;
    public getWellsSub: any;
    public selectW3Sub: any;


    constructor(private fb: FormBuilder,
                private addWellSvc: AddWellService,
                private svc: WsService,
                private dbSvc: DbService,
                private router: Router,
                private isOnlineSvc: OnlineService,
                private alertService: AlertService,
                private snackBar: MatSnackBar,
                private loadingSvc: LoadingService,
                private lokiSvc: LokiService) {
        this.isOnlineSvc.getIsOnline().subscribe(isOnline => {
            this.isOnline = isOnline;
        });
        this.dbReady = this.dbSvc.getDbReady().subscribe(ready => {
                if (this.addWellSub) {
                    this.addWellSub.unsubscribe();
                }
            if (ready) {
                this.addWellSub = this.addWellSvc.getEditItemName().subscribe(id => {
                    if (id) {
                        this.wellId = id.split(' ').join('/');
                        setTimeout(() => {
                            this.dbSvc.openDatabase().then(() => {

                                this.dbSvc.getByIndex('w3', 'wellId', this.wellId).then(
                                    w3 => {
                                        if (this.nonDriableMaterialSub) {
                                            this.nonDriableMaterialSub.unsubscribe();
                                        }
                                        if (this.rrcRulesSub) {
                                            this.rrcRulesSub.unsubscribe();
                                        }
                                        if (this.logReleasedToSub) {
                                            this.logReleasedToSub.unsubscribe();
                                        }
                                        if (w3) {
                                            setTimeout(() => {
                                                this.managerSign = w3.managerSign;
                                                this.supervisorSign = w3.supervisorSign;
                                                this.initForm(w3);
                                            });
                                        } else {
                                            this.initForm();
                                        }
                                    },
                                    error => {
                                    }
                                );
                            });
                        });
                    }
                });
            }
        });
        this.transSub = this.lokiSvc.returnCallSub().subscribe(coll => {
            if (coll) {
                this.setTransfer = coll.by('name', 'setTransferForm');
                this.insertW3 = coll.by('name', 'insertW3');
                this.getWells = coll.by('name', 'getWell');
                this.selectW3 = coll.by('name', 'selectW3');
            }
        });
    }

    ngOnInit() {
    }

    ngOnDestroy() {
        if (this.autoSaveInterval) {
            clearInterval(this.autoSaveInterval);
        }
        if (this.selectW3Sub) {
            this.selectW3Sub.unsubscribe();
        }
        if (this.getWellsSub) {
            this.getWellsSub.unsubscribe();
        }
        if (this.nonDriableMaterialSub) {
            this.nonDriableMaterialSub.unsubscribe();
        }
        if (this.rrcRulesSub) {
            this.rrcRulesSub.unsubscribe();
        }
        if (this.addWellSub) {
            this.addWellSub.unsubscribe();
        }
        if (this.logReleasedToSub) {
            this.logReleasedToSub.unsubscribe();
        }
        if (this.insertW3Sub) {
            this.insertW3Sub.unsubscribe();
        }
        if (this.transferSub) {
            this.transferSub.unsubscribe();
        }
        if (this.dbReady) {
            this.dbReady.unsubscribe();
        }
    }

    initForm(item?) {
        if (this.autoSaveInterval) {
            clearInterval(this.autoSaveInterval);
        }
        this.successes = (item && (item.supervisorSign || item.managerSign));
        this.w3Form = this.fb.group({
            assigneeAccessLevel: item && (item.assigneeAccessLevel || item.assigneeAccessLevel === 0) ?
                item.assigneeAccessLevel : this.accessLevel,
            status: [item ? item.status : null],
            supervisorSign: item ? item.supervisorSign : null,
            managerSign: item ? item.managerSign : null,
            wellId: [this.wellId],
            id: [item ? item.id : ''],
            jobNumber: [item ? item.jobNumber : null],
            apiNumber: [item ? item.apiNumber : ''],
            rrcDistrict: [item ? item.rrcDistrict : ''],
            fieldName: [item ? item.fieldName : ''],
            leaseName: [item ? item.leaseName : ''],
            rrcLeaseIdNumber: [item ? item.rrcLeaseIdNumber : null],
            wellNumber1: [item ? item.wellNumber1 : null],
            operatorName: [item ? item.operatorName : ''],
            w1FiledName: [item ? item.w1FiledName : ''],
            subsequentW1FiledName: [item ? item.subsequentW1FiledName : ''],
            address: [item ? item.address : ''],
            leaseDistance1: [item ? item.leaseDistance1 : null],
            leaseDirection1: [item ? item.leaseDirection1 : ''],
            leaseDistance2: [item ? item.leaseDistance2 : null],
            leaseDirection2: [item ? item.leaseDirection2 : ''],
            lease: [item ? item.lease : ''],
            sectionBlockAndSurvey: [item ? item.sectionBlockAndSurvey : ''],
            distanceDirectionNearestTown: [item ? item.distanceDirectionNearestTown : ''],
            country: [item ? item.country : ''],
            drillingPermitIssuedDate: [item && !!item.drillingPermitIssuedDate ?
                new Date(+new Date(item.drillingPermitIssuedDate)).toISOString().substring(0, 10) : null],
            permitNumber: [item ? item.permitNumber : null],
            drillingCommencedDate: [item && !!item.drillingCommencedDate ?
                new Date(+new Date(item.drillingCommencedDate)).toISOString().substring(0, 10) : null],
            drillingCompletedDate: [item && !!item.drillingCompletedDate ?
                new Date(+new Date(item.drillingCompletedDate)).toISOString().substring(0, 10) : null],
            wellPluggedDate: [item && !!item.wellPluggedDate ?
                new Date(+new Date(item.wellPluggedDate)).toISOString().substring(0, 10) : null],
            wellType: [item ? item.wellType : ''],
            totalDepth1: [item ? item.totalDepth1 : null],
            gasIdOrOilLease: [item ? item.gasIdOrOilLease : ''],
            oilOGasG: [item ? item.oilOGasG : ''],
            wellNumber2: [item ? item.wellNumber2 : ''],
            gasAtTimePlugging: [item ? item.gasAtTimePlugging : ''],
            cementingDate: this.fb.group({
                plug1: [(item && item.cementingDate && item.cementingDate.plug1) ? item.cementingDate.plug1 : null],
                plug2: [(item && item.cementingDate && item.cementingDate.plug2) ? item.cementingDate.plug2 : null],
                plug3: [(item && item.cementingDate && item.cementingDate.plug3) ? item.cementingDate.plug3 : null],
                plug4: [(item && item.cementingDate && item.cementingDate.plug4) ? item.cementingDate.plug4 : null],
                plug5: [(item && item.cementingDate && item.cementingDate.plug5) ? item.cementingDate.plug5 : null],
                plug6: [(item && item.cementingDate && item.cementingDate.plug6) ? item.cementingDate.plug6 : null],
                plug7: [(item && item.cementingDate && item.cementingDate.plug7) ? item.cementingDate.plug7 : null],
                plug8: [(item && item.cementingDate && item.cementingDate.plug8) ? item.cementingDate.plug8 : null]
            }),
            holeOrPipeSize: this.fb.group({
                plug1: [(item && item.holeOrPipeSize && item.holeOrPipeSize.plug1) ? item.holeOrPipeSize.plug1 : null],
                plug2: [(item && item.holeOrPipeSize && item.holeOrPipeSize.plug2) ? item.holeOrPipeSize.plug2 : null],
                plug3: [(item && item.holeOrPipeSize && item.holeOrPipeSize.plug3) ? item.holeOrPipeSize.plug3 : null],
                plug4: [(item && item.holeOrPipeSize && item.holeOrPipeSize.plug4) ? item.holeOrPipeSize.plug4 : null],
                plug5: [(item && item.holeOrPipeSize && item.holeOrPipeSize.plug5) ? item.holeOrPipeSize.plug5 : null],
                plug6: [(item && item.holeOrPipeSize && item.holeOrPipeSize.plug6) ? item.holeOrPipeSize.plug6 : null],
                plug7: [(item && item.holeOrPipeSize && item.holeOrPipeSize.plug7) ? item.holeOrPipeSize.plug7 : null],
                plug8: [(item && item.holeOrPipeSize && item.holeOrPipeSize.plug8) ? item.holeOrPipeSize.plug8 : null]
            }),
            tubingBottomDepth: this.fb.group({
                plug1: [(item && item.tubingBottomDepth && item.tubingBottomDepth.plug1) ? item.tubingBottomDepth.plug1 : null],
                plug2: [(item && item.tubingBottomDepth && item.tubingBottomDepth.plug2) ? item.tubingBottomDepth.plug2 : null],
                plug3: [(item && item.tubingBottomDepth && item.tubingBottomDepth.plug3) ? item.tubingBottomDepth.plug3 : null],
                plug4: [(item && item.tubingBottomDepth && item.tubingBottomDepth.plug4) ? item.tubingBottomDepth.plug4 : null],
                plug5: [(item && item.tubingBottomDepth && item.tubingBottomDepth.plug5) ? item.tubingBottomDepth.plug5 : null],
                plug6: [(item && item.tubingBottomDepth && item.tubingBottomDepth.plug6) ? item.tubingBottomDepth.plug6 : null],
                plug7: [(item && item.tubingBottomDepth && item.tubingBottomDepth.plug7) ? item.tubingBottomDepth.plug7 : null],
                plug8: [(item && item.tubingBottomDepth && item.tubingBottomDepth.plug8) ? item.tubingBottomDepth.plug8 : null]
            }),
            usedCementSacks: this.fb.group({
                plug1: [(item && item.usedCementSacks && item.usedCementSacks.plug1) ? item.usedCementSacks.plug1 : null],
                plug2: [(item && item.usedCementSacks && item.usedCementSacks.plug2) ? item.usedCementSacks.plug2 : null],
                plug3: [(item && item.usedCementSacks && item.usedCementSacks.plug3) ? item.usedCementSacks.plug3 : null],
                plug4: [(item && item.usedCementSacks && item.usedCementSacks.plug4) ? item.usedCementSacks.plug4 : null],
                plug5: [(item && item.usedCementSacks && item.usedCementSacks.plug5) ? item.usedCementSacks.plug5 : null],
                plug6: [(item && item.usedCementSacks && item.usedCementSacks.plug6) ? item.usedCementSacks.plug6 : null],
                plug7: [(item && item.usedCementSacks && item.usedCementSacks.plug7) ? item.usedCementSacks.plug7 : null],
                plug8: [(item && item.usedCementSacks && item.usedCementSacks.plug8) ? item.usedCementSacks.plug8 : null]
            }),
            pumpedSlurryVolume: this.fb.group({
                plug1: [(item && item.pumpedSlurryVolume && item.pumpedSlurryVolume.plug1) ? item.pumpedSlurryVolume.plug1 : null],
                plug2: [(item && item.pumpedSlurryVolume && item.pumpedSlurryVolume.plug2) ? item.pumpedSlurryVolume.plug2 : null],
                plug3: [(item && item.pumpedSlurryVolume && item.pumpedSlurryVolume.plug3) ? item.pumpedSlurryVolume.plug3 : null],
                plug4: [(item && item.pumpedSlurryVolume && item.pumpedSlurryVolume.plug4) ? item.pumpedSlurryVolume.plug4 : null],
                plug5: [(item && item.pumpedSlurryVolume && item.pumpedSlurryVolume.plug5) ? item.pumpedSlurryVolume.plug5 : null],
                plug6: [(item && item.pumpedSlurryVolume && item.pumpedSlurryVolume.plug6) ? item.pumpedSlurryVolume.plug6 : null],
                plug7: [(item && item.pumpedSlurryVolume && item.pumpedSlurryVolume.plug7) ? item.pumpedSlurryVolume.plug7 : null],
                plug8: [(item && item.pumpedSlurryVolume && item.pumpedSlurryVolume.plug8) ? item.pumpedSlurryVolume.plug8 : null]
            }),
            calculatedTop: this.fb.group({
                plug1: [(item && item.calculatedTop && item.calculatedTop.plug1) ? item.calculatedTop.plug1 : null],
                plug2: [(item && item.calculatedTop && item.calculatedTop.plug2) ? item.calculatedTop.plug2 : null],
                plug3: [(item && item.calculatedTop && item.calculatedTop.plug3) ? item.calculatedTop.plug3 : null],
                plug4: [(item && item.calculatedTop && item.calculatedTop.plug4) ? item.calculatedTop.plug4 : null],
                plug5: [(item && item.calculatedTop && item.calculatedTop.plug5) ? item.calculatedTop.plug5 : null],
                plug6: [(item && item.calculatedTop && item.calculatedTop.plug6) ? item.calculatedTop.plug6 : null],
                plug7: [(item && item.calculatedTop && item.calculatedTop.plug7) ? item.calculatedTop.plug7 : null],
                plug8: [(item && item.calculatedTop && item.calculatedTop.plug8) ? item.calculatedTop.plug8 : null]
            }),
            measuredTop: this.fb.group({
                plug1: [(item && item.measuredTop && item.measuredTop.plug1) ? item.measuredTop.plug1 : null],
                plug2: [(item && item.measuredTop && item.measuredTop.plug2) ? item.measuredTop.plug2 : null],
                plug3: [(item && item.measuredTop && item.measuredTop.plug3) ? item.measuredTop.plug3 : null],
                plug4: [(item && item.measuredTop && item.measuredTop.plug4) ? item.measuredTop.plug4 : null],
                plug5: [(item && item.measuredTop && item.measuredTop.plug5) ? item.measuredTop.plug5 : null],
                plug6: [(item && item.measuredTop && item.measuredTop.plug6) ? item.measuredTop.plug6 : null],
                plug7: [(item && item.measuredTop && item.measuredTop.plug7) ? item.measuredTop.plug7 : null],
                plug8: [(item && item.measuredTop && item.measuredTop.plug8) ? item.measuredTop.plug8 : null]
            }),
            slurryWt: this.fb.group({
                plug1: [(item && item.slurryWt && item.slurryWt.plug1) ? item.slurryWt.plug1 : null],
                plug2: [(item && item.slurryWt && item.slurryWt.plug2) ? item.slurryWt.plug2 : null],
                plug3: [(item && item.slurryWt && item.slurryWt.plug3) ? item.slurryWt.plug3 : null],
                plug4: [(item && item.slurryWt && item.slurryWt.plug4) ? item.slurryWt.plug4 : null],
                plug5: [(item && item.slurryWt && item.slurryWt.plug5) ? item.slurryWt.plug5 : null],
                plug6: [(item && item.slurryWt && item.slurryWt.plug6) ? item.slurryWt.plug6 : null],
                plug7: [(item && item.slurryWt && item.slurryWt.plug7) ? item.slurryWt.plug7 : null],
                plug8: [(item && item.slurryWt && item.slurryWt.plug8) ? item.slurryWt.plug8 : null]
            }),
            cementType: this.fb.group({
                plug1: [(item && item.cementType && item.cementType.plug1) ? item.cementType.plug1 : null],
                plug2: [(item && item.cementType && item.cementType.plug2) ? item.cementType.plug2 : null],
                plug3: [(item && item.cementType && item.cementType.plug3) ? item.cementType.plug3 : null],
                plug4: [(item && item.cementType && item.cementType.plug4) ? item.cementType.plug4 : null],
                plug5: [(item && item.cementType && item.cementType.plug5) ? item.cementType.plug5 : null],
                plug6: [(item && item.cementType && item.cementType.plug6) ? item.cementType.plug6 : null],
                plug7: [(item && item.cementType && item.cementType.plug7) ? item.cementType.plug7 : null],
                plug8: [(item && item.cementType && item.cementType.plug8) ? item.cementType.plug8 : null]
            }),
            casingTubingRecordAfterPlugging: item ? this.casingTubingRecordFn(item.casingTubingRecordAfterPlugging) :
                this.fb.array([this.casingTubingRecordFn()]),
            nonDriableMaterial: [item ? !!item.nonDriableMaterial : false],
            stateDepthOfJunk: [item ? item.stateDepthOfJunk : '',
                (item && !!item.nonDriableMaterial) ? [Validators.required] : []],
            perforatedIntervalsList: item ? this.perforatedIntervalsListFn(item.perforatedIntervalsList) :
                this.fb.array([this.perforatedIntervalsListFn()]),
            filledWithMudLaden: [item ? !!item.filledWithMudLaden : false],
            mudAppliedMethod: [item ? item.mudAppliedMethod : ''],
            mudWeight: [item ? item.mudWeight : null],
            totalDepth2: [item ? item.totalDepth2 : null],
            deepestFreshWaterDepth: [item ? item.deepestFreshWaterDepth : null],
            otherFreshWaterZones: item ? this.otherFreshWaterZonesFn(item.otherFreshWaterZones) :
                this.fb.array([this.otherFreshWaterZonesFn()]),
            rrcRules: [item ? !!item.rrcRules : false],
            explainance: [{
                value: item ? item.explainance : '',
                disabled: !item ? false : item && !item.rrcRules ? false : true
            }, (item && !item.rrcRules) ? Validators.required : ''],
            nameAddressCementingServiceCompany: [item ? item.nameAddressCementingServiceCompany : ''],
            rrcDistrictDate: [item && !!item.rrcDistrictDate ?
                new Date(+new Date(item.rrcDistrictDate)).toISOString().substring(0, 10) : null],
            nameAddressSurfaceOwner: [item ? item.nameAddressSurfaceOwner : ''],
            noticeGivenData: [item ? item.noticeGivenData : ''],
            logAttached: [item ? !!item.logAttached : false],
            logReleased: [item ? !!item.logReleased : false],
            logReleasedDescription: [item ? item.logReleasedDescription : '',
                (item && item.logReleased) ? [Validators.required] : []],
            logReleasedDate: [item && !!item.logReleasedDate ?
                new Date(+new Date(item.logReleasedDate)).toISOString().substring(0, 10) : null,
                (item && item.logReleased) ? [Validators.required] : []],
            drillersLog: [item ? !!item.drillersLog : false],
            electricLog: [item ? !!item.electricLog : false],
            radioactivityLog: [item ? !!item.radioactivityLog : false],
            acousticalSonicLog: [item ? !!item.acousticalSonicLog : false],
            dateFormP8: [item ? item.dateFormP8 : ''],
            producedOilAmount: [item ? item.producedOilAmount : null],
            remarks: [item ? item.remarks : '']
        });

        setTimeout(() => {
            if (item && !!item.nonDriableMaterial) {
                this.w3Form.get('stateDepthOfJunk').enable();
            } else {
                this.w3Form.get('stateDepthOfJunk').disable();
            }
            if (item && item.logReleased) {
                this.w3Form.get('logReleasedDescription').enable();
            } else {
                this.w3Form.get('logReleasedDescription').disable();
            }
            if (item && item.logReleased) {
                this.w3Form.get('logReleasedDate').enable();
            } else {
                this.w3Form.get('logReleasedDate').disable();
            }
        }, 100);

        this.nonDriableMaterialSub = this.w3Form.get('nonDriableMaterial').valueChanges.subscribe(value => {
            if (value) {
                this.w3Form.get('stateDepthOfJunk').enable();
                this.w3Form.get('stateDepthOfJunk').setValidators(Validators.required);
                this.w3Form.get('stateDepthOfJunk').setErrors({'required': true});
            } else {
                this.w3Form.get('stateDepthOfJunk').setValue('');
                this.w3Form.get('stateDepthOfJunk').disable();
                this.w3Form.get('stateDepthOfJunk').setValidators(null);
                this.w3Form.get('stateDepthOfJunk').setErrors({'required': false});
            }
        });
        this.rrcRulesSub = this.w3Form.get('rrcRules').valueChanges.subscribe(value => {
            if (!value) {
                this.w3Form.get('explainance').enable();
                this.w3Form.get('explainance').setValidators(Validators.required);
                this.w3Form.get('explainance').setErrors({'required': true});
            } else {
                this.w3Form.get('explainance').setValue('');
                this.w3Form.get('explainance').disable();
                this.w3Form.get('explainance').setValidators(null);
                this.w3Form.get('explainance').setErrors({'required': false});
            }
        });
        this.logReleasedToSub = this.w3Form.get('logReleased').valueChanges.subscribe(value => {
            if (value) {
                this.w3Form.get('logReleasedDescription').enable();
                this.w3Form.get('logReleasedDescription').setValidators(Validators.required);
                this.w3Form.get('logReleasedDescription').setErrors({'required': true});
                this.w3Form.get('logReleasedDate').enable();
                this.w3Form.get('logReleasedDate').setValidators(Validators.required);
                this.w3Form.get('logReleasedDate').setErrors({'required': true});
            } else {
                this.w3Form.get('logReleasedDescription').setValue('');
                this.w3Form.get('logReleasedDescription').disable();
                this.w3Form.get('logReleasedDescription').setValidators(null);
                this.w3Form.get('logReleasedDescription').setErrors({'required': false});
                this.w3Form.get('logReleasedDate').setValue('');
                this.w3Form.get('logReleasedDate').disable();
                this.w3Form.get('logReleasedDate').setValidators(null);
                this.w3Form.get('logReleasedDate').setErrors({'required': false});
            }
        });
        this.loadingSvc.endLoading();
        if (this.accessLevel === this.f['assigneeAccessLevel'].value) {
            this.autoSaveInterval = setInterval(() => {
                this.onSubmit(0);
            }, 180000);
        }/* else {
            this.openSnackBar('Your autosave is not working because you do not have access to save', 'skip');
        }*/
    }

    openSnackBar(message: string, action: string) {
        this.snackBar.open(message, action);
    }


    pickerValue(value: any, formItem: any) {
        formItem.setValue(value);
    }

    casingTubingRecordFn(array?) {
        if (array) {
            const l = array.length;
            const arr = this.fb.array([]);
            for (let i = 0; i < l; i++) {
                arr.push(this.fb.group({
                    size: [array[i].size],
                    wtft: [array[i].wtft],
                    putInWell: [array[i].putInWell],
                    leftInWell: [array[i].leftInWell],
                    holeSize: [array[i].holeSize]
                }));
            }
            return arr;
        } else {
            return this.fb.group({
                size: [''],
                wtft: [''],
                putInWell: [null],
                leftInWell: [null],
                holeSize: ['']
            });
        }
    }

    perforatedIntervalsListFn(array?) {
        if (array) {
            const l = array.length;
            const arr = this.fb.array([]);
            for (let i = 0; i < l; i++) {
                arr.push(this.fb.group({
                    from: [array[i].from],
                    to: [array[i].to]
                }));
            }
            return arr;
        } else {
            return this.fb.group({
                from: [null],
                to: [null]
            });
        }
    }

    otherFreshWaterZonesFn(array?) {
        if (array) {
            const l = array.length;
            const arr = this.fb.array([]);
            for (let i = 0; i < l; i++) {
                arr.push(this.fb.group({
                    top: [array[i].top],
                    bottom: [array[i].bottom]
                }));
            }
            return arr;
        } else {
            return this.fb.group({
                top: [null],
                bottom: [null]
            });
        }
    }

    addItem(elem, fn) {
        const items = this.formData(this.w3Form.get(elem));
        items.push(this[fn]());
    }

    deleteItem(index, elem) {
        const items = this.formData(this.w3Form.get(elem));
        items.removeAt(index);
    }

    formData(arr) {
        return <FormArray>arr;
    }

    get f() {
        return this.w3Form.controls;
    }

    markFormGroupTouched(formGroup: FormGroup) {
        (<any>Object).values(formGroup.controls).forEach(control => {
            control.markAsTouched();

            if (control.controls) {
                this.markFormGroupTouched(control);
            }
        });
    }

    success(message: string) {
        this.alertService.success(message);
    }

    error(message: string) {
        this.alertService.error(message);
    }

    tableToExcel(name) {
        const template = `<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
          xmlns:x="urn:schemas-microsoft-com:office:excel"
          xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
          xmlns:html="http://www.w3.org/TR/REC-html40">
    <DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">
        <Created>2017-08-30T07:31:14Z</Created>
        <LastSaved>2019-02-16T09:17:31Z</LastSaved>
        <Version>16.00</Version>
    </DocumentProperties>
    <OfficeDocumentSettings xmlns="urn:schemas-microsoft-com:office:office">
        <AllowPNG/>
        <RemovePersonalInformation/>
        <Colors>
            <Color>
                <Index>16</Index>
                <RGB>#8080FF</RGB>
            </Color>
            <Color>
                <Index>17</Index>
                <RGB>#802060</RGB>
            </Color>
            <Color>
                <Index>18</Index>
                <RGB>#FFFFC0</RGB>
            </Color>
            <Color>
                <Index>19</Index>
                <RGB>#A0E0E0</RGB>
            </Color>
            <Color>
                <Index>20</Index>
                <RGB>#600080</RGB>
            </Color>
            <Color>
                <Index>22</Index>
                <RGB>#0080C0</RGB>
            </Color>
            <Color>
                <Index>23</Index>
                <RGB>#C0C0FF</RGB>
            </Color>
            <Color>
                <Index>33</Index>
                <RGB>#69FFFF</RGB>
            </Color>
            <Color>
                <Index>36</Index>
                <RGB>#A6CAF0</RGB>
            </Color>
            <Color>
                <Index>37</Index>
                <RGB>#CC9CCC</RGB>
            </Color>
            <Color>
                <Index>39</Index>
                <RGB>#E3E3E3</RGB>
            </Color>
            <Color>
                <Index>42</Index>
                <RGB>#339933</RGB>
            </Color>
            <Color>
                <Index>43</Index>
                <RGB>#999933</RGB>
            </Color>
            <Color>
                <Index>44</Index>
                <RGB>#996633</RGB>
            </Color>
            <Color>
                <Index>45</Index>
                <RGB>#996666</RGB>
            </Color>
            <Color>
                <Index>48</Index>
                <RGB>#3333CC</RGB>
            </Color>
            <Color>
                <Index>49</Index>
                <RGB>#336666</RGB>
            </Color>
            <Color>
                <Index>52</Index>
                <RGB>#663300</RGB>
            </Color>
            <Color>
                <Index>55</Index>
                <RGB>#424242</RGB>
            </Color>
        </Colors>
    </OfficeDocumentSettings>
    <ExcelWorkbook xmlns="urn:schemas-microsoft-com:office:excel">
        <WindowHeight>15960</WindowHeight>
        <WindowWidth>28040</WindowWidth>
        <WindowTopX>380</WindowTopX>
        <WindowTopY>460</WindowTopY>
        <ActiveSheet>1</ActiveSheet>
        <ProtectStructure>True</ProtectStructure>
        <ProtectWindows>False</ProtectWindows>
    </ExcelWorkbook>
    <Styles>
        <Style ss:ID="Default" ss:Name="Normal">
            <Alignment ss:Vertical="Bottom"/>
            <Borders/>
            <Font ss:FontName="Arial" x:Family="Swiss"/>
            <Interior/>
            <NumberFormat/>
            <Protection/>
        </Style>
        <Style ss:ID="m105553180563028">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180571140">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180557412">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180774356">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180558560">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="9" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180558580">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="9" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180558600">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180558720">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181206480">
            <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181206500">
            <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181206520">
            <Alignment ss:Vertical="Top" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181206540">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="9" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181206560">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="9" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181206580">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="9" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181206600">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="9" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181206620">
            <Alignment ss:Horizontal="Left" ss:Vertical="Bottom" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181206640">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="9" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181206660">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="9" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181204816">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181204836">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181204856">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181204876">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181204896">
            <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"
                  ss:Bold="1"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181204916">
            <Alignment ss:Horizontal="Center" ss:Vertical="Center" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180564592">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180564612">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180564632">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180564652">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180564672">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180564692">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180564712">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180564732">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181206272">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181206292">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181206312">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181206332">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181206352">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181206372">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="0"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181206392">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="0"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181206412">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="0"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181205648">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181205668">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181205688">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181205708">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181205728">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181205748">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181205768">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181205788">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181201904">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181201924">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="mm/dd/yy;@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181201944">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="mm/dd/yy;@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181201964">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="mm/dd/yy;@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181201984">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181202004">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181202024">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181202044">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180784032">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180784052">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180784072">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="Short Date"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180784092">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180784112">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Color="#000000"
                  ss:Bold="1"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180784132">
            <Alignment ss:Horizontal="Center" ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Color="#000000"
                  ss:Bold="1"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180784152">
            <Alignment ss:Horizontal="Center" ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Color="#000000"
                  ss:Bold="1"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180784172">
            <Alignment ss:Horizontal="Center" ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Color="#000000"
                  ss:Bold="1"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180781764">
            <Alignment ss:Horizontal="Center" ss:Vertical="Top" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180781784">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180781804">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="9" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180781824">
            <Alignment ss:Horizontal="Left" ss:Vertical="Top" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180781844">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180781864">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180781884">
            <Alignment ss:Horizontal="Left" ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180781904">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180781924">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181197744">
            <Alignment ss:Vertical="Bottom" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181197764">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181197784">
            <Alignment ss:Horizontal="Center" ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181197804">
            <Alignment ss:Horizontal="Right" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181197824">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181197864">
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181197884">
            <Alignment ss:Vertical="Bottom" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181197904">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181197924">
            <Alignment ss:Horizontal="Center" ss:Vertical="Top" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180773484">
            <Alignment ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180773504">
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180773524">
            <Alignment ss:Vertical="Bottom" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180975024">
            <Alignment ss:Vertical="Bottom" ss:ShrinkToFit="1"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180975044">
            <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180975064">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180975164">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180975184">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180975204">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180563344">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180563364">
            <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180563384">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180563404">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180563424">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180563444">
            <Alignment ss:Vertical="Bottom" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180558144">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180558164">
            <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180558184">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180558204">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180558224">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180558244">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181209600">
            <Alignment ss:Horizontal="Center" ss:Vertical="Center" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181209620">
            <Alignment ss:Horizontal="Left" ss:Vertical="Top" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181209640">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181209660">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection/>
        </Style>
        <Style ss:ID="m105553181209680">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection/>
        </Style>
        <Style ss:ID="m105553181209700">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection/>
        </Style>
        <Style ss:ID="m105553181206728">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181206748">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181206768">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181206788">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181206808">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181206828">
            <Alignment ss:Horizontal="Left" ss:Vertical="Bottom" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180567752">
            <Alignment ss:Vertical="Top" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"
                  ss:Underline="Single"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180785320">
            <Alignment ss:Horizontal="Left" ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180785340">
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Color="#000000"
                  ss:Bold="1"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181201508">
            <Alignment ss:Vertical="Center"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553181201528">
            <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181201548">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181201568">
            <Alignment ss:Vertical="Center"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553181201608">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000" ss:Bold="1"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180970032">
            <Alignment ss:Vertical="Center"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180970052">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180970072">
            <Alignment ss:Vertical="Center"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"
                  ss:Bold="1"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180970092">
            <Alignment ss:Vertical="Center"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180970112">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180970132">
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180567296">
            <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Dash" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180567316">
            <Alignment ss:Vertical="Center" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Dash" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180567336">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Dash" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180567356">
            <Alignment ss:Vertical="Center"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Dash" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="Short Date"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180567376">
            <Alignment ss:Vertical="Center"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180567396">
            <Alignment ss:Vertical="Bottom" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"
                  ss:Underline="Single"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180562176">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Dash" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180557728">
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Dash" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180557788">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180557808">
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Dash" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180557868">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180557888">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Dash" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180784656">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Dash" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180966932">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180966952">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="m105553180966972">
            <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="m105553180967012">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Dash" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s62">
            <Font ss:FontName="Arial" x:Family="Swiss"/>
        </Style>
        <Style ss:ID="s63">
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s64">
            <Font ss:FontName="Arial" x:Family="Swiss"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s66">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="12" ss:Bold="1"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s67">
            <Alignment ss:Horizontal="Right" ss:Vertical="Bottom"/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s69">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="11"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s70">
            <Alignment ss:Horizontal="Right" ss:Vertical="Top" ss:WrapText="1"/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s71">
            <Alignment ss:Horizontal="CenterAcrossSelection" ss:Vertical="Bottom"/>
            <Borders/>
            <Font ss:FontName="Arial" x:Family="Swiss"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s72">
            <Alignment ss:Horizontal="CenterAcrossSelection" ss:Vertical="Bottom"/>
            <Font ss:FontName="Arial" x:Family="Swiss"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s73">
            <Alignment ss:Vertical="Top" ss:WrapText="1"/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s74">
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s75">
            <Borders/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s94">
            <Borders/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s95">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s96">
            <Alignment ss:Vertical="Bottom" ss:WrapText="1"/>
            <Borders/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s124">
            <Alignment ss:Horizontal="Left" ss:Vertical="Top" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s146">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s154">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s156">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s158">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s160">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s181">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s182">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s183">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s189">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s190">
            <Borders/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s191">
            <Borders>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s196">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s201">
            <Alignment ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s202">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s211">
            <Borders>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s234">
            <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s245">
            <Alignment ss:Horizontal="Center" ss:Vertical="Top" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s264">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom" ss:ShrinkToFit="1"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s302">
            <Alignment ss:Horizontal="Center" ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Color="#000000"
                  ss:Bold="1"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s303">
            <Alignment ss:Horizontal="Center" ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Color="#000000"
                  ss:Bold="1"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s317">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="mm/dd/yy;@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s331">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="0"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s355">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s356">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s357">
            <Alignment ss:Vertical="Center" ss:WrapText="1"/>
            <Borders/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s358">
            <Alignment ss:Vertical="Center" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s359">
            <Alignment ss:Vertical="Center"/>
            <Borders/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s360">
            <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s361">
            <Alignment ss:Vertical="Center" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s362">
            <Alignment ss:Vertical="Center"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s363">
            <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s364">
            <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s375">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="9" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s386">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s387">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s389">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s392">
            <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <Protection/>
        </Style>
        <Style ss:ID="s395">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s396">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s398">
            <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <Protection/>
        </Style>
        <Style ss:ID="s401">
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s402">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s407">
            <Borders>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"
                  ss:Bold="1"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s408">
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000" ss:Bold="1"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s411">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="mm/dd/yy"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s414">
            <Alignment ss:Horizontal="Right" ss:Vertical="Bottom"/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s416">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"
                  ss:Bold="1"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s417">
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"
                  ss:Bold="1"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s418">
            <Alignment ss:Horizontal="CenterAcrossSelection" ss:Vertical="Bottom"/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"
                  ss:Bold="1"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s419">
            <Alignment ss:Horizontal="CenterAcrossSelection" ss:Vertical="Bottom"/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000" ss:Bold="1"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s421">
            <Alignment ss:Vertical="Bottom"/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"
                  ss:Bold="1"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s422">
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
        </Style>
        <Style ss:ID="s423">
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s424">
            <Borders>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s425">
            <Borders>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s426">
            <Alignment ss:Vertical="Center" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s429">
            <Alignment ss:Horizontal="Right" ss:Vertical="Center"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s430">
            <Borders/>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s431">
            <Borders>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s434">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s435">
            <Alignment ss:Vertical="Top"/>
            <Borders/>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s437">
            <Alignment ss:Horizontal="Right" ss:Vertical="Center"/>
            <Borders/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s438">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s439">
            <Alignment ss:Vertical="Top"/>
            <Borders/>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s440">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s441">
            <Alignment ss:Horizontal="Right" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s442">
            <Alignment ss:Horizontal="Right" ss:Vertical="Bottom"/>
            <Borders/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s443">
            <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s444">
            <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
            <Borders/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s450">
            <Alignment ss:Vertical="Center" ss:WrapText="1"/>
            <Borders>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="7" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s451">
            <Alignment ss:Horizontal="Right" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s452">
            <Borders>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s453">
            <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s454">
            <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s455">
            <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s456">
            <Alignment ss:Horizontal="Right" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s460">
            <Alignment ss:Horizontal="Right" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s461">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Right" ss:LineStyle="Dash" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s463">
            <Alignment ss:Horizontal="Center" ss:Vertical="Top"/>
            <Borders/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Color="#000000"
                  ss:Bold="1"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s464">
            <Alignment ss:Horizontal="Center" ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Color="#000000"
                  ss:Bold="1"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s466">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s468">
            <Alignment ss:Vertical="Bottom"/>
            <Borders/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s469">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s470">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s471">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s472">
            <Alignment ss:Vertical="Top"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s473">
            <Alignment ss:Horizontal="Right" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s474">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s479">
            <Alignment ss:Vertical="Bottom"/>
            <Borders/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s494">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s539">
            <Alignment ss:Vertical="Center"/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
        </Style>
        <Style ss:ID="s540">
            <Alignment ss:Horizontal="Right" ss:Vertical="Center"/>
            <Borders/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s541">
            <Alignment ss:Vertical="Center"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
        </Style>
        <Style ss:ID="s542">
            <Alignment ss:Vertical="Center"/>
            <Borders/>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s544">
            <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s546">
            <Alignment ss:Horizontal="Left" ss:Vertical="Center"/>
            <Borders/>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s556">
            <Alignment ss:Horizontal="Right" ss:Vertical="Center"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s557">
            <Alignment ss:Vertical="Center"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s558">
            <Alignment ss:Vertical="Center"/>
            <Borders>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s567">
            <Alignment ss:Horizontal="Left" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s570">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="12"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s572">
            <Borders>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <NumberFormat ss:Format="@"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s573">
            <Alignment ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s587">
            <Alignment ss:Horizontal="Right" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s589">
            <Alignment ss:Horizontal="Right" ss:Vertical="Bottom"/>
            <Borders/>
            <Font ss:FontName="times new roman" x:Family="Roman" ss:Size="8"
                  ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s591">
            <Borders>
                <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <Protection ss:Protected="0"/>
        </Style>
        <Style ss:ID="s593">
            <Borders>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s595">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s596">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s597">
            <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
            <Borders>
                <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
        </Style>
        <Style ss:ID="s598">
            <Borders>
                <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Color="#000000"
                  ss:Bold="1"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <Protection/>
        </Style>
        <Style ss:ID="s599">
            <Borders/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Color="#000000"
                  ss:Bold="1"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <Protection/>
        </Style>
        <Style ss:ID="s600">
            <Borders>
                <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
            </Borders>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Size="8" ss:Color="#000000"
                  ss:Bold="1"/>
            <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
            <Protection/>
        </Style>
        <Style ss:ID="s608">
            <Borders/>
            <Font ss:FontName="Arial" x:Family="Swiss" ss:Color="#000000"/>
        </Style>
    </Styles>
    <Worksheet ss:Name="TX W-3 Plugging   Page 1">
        <Names>
            <NamedRange ss:Name="Print_Area"
                        ss:RefersTo="='TX W-3 Plugging   Page 1'!R1C1:R60C18"/>
        </Names>
        <Table ss:ExpandedColumnCount="18" ss:ExpandedRowCount="60" x:FullColumns="1"
               x:FullRows="1" ss:StyleID="s62" ss:DefaultColumnWidth="51"
               ss:DefaultRowHeight="13">
            <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="31"/>
            <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="43"/>
            <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="66"/>
            <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="28"/>
            <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="36"/>
            <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="16"/>
            <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="46" ss:Span="1"/>
            <Column ss:Index="9" ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="23"/>
            <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="26"/>
            <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="46"/>
            <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="31"/>
            <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="18"/>
            <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="15"/>
            <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="21"/>
            <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="15"/>
            <Column ss:StyleID="s62" ss:AutoFitWidth="0" ss:Width="46" ss:Span="1"/>
            <Row ss:AutoFitHeight="0" ss:Height="15">
                <Cell ss:StyleID="s63">
                    <Data ss:Type="String">Plugging Record</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s64">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="14" ss:StyleID="s66">
                    <Data ss:Type="String">RAILROAD COMMISSION OF TEXAS</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s67">
                    <Data ss:Type="String">FORM W-3</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="13.5">
                <Cell ss:StyleID="s64">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s64">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="14" ss:StyleID="s69">
                    <Data ss:Type="String">OIL AND GAS DIVISION</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s70">
                    <Data ss:Type="String">Rev. 12/92</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="6.25">
                <Cell ss:StyleID="s64">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s64">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s71">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s71">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s71">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s71">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s71">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s71">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s71">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s72">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s72">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s72">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s72">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s72">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s72">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s72">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s73">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s73">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0">
                <Cell ss:StyleID="s74">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s74">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s75">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s75">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s75">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s75">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s75">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s75">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s75">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181206728">
                    <Data ss:Type="String">Job No.</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="3" ss:StyleID="m105553181206748">
                    <Data ss:Type="String">API NO. (if available)</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553181206768">
                    <Data ss:Type="String">1. RRC District</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="15.75">
                <Cell ss:StyleID="s74">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s74">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s75">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s75">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s94">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s75">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s95">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s95">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s96">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181206788">
                    <Data ss:Type="String"
                          x:Ticked="1">${this.w3Form.value.jobNumber !== null ? this.w3Form.value.jobNumber : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="3" ss:StyleID="m105553181206808">
                    <Data ss:Type="String">${this.w3Form.value.apiNumber}</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553181206828">
                    <Data ss:Type="String">${this.w3Form.value.rrcDistrict}</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="15.5">
                <Cell ss:MergeAcross="14" ss:MergeDown="1" ss:StyleID="m105553181209600">
                    <Data
                            ss:Type="String">FILE IN DUPLICATE WITH DISTRICT OFFICE OF DISTRICT IN WHICH&#10;WELL IS
                        LOCATED WITHIN THIRTY DAYS AFTER PLUGGING
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553181209620">
                    <Data ss:Type="String">4. RRC Lease or Id. Number</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="15.5">
                <Cell ss:Index="16" ss:MergeAcross="2" ss:StyleID="m105553181209640">
                    <Data
                            ss:Type="String" x:Ticked="1">
                        ${this.w3Form.value.rrcLeaseIdNumber !== null ? this.w3Form.value.rrcLeaseIdNumber : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="9.75">
                <Cell ss:MergeAcross="5" ss:StyleID="m105553181209660">
                    <Data ss:Type="String">2. FIELD NAME (as per RRC Records)</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="8" ss:StyleID="m105553181209680">
                    <Data ss:Type="String">3. Lease Name</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553181209700">
                    <Data ss:Type="String">5. Well Number</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="5" ss:StyleID="m105553180558144">
                    <Data ss:Type="String">${this.w3Form.value.fieldName}</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="8" ss:StyleID="m105553180558164">
                    <Data ss:Type="String">${this.w3Form.value.leaseName}</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180558184">
                    <Data ss:Type="String">
                        ${this.w3Form.value.wellNumber1 !== null ? this.w3Form.value.wellNumber1 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="9.75">
                <Cell ss:MergeAcross="5" ss:StyleID="m105553180558204">
                    <Data ss:Type="String">6. OPERATOR</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="8" ss:StyleID="m105553180558224">
                    <Data ss:Type="String">6a. Original Form W-1 Filed in Name of:</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180558244">
                    <Data ss:Type="String">10. County</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="5" ss:StyleID="m105553180563344">
                    <Data ss:Type="String">${this.w3Form.value.operatorName}</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="8" ss:StyleID="m105553180563364">
                    <Data ss:Type="String">${this.w3Form.value.w1FiledName}</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180563384">
                    <Data ss:Type="String">${this.w3Form.value.country}</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="9.75">
                <Cell ss:MergeAcross="5" ss:StyleID="m105553180563404">
                    <Data ss:Type="String">7. ADDRESS</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="8" ss:StyleID="m105553180563424">
                    <Data ss:Type="String">6b. Any Subsequent W-1's Filed in Name of :</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180563444">
                    <Data ss:Type="String">11. Date Drilling Permit Issued</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="5" ss:StyleID="m105553180975024">
                    <Data ss:Type="String">${this.w3Form.value.address}</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="8" ss:StyleID="m105553180975044">
                    <Data ss:Type="String">${this.w3Form.value.subsequentW1FiledName}</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180975064">
                    <Data ss:Type="String">
                        ${this.w3Form.value.drillingPermitIssuedDate ? ('0' + (new Date(this.w3Form.value.drillingPermitIssuedDate).getMonth() + 1)).slice(-2) + '/' + new Date(this.w3Form.value.drillingPermitIssuedDate).getDate() + '/' + new Date(this.w3Form.value.drillingPermitIssuedDate).getFullYear() : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0">
                <Cell ss:MergeAcross="4" ss:MergeDown="1" ss:StyleID="s124">
                    <Data
                            ss:Type="String">8. Location of Well, Relative to Nearest Lease Boundaries of Lease on which
                        this Well is Located
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s181">
                    <Data ss:Type="String">
                        ${this.w3Form.value.leaseDistance1 !== null ? this.w3Form.value.leaseDistance1 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s183">
                    <Data ss:Type="String">Feet From</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s182">
                    <Data ss:Type="String">
                        ${this.w3Form.value.leaseDirection1 === 0 ? 'North' : this.w3Form.value.leaseDirection1 === 1 ? 'East' : this.w3Form.value.leaseDirection1 === 2 ? 'South' : this.w3Form.value.leaseDirection1 === 2 ? 'West' : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s183">
                    <Data ss:Type="String">Line and</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s182">
                    <Data ss:Type="String">
                        ${this.w3Form.value.leaseDistance2 !== null ? this.w3Form.value.leaseDistance2 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553180975164">
                    <Data ss:Type="String">Feet From</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180975184">
                    <Data ss:Type="String">12. Permit Number</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="4.75">
                <Cell ss:Index="6" ss:StyleID="s189">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s95">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s190">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s95">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s95">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s190">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s95">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s95">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s190">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s191">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:MergeDown="1" ss:StyleID="m105553180975204">
                    <Data
                            ss:Type="String" x:Ticked="1">
                        ${this.w3Form.value.permitNumber !== null ? this.w3Form.value.permitNumber : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0">
                <Cell ss:MergeAcross="4" ss:StyleID="s196">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s158">
                    <Data ss:Type="String">
                        ${this.w3Form.value.leaseDirection2 === 0 ? 'North' : this.w3Form.value.leaseDirection2 === 1 ? 'East' : this.w3Form.value.leaseDirection2 === 2 ? 'South' : this.w3Form.value.leaseDirection2 === 2 ? 'West' : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s201">
                    <Data ss:Type="String">Line of the</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="4" ss:StyleID="s160">
                    <Data ss:Type="String">${this.w3Form.value.lease}</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553180773484">
                    <Data ss:Type="String">Lease</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="10.5">
                <Cell ss:MergeAcross="5" ss:StyleID="m105553180773504">
                    <Data ss:Type="String">9a. SECTION, BLOCK, AND SURVEY</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="8" ss:StyleID="m105553180773524">
                    <Data ss:Type="String">9b. Distance and Direction from Nearest Town in this County</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553181197744">
                    <Data ss:Type="String">13. Date Drilling Commenced</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0">
                <Cell ss:MergeAcross="5" ss:StyleID="m105553181197764">
                    <Data ss:Type="String">${this.w3Form.value.sectionBlockAndSurvey}</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="8" ss:StyleID="m105553181197784">
                    <Data ss:Type="String">${this.w3Form.value.distanceDirectionNearestTown}</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553181197804">
                    <Data ss:Type="String">
                        ${this.w3Form.value.drillingCommencedDate ? ('0' + (new Date(this.w3Form.value.drillingCommencedDate).getMonth() + 1)).slice(-2) + '/' + new Date(this.w3Form.value.drillingCommencedDate).getDate() + '/' + new Date(this.w3Form.value.drillingCommencedDate).getFullYear() : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="10.5">
                <Cell ss:MergeAcross="1" ss:MergeDown="1" ss:StyleID="m105553181197824">
                    <Data
                            ss:Type="String">16. Type Well&#10; (Oil, Gas, Dry)
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeDown="1" ss:StyleID="s234">
                    <Data ss:Type="String">Total Depth</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="11" ss:StyleID="m105553181197864">
                    <Data ss:Type="String">17. If Multiple Completion List All Field Names and Oil Lease or Gas ID
                        No.'s
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553181197884">
                    <Data ss:Type="String">14. Date Drilling Completed</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="10.5">
                <Cell ss:Index="4" ss:MergeAcross="5" ss:MergeDown="2"
                      ss:StyleID="m105553181197904">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:MergeDown="1" ss:StyleID="m105553181197924">
                    <Data
                            ss:Type="String">GAS ID or&#10;OIL LEASE #
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeDown="1" ss:StyleID="s245">
                    <Data ss:Type="String">Oil - O&#10;Gas - G</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:MergeDown="1" ss:StyleID="m105553180781764">
                    <Data
                            ss:Type="String">WELL&#10;#
                    </Data>
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:MergeDown="1" ss:StyleID="m105553180781784">
                    <Data
                            ss:Type="String">
                        ${this.w3Form.value.drillingCompletedDate ? ('0' + (new Date(this.w3Form.value.drillingCompletedDate).getMonth() + 1)).slice(-2) + '/' + new Date(this.w3Form.value.drillingCompletedDate).getDate() + '/' + new Date(this.w3Form.value.drillingCompletedDate).getFullYear() : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="1" ss:StyleID="m105553180781804">
                    <Data ss:Type="String">${this.w3Form.value.wellType}</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s264">
                    <Data ss:Type="String">
                        ${this.w3Form.value.totalDepth1 !== null ? this.w3Form.value.totalDepth1 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0">
                <Cell ss:MergeAcross="2" ss:MergeDown="1" ss:StyleID="m105553180781824">
                    <Data
                            ss:Type="String">18. If Gas, Amt, of Cond. on&#10; Hand at time of Plugging
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:Index="10" ss:MergeAcross="1" ss:StyleID="m105553180781844">
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180781864">
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180781884">
                    <Data ss:Type="String">15. Date Well Plugged</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="6.25">
                <Cell ss:Index="4" ss:MergeAcross="5" ss:MergeDown="1"
                      ss:StyleID="m105553180781904">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:MergeDown="1" ss:StyleID="m105553180781924">
                    <Data
                            ss:Type="String">${this.w3Form.value.gasIdOrOilLease}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeDown="1" ss:StyleID="m105553180784032">
                    <Data ss:Type="String">${this.w3Form.value.oilOGasG}</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:MergeDown="1" ss:StyleID="m105553180784052">
                    <Data
                            ss:Type="String">${this.w3Form.value.wellNumber2}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:MergeDown="1" ss:StyleID="m105553180784072">
                    <Data
                            ss:Type="String">
                        ${this.w3Form.value.wellPluggedDate ? ('0' + (new Date(this.w3Form.value.wellPluggedDate).getMonth() + 1)).slice(-2) + '/' + new Date(this.w3Form.value.wellPluggedDate).getDate() + '/' + new Date(this.w3Form.value.wellPluggedDate).getFullYear() : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180784092">
                    <Data ss:Type="String">${this.w3Form.value.gasAtTimePlugging}</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="5" ss:StyleID="m105553180784112">
                    <Data ss:Type="String">CEMENTING TO PLUG AND ABANDON DATA:</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s302">
                    <Data ss:Type="String">PLUG #1</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s303">
                    <Data ss:Type="String">PLUG #2</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553180784132">
                    <Data ss:Type="String">PLUG #3</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s303">
                    <Data ss:Type="String">PLUG #4</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553180784152">
                    <Data ss:Type="String">PLUG #5</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180784172">
                    <Data ss:Type="String">PLUG #6</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s303">
                    <Data ss:Type="String">PLUG #7</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s303">
                    <Data ss:Type="String">PLUG #8</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="5" ss:StyleID="m105553181201904">
                    <Data ss:Type="String">*19. Commencing Date</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s317">
                    <Data ss:Type="String">
                        ${this.w3Form.value.cementingDate.plug1 ? ('0' + (new Date(this.w3Form.value.cementingDate.plug1).getMonth() + 1)).slice(-2) + '/' + new Date(this.w3Form.value.cementingDate.plug1).getDate() + '/' + new Date(this.w3Form.value.cementingDate.plug1).getFullYear() : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s317">
                    <Data ss:Type="String">
                        ${this.w3Form.value.cementingDate.plug2 ? ('0' + (new Date(this.w3Form.value.cementingDate.plug2).getMonth() + 1)).slice(-2) + '/' + new Date(this.w3Form.value.cementingDate.plug2).getDate() + '/' + new Date(this.w3Form.value.cementingDate.plug2).getFullYear() : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181201924">
                    <Data ss:Type="String">
                        ${this.w3Form.value.cementingDate.plug3 ? ('0' + (new Date(this.w3Form.value.cementingDate.plug3).getMonth() + 1)).slice(-2) + '/' + new Date(this.w3Form.value.cementingDate.plug3).getDate() + '/' + new Date(this.w3Form.value.cementingDate.plug3).getFullYear() : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s317">
                    <Data ss:Type="String">
                        ${this.w3Form.value.cementingDate.plug4 ? ('0' + (new Date(this.w3Form.value.cementingDate.plug4).getMonth() + 1)).slice(-2) + '/' + new Date(this.w3Form.value.cementingDate.plug4).getDate() + '/' + new Date(this.w3Form.value.cementingDate.plug4).getFullYear() : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181201944">
                    <Data ss:Type="String">
                        ${this.w3Form.value.cementingDate.plug5 ? ('0' + (new Date(this.w3Form.value.cementingDate.plug4).getMonth() + 1)).slice(-2) + '/' + new Date(this.w3Form.value.cementingDate.plug4).getDate() + '/' + new Date(this.w3Form.value.cementingDate.plug4).getFullYear() : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553181201964">
                    <Data ss:Type="String">
                        ${this.w3Form.value.cementingDate.plug6 ? ('0' + (new Date(this.w3Form.value.cementingDate.plug5).getMonth() + 1)).slice(-2) + '/' + new Date(this.w3Form.value.cementingDate.plug5).getDate() + '/' + new Date(this.w3Form.value.cementingDate.plug5).getFullYear() : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s317">
                    <Data ss:Type="String">
                        ${this.w3Form.value.cementingDate.plug7 ? ('0' + (new Date(this.w3Form.value.cementingDate.plug7).getMonth() + 1)).slice(-2) + '/' + new Date(this.w3Form.value.cementingDate.plug7).getDate() + '/' + new Date(this.w3Form.value.cementingDate.plug7).getFullYear() : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s317">
                    <Data ss:Type="String">
                        ${this.w3Form.value.cementingDate.plug8 ? ('0' + (new Date(this.w3Form.value.cementingDate.plug8).getMonth() + 1)).slice(-2) + '/' + new Date(this.w3Form.value.cementingDate.plug8).getDate() + '/' + new Date(this.w3Form.value.cementingDate.plug8).getFullYear() : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="5" ss:StyleID="m105553181201984">
                    <Data ss:Type="String">20. Size of Hole or Pipe in which Plug Placed (inches)</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.holeOrPipeSize.plug1 !== null ? this.w3Form.value.holeOrPipeSize.plug1 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.holeOrPipeSize.plug2 !== null ? this.w3Form.value.holeOrPipeSize.plug2 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181202004">
                    <Data ss:Type="String">
                        ${this.w3Form.value.holeOrPipeSize.plug3 !== null ? this.w3Form.value.holeOrPipeSize.plug3 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.holeOrPipeSize.plug4 !== null ? this.w3Form.value.holeOrPipeSize.plug4 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181202024">
                    <Data ss:Type="String">
                        ${this.w3Form.value.holeOrPipeSize.plug5 !== null ? this.w3Form.value.holeOrPipeSize.plug5 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553181202044">
                    <Data ss:Type="String">
                        ${this.w3Form.value.holeOrPipeSize.plug6 !== null ? this.w3Form.value.holeOrPipeSize.plug6 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.holeOrPipeSize.plug7 !== null ? this.w3Form.value.holeOrPipeSize.plug7 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.holeOrPipeSize.plug8 !== null ? this.w3Form.value.holeOrPipeSize.plug8 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="5" ss:StyleID="m105553181205648">
                    <Data ss:Type="String">21. Depth to Bottom of Tubing or Drill Pipe (ft.)</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.tubingBottomDepth.plug1 !== null ? this.w3Form.value.tubingBottomDepth.plug1 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.tubingBottomDepth.plug2 !== null ? this.w3Form.value.tubingBottomDepth.plug2 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181205668">
                    <Data ss:Type="String">
                        ${this.w3Form.value.tubingBottomDepth.plug3 !== null ? this.w3Form.value.tubingBottomDepth.plug3 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.tubingBottomDepth.plug4 !== null ? this.w3Form.value.tubingBottomDepth.plug4 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181205688">
                    <Data ss:Type="String">
                        ${this.w3Form.value.tubingBottomDepth.plug5 !== null ? this.w3Form.value.tubingBottomDepth.plug5 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553181205708">
                    <Data ss:Type="String">
                        ${this.w3Form.value.tubingBottomDepth.plug6 !== null ? this.w3Form.value.tubingBottomDepth.plug6 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.tubingBottomDepth.plug7 !== null ? this.w3Form.value.tubingBottomDepth.plug7 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.tubingBottomDepth.plug8 !== null ? this.w3Form.value.tubingBottomDepth.plug8 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="5" ss:StyleID="m105553181205728">
                    <Data ss:Type="String">*22. Sacks of Cement Used (each plug)</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.usedCementSacks.plug1 !== null ? this.w3Form.value.usedCementSacks.plug1 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.usedCementSacks.plug2 !== null ? this.w3Form.value.usedCementSacks.plug2 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181205748">
                    <Data ss:Type="String">
                        ${this.w3Form.value.usedCementSacks.plug3 !== null ? this.w3Form.value.usedCementSacks.plug3 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.usedCementSacks.plug4 !== null ? this.w3Form.value.usedCementSacks.plug4 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181205768">
                    <Data ss:Type="String">
                        ${this.w3Form.value.usedCementSacks.plug5 !== null ? this.w3Form.value.usedCementSacks.plug5 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553181205788">
                    <Data ss:Type="String">
                        ${this.w3Form.value.usedCementSacks.plug6 !== null ? this.w3Form.value.usedCementSacks.plug6 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.usedCementSacks.plug7 !== null ? this.w3Form.value.usedCementSacks.plug7 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.usedCementSacks.plug8 !== null ? this.w3Form.value.usedCementSacks.plug8 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="5" ss:StyleID="m105553181206272">
                    <Data ss:Type="String">*23. Slurry Volume Pumped (cu. ft.)</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.pumpedSlurryVolume.plug1 !== null ? this.w3Form.value.pumpedSlurryVolume.plug1 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.pumpedSlurryVolume.plug2 !== null ? this.w3Form.value.pumpedSlurryVolume.plug2 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181206292">
                    <Data ss:Type="String">
                        ${this.w3Form.value.pumpedSlurryVolume.plug3 !== null ? this.w3Form.value.pumpedSlurryVolume.plug3 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.pumpedSlurryVolume.plug4 !== null ? this.w3Form.value.pumpedSlurryVolume.plug4 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181206312">
                    <Data ss:Type="String">
                        ${this.w3Form.value.pumpedSlurryVolume.plug5 !== null ? this.w3Form.value.pumpedSlurryVolume.plug5 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553181206332">
                    <Data ss:Type="String">
                        ${this.w3Form.value.pumpedSlurryVolume.plug6 !== null ? this.w3Form.value.pumpedSlurryVolume.plug6 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.pumpedSlurryVolume.plug7 !== null ? this.w3Form.value.pumpedSlurryVolume.plug7 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.pumpedSlurryVolume.plug8 !== null ? this.w3Form.value.pumpedSlurryVolume.plug8 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="5" ss:StyleID="m105553181206352">
                    <Data ss:Type="String">*24. Calculated Top of Plug (ft.)</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s331">
                    <Data ss:Type="String">
                        ${this.w3Form.value.calculatedTop.plug1 !== null ? this.w3Form.value.calculatedTop.plug1 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s331">
                    <Data ss:Type="String">
                        ${this.w3Form.value.calculatedTop.plug2 !== null ? this.w3Form.value.calculatedTop.plug2 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181206372">
                    <Data ss:Type="String">
                        ${this.w3Form.value.calculatedTop.plug3 !== null ? this.w3Form.value.calculatedTop.plug3 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s331">
                    <Data ss:Type="String">
                        ${this.w3Form.value.calculatedTop.plug4 !== null ? this.w3Form.value.calculatedTop.plug4 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181206392">
                    <Data ss:Type="String">
                        ${this.w3Form.value.calculatedTop.plug5 !== null ? this.w3Form.value.calculatedTop.plug5 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553181206412">
                    <Data ss:Type="String">
                        ${this.w3Form.value.calculatedTop.plug6 !== null ? this.w3Form.value.calculatedTop.plug6 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s331">
                    <Data ss:Type="String">
                        ${this.w3Form.value.calculatedTop.plug7 !== null ? this.w3Form.value.calculatedTop.plug7 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s331">
                    <Data ss:Type="String">
                        ${this.w3Form.value.calculatedTop.plug8 !== null ? this.w3Form.value.calculatedTop.plug8 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="5" ss:StyleID="m105553180564592">
                    <Data ss:Type="String">25. Measured Top of Plug (if tagged) (ft.)</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.measuredTop.plug1 !== null ? this.w3Form.value.measuredTop.plug1 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.measuredTop.plug2 !== null ? this.w3Form.value.measuredTop.plug2 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553180564612">
                    <Data ss:Type="String">
                        ${this.w3Form.value.measuredTop.plug3 !== null ? this.w3Form.value.measuredTop.plug3 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.measuredTop.plug4 !== null ? this.w3Form.value.measuredTop.plug4 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553180564632">
                    <Data ss:Type="String">
                        ${this.w3Form.value.measuredTop.plug5 !== null ? this.w3Form.value.measuredTop.plug5 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180564652">
                    <Data ss:Type="String">
                        ${this.w3Form.value.measuredTop.plug6 !== null ? this.w3Form.value.measuredTop.plug6 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.measuredTop.plug7 !== null ? this.w3Form.value.measuredTop.plug7 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.measuredTop.plug8 !== null ? this.w3Form.value.measuredTop.plug8 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="5" ss:StyleID="m105553180564672">
                    <Data ss:Type="String">*26. Slurry Wt. # /Gal.</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.slurryWt.plug1 !== null ? this.w3Form.value.slurryWt.plug1 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.slurryWt.plug2 !== null ? this.w3Form.value.slurryWt.plug2 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553180564692">
                    <Data ss:Type="String">
                        ${this.w3Form.value.slurryWt.plug3 !== null ? this.w3Form.value.slurryWt.plug3 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.slurryWt.plug4 !== null ? this.w3Form.value.slurryWt.plug4 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553180564712">
                    <Data ss:Type="String">
                        ${this.w3Form.value.slurryWt.plug5 !== null ? this.w3Form.value.slurryWt.plug5 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180564732">
                    <Data ss:Type="String">
                        ${this.w3Form.value.slurryWt.plug6 !== null ? this.w3Form.value.slurryWt.plug6 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.slurryWt.plug7 !== null ? this.w3Form.value.slurryWt.plug7 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.slurryWt.plug8 !== null ? this.w3Form.value.slurryWt.plug8 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="5" ss:StyleID="m105553181204816">
                    <Data ss:Type="String">*27. Type Cement</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.cementType.plug1 !== null ? this.w3Form.value.cementType.plug1 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.cementType.plug2 !== null ? this.w3Form.value.cementType.plug2 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181204836">
                    <Data ss:Type="String">
                        ${this.w3Form.value.cementType.plug3 !== null ? this.w3Form.value.cementType.plug3 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.cementType.plug4 !== null ? this.w3Form.value.cementType.plug4 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181204856">
                    <Data ss:Type="String">
                        ${this.w3Form.value.cementType.plug5 !== null ? this.w3Form.value.cementType.plug5 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553181204876">
                    <Data ss:Type="String">
                        ${this.w3Form.value.cementType.plug6 !== null ? this.w3Form.value.cementType.plug6 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.cementType.plug7 !== null ? this.w3Form.value.cementType.plug7 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s154">
                    <Data ss:Type="String">
                        ${this.w3Form.value.cementType.plug8 !== null ? this.w3Form.value.cementType.plug8 : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="4.5">
                <Cell ss:MergeAcross="6" ss:MergeDown="2" ss:StyleID="m105553181204896">
                    <ss:Data
                            ss:Type="String" xmlns="http://www.w3.org/TR/REC-html40">
                        <B>
                            <Font
                                    html:Color="#000000"></Font>
                        </B>
                        <Font html:Color="#000000">28.</Font>
                        <B>
                            <Font
                                    html:Color="#000000"></Font>
                            <Font html:Size="8" html:Color="#000000">CASING AND TUBING RECORD AFTER PLUGGING</Font>
                        </B>
                    </ss:Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="3" ss:MergeDown="2" ss:StyleID="m105553181204916">
                    <Data
                            ss:Type="String">29. Was any Non-Drillable Material (Other&#10; than Casing) Left in This
                        Well
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s355">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s355">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s355">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s355">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s355">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s355">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s356">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="18">
                <Cell ss:Index="12" ss:StyleID="s357">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s358">
                    <Data ss:Type="String">${this.w3Form.value.nonDriableMaterial ? 'X' : ''}</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s359">
                    <Data ss:Type="String">YES</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s357">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s358">
                    <Data ss:Type="String">${!this.w3Form.value.nonDriableMaterial ? 'X' : ''}</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s359">
                    <Data ss:Type="String">NO</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s360">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="4.5">
                <Cell ss:Index="12" ss:StyleID="s361">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s361">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s362">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s361">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s361">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s362">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s363">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:StyleID="s364">
                    <Data ss:Type="String">SIZE</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s364">
                    <Data ss:Type="String">WT. #/FT.</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s364">
                    <Data ss:Type="String">PUT IN WELL (ft.)</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181206480">
                    <Data ss:Type="String">LEFT IN WELL (ft.)</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181206500">
                    <Data ss:Type="String">HOLE SIZE(in.)</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="10" ss:MergeDown="1" ss:StyleID="m105553181206520">
                    <Data
                            ss:Type="String">29a. If Answer to above is &quot;Yes&quot; state depth to top of &quot;junk&quot;
                        left in hole &#10; and briefly describe non-drillable material. (Use Reverse Side of &#10; Form
                        if more space is needed.)
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:StyleID="s375">
                    <Data ss:Type="String">
                        ${this.w3Form.value.casingTubingRecordAfterPlugging[0] & this.w3Form.value.casingTubingRecordAfterPlugging[0].size ? this.w3Form.value.casingTubingRecordAfterPlugging[0].size : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s375">
                    <Data ss:Type="String">
                        ${this.w3Form.value.casingTubingRecordAfterPlugging[0] && this.w3Form.value.casingTubingRecordAfterPlugging[0].wtft ? this.w3Form.value.casingTubingRecordAfterPlugging[0].wtft : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s375">
                    <Data ss:Type="String">
                        ${this.w3Form.value.casingTubingRecordAfterPlugging[0] && this.w3Form.value.casingTubingRecordAfterPlugging[0].putInWell !== null ? this.w3Form.value.casingTubingRecordAfterPlugging[0].putInWell : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181206540">
                    <Data ss:Type="String">
                        ${this.w3Form.value.casingTubingRecordAfterPlugging[0] && this.w3Form.value.casingTubingRecordAfterPlugging[0].leftInWell !== null ? this.w3Form.value.casingTubingRecordAfterPlugging[0].leftInWell : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181206560">
                    <Data ss:Type="String">
                        ${this.w3Form.value.casingTubingRecordAfterPlugging[0] && this.w3Form.value.casingTubingRecordAfterPlugging[0].holeSize ? this.w3Form.value.casingTubingRecordAfterPlugging[0].holeSize : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:StyleID="s375">
                    <Data ss:Type="String">
                        ${this.w3Form.value.casingTubingRecordAfterPlugging[1] && this.w3Form.value.casingTubingRecordAfterPlugging[1].size ? this.w3Form.value.casingTubingRecordAfterPlugging[1].size : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s375">
                    <Data ss:Type="String">
                        ${this.w3Form.value.casingTubingRecordAfterPlugging[1] && this.w3Form.value.casingTubingRecordAfterPlugging[1].wtft ? this.w3Form.value.casingTubingRecordAfterPlugging[1].wtft : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s375">
                    <Data ss:Type="String">
                        ${this.w3Form.value.casingTubingRecordAfterPlugging[1] && this.w3Form.value.casingTubingRecordAfterPlugging[1].putInWell !== null ? this.w3Form.value.casingTubingRecordAfterPlugging[1].putInWell : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181206580">
                    <Data ss:Type="String">
                        ${this.w3Form.value.casingTubingRecordAfterPlugging[1] && this.w3Form.value.casingTubingRecordAfterPlugging[1].leftInWell !== null ? this.w3Form.value.casingTubingRecordAfterPlugging[1].leftInWell : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181206600">
                    <Data ss:Type="String">
                        ${this.w3Form.value.casingTubingRecordAfterPlugging[1] && this.w3Form.value.casingTubingRecordAfterPlugging[1].holeSize ? this.w3Form.value.casingTubingRecordAfterPlugging[1].holeSize : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="10" ss:MergeDown="2" ss:StyleID="m105553181206620">
                    <Data
                            ss:Type="String">
                        ${this.w3Form.value.stateDepthOfJunk ? this.w3Form.value.stateDepthOfJunk : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:StyleID="s375">
                    <Data ss:Type="String">
                        ${this.w3Form.value.casingTubingRecordAfterPlugging[2] && this.w3Form.value.casingTubingRecordAfterPlugging[2].size ? this.w3Form.value.casingTubingRecordAfterPlugging[2].size : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s375">
                    <Data ss:Type="String">
                        ${this.w3Form.value.casingTubingRecordAfterPlugging[2] && this.w3Form.value.casingTubingRecordAfterPlugging[2].wtft ? this.w3Form.value.casingTubingRecordAfterPlugging[2].wtft : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s375">
                    <Data ss:Type="String">
                        ${this.w3Form.value.casingTubingRecordAfterPlugging[2] && this.w3Form.value.casingTubingRecordAfterPlugging[2].putInWell !== null ? this.w3Form.value.casingTubingRecordAfterPlugging[2].putInWell : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181206640">
                    <Data ss:Type="String">
                        ${this.w3Form.value.casingTubingRecordAfterPlugging[2] && this.w3Form.value.casingTubingRecordAfterPlugging[2].leftInWell !== null ? this.w3Form.value.casingTubingRecordAfterPlugging[2].leftInWell : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553181206660">
                    <Data ss:Type="String">
                        ${this.w3Form.value.casingTubingRecordAfterPlugging[2] && this.w3Form.value.casingTubingRecordAfterPlugging[2].holeSize ? this.w3Form.value.casingTubingRecordAfterPlugging[2].holeSize : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:StyleID="s386">
                    <Data ss:Type="String">
                        ${this.w3Form.value.casingTubingRecordAfterPlugging[3] && this.w3Form.value.casingTubingRecordAfterPlugging[3].size ? this.w3Form.value.casingTubingRecordAfterPlugging[3].size : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s375">
                    <Data ss:Type="String">
                        ${this.w3Form.value.casingTubingRecordAfterPlugging[3] && this.w3Form.value.casingTubingRecordAfterPlugging[3].wtft ? this.w3Form.value.casingTubingRecordAfterPlugging[3].wtft : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s375">
                    <Data ss:Type="String">
                        ${this.w3Form.value.casingTubingRecordAfterPlugging[3] && this.w3Form.value.casingTubingRecordAfterPlugging[3].putInWell !== null ? this.w3Form.value.casingTubingRecordAfterPlugging[3].putInWell : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553180558560">
                    <Data ss:Type="String">
                        ${this.w3Form.value.casingTubingRecordAfterPlugging[3] && this.w3Form.value.casingTubingRecordAfterPlugging[3].leftInWell !== null ? this.w3Form.value.casingTubingRecordAfterPlugging[3].leftInWell : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="m105553180558580">
                    <Data ss:Type="String">
                        ${this.w3Form.value.casingTubingRecordAfterPlugging[3] && this.w3Form.value.casingTubingRecordAfterPlugging[3].holeSize ? this.w3Form.value.casingTubingRecordAfterPlugging[3].holeSize : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0">
                <Cell ss:MergeAcross="17" ss:StyleID="m105553180558600">
                    <ss:Data
                            ss:Type="String" xmlns="http://www.w3.org/TR/REC-html40">
                        <Font
                                html:Color="#000000">30.
                        </Font>
                        <B>
                            <Font html:Color="#000000">LIST ALL OPEN HOLE AND/OR PERFORATED INTERVALS</Font>
                        </B>
                    </ss:Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:StyleID="s387">
                    <Data ss:Type="String">FROM</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s182">
                    <Data ss:Type="String">
                        ${this.w3Form.value.perforatedIntervalsList[0] && this.w3Form.value.perforatedIntervalsList[0].from ? this.w3Form.value.perforatedIntervalsList[0].from : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s183">
                    <Data ss:Type="String">TO</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="s182">
                    <Data ss:Type="String">
                        ${this.w3Form.value.perforatedIntervalsList[0] && this.w3Form.value.perforatedIntervalsList[0].to ? this.w3Form.value.perforatedIntervalsList[0].to : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s74">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s389">
                    <Data ss:Type="String">FROM</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="s182">
                    <Data ss:Type="String">
                        ${this.w3Form.value.perforatedIntervalsList[5] && this.w3Form.value.perforatedIntervalsList[5].from ? this.w3Form.value.perforatedIntervalsList[5].from : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s392">
                    <Data ss:Type="String">TO</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180558720">
                    <Data ss:Type="String">
                        ${this.w3Form.value.perforatedIntervalsList[5] && this.w3Form.value.perforatedIntervalsList[5].to ? this.w3Form.value.perforatedIntervalsList[5].to : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:StyleID="s387">
                    <Data ss:Type="String">FROM</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s182">
                    <Data ss:Type="String">
                        ${this.w3Form.value.perforatedIntervalsList[1] && this.w3Form.value.perforatedIntervalsList[1].from ? this.w3Form.value.perforatedIntervalsList[1].from : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s183">
                    <Data ss:Type="String">TO</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="s182">
                    <Data ss:Type="String">
                        ${this.w3Form.value.perforatedIntervalsList[1] && this.w3Form.value.perforatedIntervalsList[1].to ? this.w3Form.value.perforatedIntervalsList[1].to : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s74">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s389">
                    <Data ss:Type="String">FROM</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="s182">
                    <Data ss:Type="String">
                        ${this.w3Form.value.perforatedIntervalsList[6] && this.w3Form.value.perforatedIntervalsList[6].from ? this.w3Form.value.perforatedIntervalsList[6].from : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s392">
                    <Data ss:Type="String">TO</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180774356">
                    <Data ss:Type="String">
                        ${this.w3Form.value.perforatedIntervalsList[6] && this.w3Form.value.perforatedIntervalsList[6].to ? this.w3Form.value.perforatedIntervalsList[6].to : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:StyleID="s387">
                    <Data ss:Type="String">FROM</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s182">
                    <Data ss:Type="String">
                        ${this.w3Form.value.perforatedIntervalsList[2] && this.w3Form.value.perforatedIntervalsList[2].from ? this.w3Form.value.perforatedIntervalsList[2].from : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s183">
                    <Data ss:Type="String">TO</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="s182">
                    <Data ss:Type="String">
                        ${this.w3Form.value.perforatedIntervalsList[2] && this.w3Form.value.perforatedIntervalsList[2].to ? this.w3Form.value.perforatedIntervalsList[2].to : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s74">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s389">
                    <Data ss:Type="String">FROM</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="s182">
                    <Data ss:Type="String">
                        ${this.w3Form.value.perforatedIntervalsList[7] && this.w3Form.value.perforatedIntervalsList[7].from ? this.w3Form.value.perforatedIntervalsList[7].from : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s392">
                    <Data ss:Type="String">TO</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180557412">
                    <Data ss:Type="String">
                        ${this.w3Form.value.perforatedIntervalsList[7] && this.w3Form.value.perforatedIntervalsList[7].to ? this.w3Form.value.perforatedIntervalsList[7].to : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:StyleID="s387">
                    <Data ss:Type="String">FROM</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s182">
                    <Data ss:Type="String">
                        ${this.w3Form.value.perforatedIntervalsList[3] && this.w3Form.value.perforatedIntervalsList[3].from ? this.w3Form.value.perforatedIntervalsList[3].from : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s183">
                    <Data ss:Type="String">TO</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="s182">
                    <Data ss:Type="String">
                        ${this.w3Form.value.perforatedIntervalsList[3] && this.w3Form.value.perforatedIntervalsList[3].to ? this.w3Form.value.perforatedIntervalsList[3].to : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s74">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s389">
                    <Data ss:Type="String">FROM</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="s182">
                    <Data ss:Type="String">
                        ${this.w3Form.value.perforatedIntervalsList[8] && this.w3Form.value.perforatedIntervalsList[8].from ? this.w3Form.value.perforatedIntervalsList[8].from : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s392">
                    <Data ss:Type="String">TO</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180571140">
                    <Data ss:Type="String">
                        ${this.w3Form.value.perforatedIntervalsList[8] && this.w3Form.value.perforatedIntervalsList[8].to ? this.w3Form.value.perforatedIntervalsList[8].to : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:StyleID="s395">
                    <Data ss:Type="String">FROM</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s160">
                    <Data ss:Type="String">
                        ${this.w3Form.value.perforatedIntervalsList[4] && this.w3Form.value.perforatedIntervalsList[4].from ? this.w3Form.value.perforatedIntervalsList[4].from : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s396">
                    <Data ss:Type="String">TO</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="s160">
                    <Data ss:Type="String">
                        ${this.w3Form.value.perforatedIntervalsList[4] && this.w3Form.value.perforatedIntervalsList[4].to ? this.w3Form.value.perforatedIntervalsList[4].to : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s74">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s389">
                    <Data ss:Type="String">FROM</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="s160">
                    <Data ss:Type="String">
                        ${this.w3Form.value.perforatedIntervalsList[9] && this.w3Form.value.perforatedIntervalsList[9].from ? this.w3Form.value.perforatedIntervalsList[9].from : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s398">
                    <Data ss:Type="String">TO</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180563028">
                    <Data ss:Type="String">
                        ${this.w3Form.value.perforatedIntervalsList[9] && this.w3Form.value.perforatedIntervalsList[9].to ? this.w3Form.value.perforatedIntervalsList[9].to : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0">
                <Cell ss:MergeAcross="17" ss:StyleID="s211">
                    <Data ss:Type="String">I have knowledge that the cementing operations, as reflected by the
                        information found on this form, were performed as indicated by such information.
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="9.75">
                <Cell ss:MergeAcross="17" ss:StyleID="s401">
                    <Data ss:Type="String">* Designated items to be completed by Cementing Company. Items not so
                        designated shall be completed by Operator.
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="24.75">
                <Cell ss:MergeAcross="5" ss:StyleID="s402">
                    <Data ss:Type="String">
                        ${(this.w3Form.value.status === 1) && this.w3Form.value.supervisorSign ? this.w3Form.value.supervisorSign.name : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s74">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="10" ss:StyleID="s146">
                    <Data ss:Type="String">
                        ${(this.w3Form.value.status === 1) && this.w3Form.value.supervisorSign ? this.w3Form.value.supervisorSign.companyName : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="9.75">
                <Cell ss:MergeAcross="5" ss:StyleID="s407">
                    <Data ss:Type="String">Signature of Cementer or Authorized Representative</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s408">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="10" ss:StyleID="s407">
                    <Data ss:Type="String">Name of Cementing Company</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0">
                <Cell ss:MergeDown="3" ss:StyleID="s74">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="16" ss:StyleID="s401">
                    <Data ss:Type="String">CERTIFICATE:</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="9.75">
                <Cell ss:Index="2" ss:MergeAcross="16" ss:StyleID="s401">
                    <Data ss:Type="String">I declare under penalties prescribed inn Sec. 91.163, Texas Natural Resources
                        Code, that I am authorized to make this report, that this
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="9.75">
                <Cell ss:Index="2" ss:MergeAcross="16" ss:StyleID="s401">
                    <Data ss:Type="String">report was prepared by me or under my supervision and direction,, and that
                        data and facts stated therein are true, correct, and complete,
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="9.75">
                <Cell ss:Index="2" ss:MergeAcross="16" ss:StyleID="s401">
                    <Data ss:Type="String">to the best of my knowledge.</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="24.75">
                <Cell ss:MergeAcross="4" ss:StyleID="s146">
                    <Data ss:Type="String">
                        ${(this.w3Form.value.status === 2) && this.w3Form.value.managerSign ? this.w3Form.value.managerSign.name : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s75">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="3" ss:StyleID="s146">
                    <Data ss:Type="String">
                        ${(this.w3Form.value.status === 2) && this.w3Form.value.managerSign ? 'Manager' : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s411">
                    <Data ss:Type="String">
                        ${(this.w3Form.value.status === 2) && this.w3Form.value.managerSign ? ('0' + (new Date(this.w3Form.value.managerSign.date).getMonth() + 1)).slice(-2) + '/' + new Date(this.w3Form.value.managerSign.date).getDate() + '/' + new Date(this.w3Form.value.managerSign.date).getFullYear() : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s414">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="3" ss:StyleID="s160">
                    <Data ss:Type="String">
                        ${(this.w3Form.value.status === 2) && this.w3Form.value.managerSign ? this.w3Form.value.managerSign.phone : ''}
                    </Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="9.75">
                <Cell ss:MergeAcross="4" ss:StyleID="s416">
                    <Data ss:Type="String">REPRESENTATIVE OF COMPANY</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s417">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="3" ss:StyleID="s416">
                    <Data ss:Type="String">TITLE</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s418">
                    <Data ss:Type="String">DATE</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s419">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s408">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s407">
                    <Data ss:Type="String">A/C</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s416">
                    <Data ss:Type="String">NUMBER</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="24.75">
                <Cell ss:MergeAcross="6" ss:StyleID="s402">
                    <Data ss:Type="String"></Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s74">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s74">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s74">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s74">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s74">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s74">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s74">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s74">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s74">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s74">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s74">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="9.75">
                <Cell ss:MergeAcross="6" ss:StyleID="s416">
                    <Data ss:Type="String">SIGNATURE: REPRESENTATIVE OF RAILROAD COMMISSION</Data>
                    <NamedCell
                            ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s421">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s421">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s421">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s421">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s421">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s421">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s421">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s421">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s421">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s421">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
                <Cell ss:StyleID="s421">
                    <NamedCell ss:Name="Print_Area"/>
                </Cell>
            </Row>
        </Table>
        <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
            <PageSetup>
                <Layout x:CenterHorizontal="1"/>
                <Header x:Margin="0"/>
                <Footer x:Margin="0"/>
                <PageMargins x:Bottom="0" x:Left="0.25" x:Right="0.25" x:Top="0.5"/>
            </PageSetup>
            <Unsynced/>
            <FitToPage/>
            <Print>
                <BlackAndWhite/>
                <ValidPrinterInfo/>
                <Scale>98</Scale>
                <HorizontalResolution>600</HorizontalResolution>
                <VerticalResolution>600</VerticalResolution>
            </Print>
            <Zoom>150</Zoom>
            <DoNotDisplayGridlines/>
            <TopRowVisible>52</TopRowVisible>
            <Panes>
                <Pane>
                    <Number>3</Number>
                    <ActiveRow>51</ActiveRow>
                    <ActiveCol>6</ActiveCol>
                </Pane>
            </Panes>
            <ProtectObjects>False</ProtectObjects>
            <ProtectScenarios>False</ProtectScenarios>
        </WorksheetOptions>
    </Worksheet>
    <Worksheet ss:Name="TX W-3 Page 2">
        <Table ss:ExpandedColumnCount="18" ss:ExpandedRowCount="42" x:FullColumns="1"
               x:FullRows="1" ss:StyleID="s422" ss:DefaultColumnWidth="51"
               ss:DefaultRowHeight="13">
            <Column ss:Index="3" ss:StyleID="s422" ss:AutoFitWidth="0" ss:Width="16"/>
            <Column ss:StyleID="s422" ss:AutoFitWidth="0" ss:Width="10"/>
            <Column ss:Index="6" ss:StyleID="s422" ss:AutoFitWidth="0" ss:Width="16"
                    ss:Span="1"/>
            <Column ss:Index="8" ss:StyleID="s422" ss:AutoFitWidth="0" ss:Width="23"/>
            <Column ss:Index="10" ss:StyleID="s422" ss:AutoFitWidth="0" ss:Width="16"/>
            <Column ss:Index="12" ss:StyleID="s422" ss:AutoFitWidth="0" ss:Width="69"/>
            <Column ss:StyleID="s422" ss:AutoFitWidth="0" ss:Width="36"/>
            <Column ss:StyleID="s422" ss:AutoFitWidth="0" ss:Width="16"/>
            <Column ss:StyleID="s422" ss:AutoFitWidth="0" ss:Width="13"/>
            <Column ss:StyleID="s422" ss:AutoFitWidth="0" ss:Width="40"/>
            <Column ss:StyleID="s422" ss:AutoFitWidth="0" ss:Width="19"/>
            <Column ss:StyleID="s422" ss:AutoFitWidth="0" ss:Width="44"/>
            <Row ss:AutoFitHeight="0" ss:Height="5.75">
                <Cell ss:StyleID="s423"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s425"/>
                <Cell ss:StyleID="s423"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s425"/>
                <Cell ss:StyleID="s423"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s425"/>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="4" ss:MergeDown="2" ss:StyleID="s426">
                    <Data
                            ss:Type="String">31. Was Well filled with Mud-Laden Fluid, according to the regulations of
                        the Railroad Commission
                    </Data>
                </Cell>
                <Cell ss:StyleID="s429">
                    <Data ss:Type="String">${this.w3Form.value.filledWithMudLaden ? 'X' : ''}</Data>
                </Cell>
                <Cell ss:StyleID="s430">
                    <Data ss:Type="String">Yes</Data>
                </Cell>
                <Cell ss:StyleID="s431"/>
                <Cell ss:MergeAcross="6" ss:StyleID="m105553180966932">
                    <Data ss:Type="String">32. How was mud Applied?</Data>
                </Cell>
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180966952">
                    <Data ss:Type="String">33. Mud Weight</Data>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="5.75">
                <Cell ss:Index="6" ss:StyleID="s437"/>
                <Cell ss:StyleID="s430"/>
                <Cell ss:StyleID="s431"/>
                <Cell ss:StyleID="s438"/>
                <Cell ss:StyleID="s439"/>
                <Cell ss:StyleID="s439"/>
                <Cell ss:StyleID="s439"/>
                <Cell ss:StyleID="s439"/>
                <Cell ss:StyleID="s439"/>
                <Cell ss:StyleID="s440"/>
                <Cell ss:StyleID="s438"/>
                <Cell ss:StyleID="s439"/>
                <Cell ss:StyleID="s440"/>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:Index="6" ss:StyleID="s429">
                    <Data ss:Type="String">${!this.w3Form.value.filledWithMudLaden ? 'X' : ''}</Data>
                </Cell>
                <Cell ss:StyleID="s430">
                    <Data ss:Type="String">No</Data>
                </Cell>
                <Cell ss:StyleID="s431"/>
                <Cell ss:MergeAcross="6" ss:StyleID="m105553180966972">
                    <Data ss:Type="String">${this.w3Form.value.mudAppliedMethod}</Data>
                </Cell>
                <Cell ss:MergeAcross="1" ss:StyleID="s156">
                    <Data ss:Type="String">${this.w3Form.value.mudWeight !== null ? this.w3Form.value.mudWeight : ''}
                    </Data>
                </Cell>
                <Cell ss:StyleID="s441">
                    <Data ss:Type="String">LBS/GAL</Data>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="5.75">
                <Cell ss:StyleID="s426"/>
                <Cell ss:StyleID="s357"/>
                <Cell ss:StyleID="s357"/>
                <Cell ss:StyleID="s357"/>
                <Cell ss:StyleID="s357"/>
                <Cell ss:StyleID="s442"/>
                <Cell ss:StyleID="s430"/>
                <Cell ss:StyleID="s431"/>
                <Cell ss:StyleID="s443"/>
                <Cell ss:StyleID="s444"/>
                <Cell ss:StyleID="s444"/>
                <Cell ss:StyleID="s444"/>
                <Cell ss:StyleID="s444"/>
                <Cell ss:StyleID="s444"/>
                <Cell ss:StyleID="s360"/>
                <Cell ss:StyleID="s189"/>
                <Cell ss:StyleID="s95"/>
                <Cell ss:StyleID="s441"/>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="5.75">
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180967012"/>
                <Cell ss:StyleID="s450"/>
                <Cell ss:StyleID="s450"/>
                <Cell ss:StyleID="s451"/>
                <Cell ss:StyleID="s452"/>
                <Cell ss:StyleID="s452"/>
                <Cell ss:StyleID="s453"/>
                <Cell ss:StyleID="s454"/>
                <Cell ss:StyleID="s455"/>
                <Cell ss:StyleID="s453"/>
                <Cell ss:StyleID="s453"/>
                <Cell ss:StyleID="s453"/>
                <Cell ss:StyleID="s453"/>
                <Cell ss:StyleID="s355"/>
                <Cell ss:StyleID="s355"/>
                <Cell ss:StyleID="s456"/>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180784656">
                    <Data ss:Type="String">34. Total Depth</Data>
                </Cell>
                <Cell ss:StyleID="s439"/>
                <Cell ss:MergeAcross="4" ss:StyleID="s435">
                    <Data ss:Type="String">Other Fresh Water Source by T.D.W.R.</Data>
                </Cell>
                <Cell ss:StyleID="s440"/>
                <Cell ss:MergeAcross="5" ss:StyleID="s434">
                    <Data ss:Type="String">35. Have all Abandoned Wells on this Lease been Plugged</Data>
                </Cell>
                <Cell ss:StyleID="s460">
                    <Data ss:Type="String">${this.w3Form.value.rrcRules ? 'X' : ''}</Data>
                </Cell>
                <Cell ss:StyleID="s431">
                    <Data ss:Type="String">Yes</Data>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="10.25">
                <Cell ss:StyleID="s438"/>
                <Cell ss:StyleID="s439"/>
                <Cell ss:StyleID="s461"/>
                <Cell ss:StyleID="s439"/>
                <Cell ss:MergeAcross="1" ss:StyleID="s463">
                    <Data ss:Type="String">TOP</Data>
                </Cell>
                <Cell ss:StyleID="s75"/>
                <Cell ss:MergeAcross="1" ss:StyleID="s463">
                    <Data ss:Type="String">BOTTOM</Data>
                </Cell>
                <Cell ss:StyleID="s464"/>
                <Cell ss:StyleID="s438"/>
                <Cell ss:StyleID="s439"/>
                <Cell ss:StyleID="s439"/>
                <Cell ss:StyleID="s439"/>
                <Cell ss:StyleID="s439"/>
                <Cell ss:StyleID="s439"/>
                <Cell ss:StyleID="s442"/>
                <Cell ss:StyleID="s431"/>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="1" ss:StyleID="s158">
                    <Data ss:Type="String">${this.w3Form.value.totalDepth2 ? this.w3Form.value.totalDepth2 : ''}</Data>
                </Cell>
                <Cell ss:StyleID="s461"/>
                <Cell ss:StyleID="s439"/>
                <Cell ss:MergeAcross="1" ss:StyleID="s466">
                    <Data ss:Type="String">
                        ${this.w3Form.value.otherFreshWaterZones[0] && this.w3Form.value.otherFreshWaterZones[0].top !== null ? this.w3Form.value.otherFreshWaterZones[0].top : ''}
                    </Data>
                </Cell>
                <Cell ss:StyleID="s468"/>
                <Cell ss:MergeAcross="1" ss:StyleID="s466">
                    <Data ss:Type="String">
                        ${this.w3Form.value.otherFreshWaterZones[0] && this.w3Form.value.otherFreshWaterZones[0].bottom !== null ? this.w3Form.value.otherFreshWaterZones[0].bottom : ''}
                    </Data>
                </Cell>
                <Cell ss:StyleID="s469"/>
                <Cell ss:MergeAcross="5" ss:StyleID="s434">
                    <Data ss:Type="String">according to RRC Rules?</Data>
                </Cell>
                <Cell ss:StyleID="s460">
                    <Data ss:Type="String">${!this.w3Form.value.rrcRules ? 'X' : ''}</Data>
                </Cell>
                <Cell ss:StyleID="s431">
                    <Data ss:Type="String">No</Data>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="3.75">
                <Cell ss:StyleID="s189"/>
                <Cell ss:StyleID="s95"/>
                <Cell ss:StyleID="s461"/>
                <Cell ss:StyleID="s439"/>
                <Cell ss:StyleID="s470"/>
                <Cell ss:StyleID="s470"/>
                <Cell ss:StyleID="s468"/>
                <Cell ss:StyleID="s470"/>
                <Cell ss:StyleID="s470"/>
                <Cell ss:StyleID="s469"/>
                <Cell ss:StyleID="s471"/>
                <Cell ss:StyleID="s472"/>
                <Cell ss:StyleID="s472"/>
                <Cell ss:StyleID="s472"/>
                <Cell ss:StyleID="s472"/>
                <Cell ss:StyleID="s472"/>
                <Cell ss:StyleID="s473"/>
                <Cell ss:StyleID="s474"/>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180557728"/>
                <Cell ss:StyleID="s75"/>
                <Cell ss:MergeAcross="1" ss:StyleID="s466">
                    <Data ss:Type="String">
                        ${this.w3Form.value.otherFreshWaterZones[1] && this.w3Form.value.otherFreshWaterZones[1].top !== null ? this.w3Form.value.otherFreshWaterZones[1].top : ''}
                    </Data>
                </Cell>
                <Cell ss:StyleID="s479"/>
                <Cell ss:MergeAcross="1" ss:StyleID="s466">
                    <Data ss:Type="String">
                        ${this.w3Form.value.otherFreshWaterZones[1] && this.w3Form.value.otherFreshWaterZones[1].bottom !== null ? this.w3Form.value.otherFreshWaterZones[1].bottom : ''}
                    </Data>
                </Cell>
                <Cell ss:StyleID="s469"/>
                <Cell ss:MergeAcross="7" ss:StyleID="m105553180557788">
                    <Data ss:Type="String">36. If NO, Explain</Data>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180557808">
                    <Data ss:Type="String">Depth of Deepest</Data>
                </Cell>
                <Cell ss:StyleID="s430"/>
                <Cell ss:MergeAcross="1" ss:StyleID="s466">
                    <Data ss:Type="String">
                        ${this.w3Form.value.otherFreshWaterZones[2] && this.w3Form.value.otherFreshWaterZones[2].top !== null ? this.w3Form.value.otherFreshWaterZones[2].top : ''}
                    </Data>
                </Cell>
                <Cell ss:StyleID="s479"/>
                <Cell ss:MergeAcross="1" ss:StyleID="s466">
                    <Data ss:Type="String">
                        ${this.w3Form.value.otherFreshWaterZones[2] && this.w3Form.value.otherFreshWaterZones[2].bottom !== null ? this.w3Form.value.otherFreshWaterZones[2].bottom : ''}
                    </Data>
                </Cell>
                <Cell ss:StyleID="s469"/>
                <Cell ss:MergeAcross="7" ss:MergeDown="3" ss:StyleID="m105553180557868">
                    <Data
                            ss:Type="String">${this.w3Form.value.explainance ? this.w3Form.value.explainance : ''}
                    </Data>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180557888">
                    <Data ss:Type="String">Fresh Water</Data>
                </Cell>
                <Cell ss:StyleID="s439"/>
                <Cell ss:MergeAcross="1" ss:StyleID="s466">
                    <Data ss:Type="String">
                        ${this.w3Form.value.otherFreshWaterZones[3] && this.w3Form.value.otherFreshWaterZones[3].top !== null ? this.w3Form.value.otherFreshWaterZones[3].top : ''}
                    </Data>
                </Cell>
                <Cell ss:StyleID="s479"/>
                <Cell ss:MergeAcross="1" ss:StyleID="s466">
                    <Data ss:Type="String">
                        ${this.w3Form.value.otherFreshWaterZones[3] && this.w3Form.value.otherFreshWaterZones[3].bottom !== null ? this.w3Form.value.otherFreshWaterZones[3].bottom : ''}
                    </Data>
                </Cell>
                <Cell ss:StyleID="s469"/>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="1" ss:StyleID="s158">
                    <Data ss:Type="String">
                        ${this.w3Form.value.deepestFreshWaterDepth !== null ? this.w3Form.value.deepestFreshWaterDepth : ''}
                    </Data>
                </Cell>
                <Cell ss:StyleID="s461"/>
                <Cell ss:StyleID="s439"/>
                <Cell ss:MergeAcross="1" ss:StyleID="s466">
                    <Data ss:Type="String">
                        ${this.w3Form.value.otherFreshWaterZones[4] && this.w3Form.value.otherFreshWaterZones[4].top !== null ? this.w3Form.value.otherFreshWaterZones[4].top : ''}
                    </Data>
                </Cell>
                <Cell ss:StyleID="s479"/>
                <Cell ss:MergeAcross="1" ss:StyleID="s466">
                    <Data ss:Type="String">
                        ${this.w3Form.value.otherFreshWaterZones[4] && this.w3Form.value.otherFreshWaterZones[4].bottom !== null ? this.w3Form.value.otherFreshWaterZones[4].bottom : ''}
                    </Data>
                </Cell>
                <Cell ss:StyleID="s469"/>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="3.75">
                <Cell ss:MergeAcross="2" ss:StyleID="m105553180562176"/>
                <Cell ss:StyleID="s402"/>
                <Cell ss:MergeAcross="1" ss:StyleID="s402"/>
                <Cell ss:StyleID="s402"/>
                <Cell ss:StyleID="s402"/>
                <Cell ss:StyleID="s402"/>
                <Cell ss:StyleID="s494"/>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="21">
                <Cell ss:MergeAcross="13" ss:StyleID="m105553180567296">
                    <Data ss:Type="String">37. Name and Address of Cementing or Service company who mixed and pumped
                        cement plugs in this well
                    </Data>
                </Cell>
                <Cell ss:MergeAcross="3" ss:StyleID="m105553180567316">
                    <Data ss:Type="String">Date RRC District Office notified &#10;of plugging</Data>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="16">
                <Cell ss:MergeAcross="13" ss:StyleID="m105553180567336">
                    <Data ss:Type="String">${this.w3Form.value.nameAddressCementingServiceCompany}</Data>
                </Cell>
                <Cell ss:MergeAcross="3" ss:StyleID="m105553180567356">
                    <Data ss:Type="String">
                        ${this.w3Form.value.rrcDistrictDate ? ('0' + (new Date(this.w3Form.value.rrcDistrictDate).getMonth() + 1)).slice(-2) + '/' + new Date(this.w3Form.value.rrcDistrictDate).getDate() + '/' + new Date(this.w3Form.value.rrcDistrictDate).getFullYear() : ''}
                    </Data>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="17" ss:StyleID="m105553180567376">
                    <Data ss:Type="String">38. Name and Addresses of Surface Owner of Well Site and Operators of Offset
                        Producing Leases
                    </Data>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="91.75">
                <Cell ss:MergeAcross="17" ss:StyleID="m105553180567396">
                    <Data ss:Type="String">${this.w3Form.value.nameAddressSurfaceOwner}</Data>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="17" ss:StyleID="m105553180970032">
                    <Data ss:Type="String">39. Was Notice Given Before Plugging to Each of the Above?</Data>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="17" ss:StyleID="m105553180970052">
                    <Data ss:Type="String">${this.w3Form.value.noticeGivenData}</Data>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="17" ss:StyleID="m105553180970072">
                    <Data ss:Type="String">FILL IN BELOW FOR DRY HOLES ONLY</Data>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="17" ss:StyleID="m105553180970092">
                    <Data ss:Type="String">40. For dry Holes, this Form must be accompanied by either a Driller's,
                        Electric, Radioactivity or Acoustical/Sonic Log or such Log must be
                    </Data>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0">
                <Cell ss:MergeAcross="17" ss:StyleID="m105553180970112">
                    <Data ss:Type="String">released to a Commercial Log Service,</Data>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="8.25">
                <Cell ss:MergeAcross="17" ss:StyleID="m105553180970132"/>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25" ss:StyleID="s539">
                <Cell ss:StyleID="s540"/>
                <Cell ss:StyleID="s540"/>
                <Cell ss:StyleID="s541">
                    <Data ss:Type="String">${this.w3Form.value.logAttached ? 'X' : ''}</Data>
                </Cell>
                <Cell ss:StyleID="s542">
                    <Data ss:Type="String">Log Attached</Data>
                </Cell>
                <Cell ss:StyleID="s542"/>
                <Cell ss:StyleID="s540"/>
                <Cell ss:StyleID="s541">
                    <Data ss:Type="String">${this.w3Form.value.logReleased ? 'X' : ''}</Data>
                </Cell>
                <Cell ss:StyleID="s542">
                    <Data ss:Type="String">Log released to</Data>
                </Cell>
                <Cell ss:StyleID="s542"/>
                <Cell ss:MergeAcross="3" ss:StyleID="s544">
                    <Data ss:Type="String">
                        ${this.w3Form.value.logReleasedDescription ? this.w3Form.value.logReleasedDescription : ''}
                    </Data>
                </Cell>
                <Cell ss:StyleID="s546">
                    <Data ss:Type="String">Date</Data>
                </Cell>
                <Cell ss:Index="16" ss:MergeAcross="2" ss:StyleID="m105553181201508">
                    <Data
                            ss:Type="String">
                        ${this.w3Form.value.logReleasedDate ? ('0' + (new Date(this.w3Form.value.logReleasedDate).getMonth() + 1)).slice(-2) + '/' + new Date(this.w3Form.value.logReleasedDate).getDate() + '/' + new Date(this.w3Form.value.logReleasedDate).getFullYear() : ''}
                    </Data>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="17" ss:StyleID="m105553181201528">
                    <Data ss:Type="String">Type Logs:</Data>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25" ss:StyleID="s539">
                <Cell ss:StyleID="s540"/>
                <Cell ss:StyleID="s540"/>
                <Cell ss:StyleID="s541">
                    <Data ss:Type="String">${this.w3Form.value.drillersLog ? 'X' : ''}</Data>
                </Cell>
                <Cell ss:StyleID="s542">
                    <Data ss:Type="String">Driller's</Data>
                </Cell>
                <Cell ss:StyleID="s542"/>
                <Cell ss:StyleID="s542"/>
                <Cell ss:StyleID="s556">
                    <Data ss:Type="String">${this.w3Form.value.electricLog ? 'X' : ''}</Data>
                </Cell>
                <Cell ss:StyleID="s542">
                    <Data ss:Type="String">Electric</Data>
                </Cell>
                <Cell ss:Index="10" ss:StyleID="s557">
                    <Data ss:Type="String">${this.w3Form.value.radioactivityLog ? 'X' : ''}</Data>
                </Cell>
                <Cell ss:StyleID="s542">
                    <Data ss:Type="String">Radioactivity</Data>
                </Cell>
                <Cell ss:Index="13" ss:StyleID="s542"/>
                <Cell ss:StyleID="s556">
                    <Data ss:Type="String">${this.w3Form.value.acousticalSonicLog ? 'X' : ''}</Data>
                </Cell>
                <Cell ss:StyleID="s542">
                    <Data ss:Type="String">Acoustical/Sonic</Data>
                </Cell>
                <Cell ss:Index="17" ss:StyleID="s542"/>
                <Cell ss:StyleID="s558"/>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="17" ss:StyleID="m105553181201548"/>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="17" ss:StyleID="m105553181201568">
                    <Data ss:Type="String">41. Date FORM P-8 (Special Clearance) Filed?</Data>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="2" ss:StyleID="s158">
                    <Data ss:Type="String">${this.w3Form.value.dateFormP8 ? this.w3Form.value.dateFormP8 : ''}</Data>
                </Cell>
                <Cell ss:StyleID="s202"/>
                <Cell ss:MergeAcross="13" ss:StyleID="m105553181201608"/>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="4" ss:StyleID="s567">
                    <Data ss:Type="String">42. Amount of Oil produced prior to Plugging</Data>
                </Cell>
                <Cell ss:MergeAcross="3" ss:StyleID="s570">
                    <Data ss:Type="String">
                        ${this.w3Form.value.producedOilAmount !== null ? this.w3Form.value.producedOilAmount : ''}
                    </Data>
                </Cell>
                <Cell ss:StyleID="s572"/>
                <Cell ss:StyleID="s573">
                    <Data ss:Type="String">bbls *</Data>
                </Cell>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s425"/>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="17" ss:StyleID="m105553180785320">
                    <Data ss:Type="String">* File FORM P-1 (Oil Production Report) for month this oil was produced
                    </Data>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="17" ss:StyleID="m105553180785340">
                    <ss:Data
                            ss:Type="String" xmlns="http://www.w3.org/TR/REC-html40">
                        <B>
                            <Font
                                    html:Color="#000000"></Font>
                            <U>
                                <Font html:Color="#000000">R R C USE ONLY</Font>
                            </U>
                        </B>
                    </ss:Data>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="14.25">
                <Cell ss:MergeAcross="2" ss:StyleID="s587">
                    <Data ss:Type="String">Nearest Field</Data>
                </Cell>
                <Cell ss:StyleID="s589"/>
                <Cell ss:MergeAcross="12" ss:StyleID="s591">
                    <Data ss:Type="String"></Data>
                </Cell>
                <Cell ss:StyleID="s593"/>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="4.5">
                <Cell ss:MergeAcross="2" ss:StyleID="s595"/>
                <Cell ss:StyleID="s470"/>
                <Cell ss:MergeAcross="12" ss:StyleID="s424"/>
                <Cell ss:StyleID="s593"/>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="16.25">
                <Cell ss:StyleID="s596"/>
                <Cell ss:StyleID="s597"/>
                <Cell ss:StyleID="s597"/>
                <Cell ss:StyleID="s597"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s424"/>
                <Cell ss:StyleID="s425"/>
            </Row>
            <Row ss:AutoFitHeight="0">
                <Cell ss:StyleID="s598">
                    <Data ss:Type="String">REMARKS</Data>
                </Cell>
                <Cell ss:StyleID="s599"/>
                <Cell ss:StyleID="s599"/>
                <Cell ss:StyleID="s599"/>
                <Cell ss:StyleID="s599"/>
                <Cell ss:StyleID="s599"/>
                <Cell ss:StyleID="s599"/>
                <Cell ss:StyleID="s599"/>
                <Cell ss:StyleID="s599"/>
                <Cell ss:StyleID="s599"/>
                <Cell ss:StyleID="s599"/>
                <Cell ss:StyleID="s599"/>
                <Cell ss:StyleID="s599"/>
                <Cell ss:StyleID="s599"/>
                <Cell ss:StyleID="s599"/>
                <Cell ss:StyleID="s599"/>
                <Cell ss:StyleID="s599"/>
                <Cell ss:StyleID="s600"/>
            </Row>
            <Row ss:AutoFitHeight="0" ss:Height="220.25">
                <Cell ss:MergeAcross="17" ss:StyleID="m105553180567752">
                    <Data ss:Type="String">${this.w3Form.value.remarks}</Data>
                </Cell>
            </Row>
            <Row ss:AutoFitHeight="0">
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
            </Row>
            <Row ss:AutoFitHeight="0">
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
            </Row>
            <Row ss:AutoFitHeight="0">
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
                <Cell ss:StyleID="s608"/>
            </Row>
        </Table>
        <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
            <PageSetup>
                <Layout x:CenterHorizontal="1"/>
                <Header x:Margin="0"/>
                <Footer x:Margin="0"/>
                <PageMargins x:Bottom="0.2" x:Left="0.2" x:Right="0.2" x:Top="0.38"/>
            </PageSetup>
            <Unsynced/>
            <Print>
                <BlackAndWhite/>
                <ValidPrinterInfo/>
                <HorizontalResolution>600</HorizontalResolution>
                <VerticalResolution>600</VerticalResolution>
            </Print>
            <Zoom>150</Zoom>
            <Selected/>
            <DoNotDisplayGridlines/>
            <TopRowVisible>26</TopRowVisible>
            <Panes>
                <Pane>
                    <Number>3</Number>
                    <ActiveRow>38</ActiveRow>
                    <RangeSelection>R39C1:R39C18</RangeSelection>
                </Pane>
            </Panes>
            <ProtectObjects>False</ProtectObjects>
            <ProtectScenarios>False</ProtectScenarios>
        </WorksheetOptions>
    </Worksheet>
</Workbook>`;
        const blob = new Blob([template], {type: 'text/csv'});
        saveAs(blob, `${name}.xml`);
    }

    transfer() {
        if (this.transferSub) {
            this.transferSub.unsubscribe();
        }

        this.transferSub = this.setTransfer.req(this.f['id'].value, this.wellId, this.formType['W3'], this.svc).subscribe(res => {
            if (res.header.status === 4000) {
                this.w3Form.get('assigneeAccessLevel').setValue(this.accessLevelEnum['Supervisor']);
                this.w3Form.get('supervisorSign').setValue(null);
                this.w3Form.get('managerSign').setValue(null);
                this.getWellsSub = this.getWells.req(this.svc).subscribe();
                this.selectW3Sub = this.selectW3.req(this.svc).subscribe();
            }
        });
    }

    onSubmit(status) {
        this.markFormGroupTouched(this.w3Form);
        if (this.w3Form.valid) {
            const user = JSON.parse(localStorage.getItem('userId'));
            if (status === 2) {
                this.w3Form.value.managerSign = {
                    name: `${user.firstName} ${user.lastName}`,
                    date: `${('0' + (new Date().getMonth() + 1)).slice(-2) + '.' + new Date().getDate() + '.' + new Date().getFullYear()}`,
                    phone: `${user.phone ? user.phone : ''}`
                };
            }
            if (status === 1) {
                this.w3Form.get('assigneeAccessLevel').setValue(this.accessLevelEnum['Manager']);
                this.w3Form.value.supervisorSign = {
                    name: `${user.firstName} ${user.lastName}`,
                    date: `${('0' + (new Date().getMonth() + 1)).slice(-2) + '.' + new Date().getDate() + '.' + new Date().getFullYear()}`,
                    companyName: 'JMR'
                };
            }
            if (status === 0) {
                this.w3Form.get('managerSign').setValue(null);
                this.w3Form.get('supervisorSign').setValue(null);
            }
            this.w3Form.value.drillingPermitIssuedDate = this.w3Form.value.drillingPermitIssuedDate ?
                +new Date(this.w3Form.value.drillingPermitIssuedDate).setHours(0, 0, 0, 0) : null;
            this.w3Form.value.drillingCommencedDate = this.w3Form.value.drillingCommencedDate ?
                +new Date(this.w3Form.value.drillingCommencedDate).setHours(0, 0, 0, 0) : null;
            this.w3Form.value.drillingCompletedDate = this.w3Form.value.drillingCompletedDate ?
                +new Date(this.w3Form.value.drillingCompletedDate).setHours(0, 0, 0, 0) : null;
            this.w3Form.value.wellPluggedDate = this.w3Form.value.wellPluggedDate ?
                +new Date(this.w3Form.value.wellPluggedDate).setHours(0, 0, 0, 0) : null;
            this.w3Form.value.rrcDistrictDate = this.w3Form.value.rrcDistrictDate ?
                +new Date(this.w3Form.value.rrcDistrictDate).setHours(0, 0, 0, 0) : null;
            this.w3Form.value.logReleasedDate = this.w3Form.value.logReleasedDate ?
                +new Date(this.w3Form.value.logReleasedDate).setHours(0, 0, 0, 0) : null;
            this.w3Form.value.status = status;
            if (!this.w3Form.value.id) {
                delete this.w3Form.value.id;
            }

            // Disable Offline Mode

            this.insertW3Sub = this.insertW3.req(this.w3Form.value, this.svc).subscribe(res => {
                if (res.header.status === 4000) {
                    this.successes = true;
                    this.selectW3Sub = this.selectW3.req(this.svc).subscribe();
                    this.getWellsSub = this.getWells.req(this.svc).subscribe();
                    if (status > 0) {
                        this.router.navigate(['list/well']);
                    } else {
                        this.w3Form.get('id').setValue(res.body.key.id);
                        this.success('Saved successfully');
                        this.dbSvc.update('w3', this.w3Form.value);
                    }
                } else {
                    this.successes = false;
                    this.error(res.header.summary);
                }
                this.insertW3Sub.unsubscribe();
            });
        }
    }
}
