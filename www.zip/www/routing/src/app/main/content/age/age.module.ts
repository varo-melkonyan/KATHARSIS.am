import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {AgeRoutingModule} from './age-routing.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AgeRoutingModule
  ]
})
export class AgeModule { }
