import {Component, OnDestroy, OnInit} from '@angular/core';
import {HeaderService} from '../../services/header.service';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {WsService} from '../../services/ws.service';
import {AlertService} from '../../services/alert.service';
import {Router} from '@angular/router';
import {ISubscription} from 'rxjs/Subscription';
import {LokiService} from '../../services/loki.service';

@Component({
    selector: 'app-settings',
    templateUrl: './settings.component.html',
    styleUrls: ['./settings.component.scss']
})
export class SettingsComponent implements OnInit, OnDestroy {
    public settingsForm: FormGroup;
    private userSub: ISubscription;
    public item;
    public passEye = true;
    public insertUser: any;
    public settingsUserSub: any;
    public getUser: any;
    public getUserOne: any;
    public getUserSub: any;
    public getUserOneSub: any;

    constructor(private headerSvc: HeaderService,
                private router: Router,
                private alertService: AlertService,
                private svc: WsService,
                private fb: FormBuilder,
                private lokiSrc: LokiService) {
        this.headerSvc.setUrlParams('Account Settings');
        this.item = JSON.parse(localStorage.getItem('userId'));
        this.initForm(this.item);
        this.settingsUserSub = this.lokiSrc.returnCallSub().subscribe(coll => {
            if (coll) {
                this.insertUser = coll.by('name', 'insertUser');
                this.getUser = coll.by('name', 'getUser');
                this.getUserOne = coll.by('name', 'getUserOne');
            }
        });
    }

    ngOnInit() {
        if (!localStorage.getItem('sign')) {
            this.router.navigate(['sign-in']);
        }
    }

    ngOnDestroy() {
        if (this.userSub) {
            this.userSub.unsubscribe();
        }
        if (this.getUserSub) {
            this.getUserSub.unsubscribe();
        }
        if (this.getUserOneSub) {
            this.getUserOneSub.unsubscribe();
        }
    }

    initForm(item) {
        this.settingsForm = this.fb.group({
            id: item.id,
            accessLevel: item.accessLevel,
            firstName: [item && item.firstName ? item.firstName : '', Validators.required],
            lastName: [item && item.lastName ? item.lastName : '', Validators.required],
            phone: [item && item.phone ? item.phone : '', Validators.pattern('^\\(?([+]?\\d{1,2}[.-\\s]?)?(\\d{3}[.-]?){2}\\d{4}$')],
            email: [item && item.email ? item.email : '', [Validators.required, Validators.email]],
            commissionEmail: [item && item.commissionEmail ? item.commissionEmail : '', [Validators.required, Validators.email]],
            autoSendToCommission: [item && item.autoSendToCommission ? item.autoSendToCommission : false]
        });
    }

    markFormGroupTouched(formGroup: FormGroup) {
        (<any>Object).values(formGroup.controls).forEach(control => {
            control.markAsTouched();

            if (control.controls) {
                this.markFormGroupTouched(control);
            }
        });
    }

    success(message: string) {
        this.alertService.success(message);
    }

    error(message: string) {
        this.alertService.error(message);
    }

    onSubmit() {
        this.markFormGroupTouched(this.settingsForm);
        if (this.settingsForm.valid) {
            this.userSub = this.insertUser.req(this.settingsForm.value, this.svc).subscribe(res => {
                if (res.header.status === 4000) {
                   this.getUserSub = this.getUser.req(this.svc).subscribe();
                   this.getUserOneSub = this.getUserOne.req('', this.svc).subscribe();
                    this.router.navigate(['list/employee']);
                } else {
                    this.error(res.header.summary);
                }
                this.userSub.unsubscribe();
            });
        }
    }

}
