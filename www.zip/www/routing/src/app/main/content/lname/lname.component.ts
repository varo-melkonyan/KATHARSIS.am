import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lname',
  templateUrl: './lname.component.html',
  styleUrls: ['./lname.component.css']
})
export class LnameComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
