import { Pipe, PipeTransform } from '@angular/core';


@Pipe({
  name: 'ongoing'
})
export class OngoingFilter implements PipeTransform {
  transform (items: any[]): any[] {
    if (!items) {
      return [];
    }
    return items.filter(it => {
      return it.status === 1;
    });
  }
}
