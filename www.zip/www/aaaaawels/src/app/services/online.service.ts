import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';

import { Subject, BehaviorSubject } from 'rxjs';


@Injectable()
export class OnlineService {
    public isOnline = new BehaviorSubject<boolean>(true);


    constructor () {

    }

    setIsOnline (onlineEvent) {
        this.isOnline.next(onlineEvent);
    }

    getIsOnline () {
        return this.isOnline;
    }
}
