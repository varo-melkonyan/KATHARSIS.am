import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material';
import { LoadingPopComponent } from '../components/loading-pop/loading-pop.component';


@Injectable()
export class LoadingService {

  constructor(public dialog: MatDialog) {
  }


  startLoading() {
    if (this.dialog.openDialogs.length === 0) {
      this.dialog.open(LoadingPopComponent, {
        disableClose: true,
        panelClass: 'pop-loading'
      });
    }
  }

  endLoading() {
    this.dialog.closeAll();
  }
}
