import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { HeaderService } from '../../services/header.service';
import { ISubscription } from 'rxjs/Subscription';
import { WsService } from '../../services/ws.service';
import { OnlineService } from '../../services/online.service';
import {LokiService} from '../../services/loki.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit, OnDestroy {
  @Output() toggleBar: EventEmitter<any> = new EventEmitter();
  @Input() isBar: boolean;
  private headerSub: ISubscription;
  public id: string;
  public user: any;
  public userSub: any;
  public isOnline: boolean;
  public getThisUserSub: any;
  public getThisUser: any;

  constructor(private router: Router,
              private wsService: WsService,
              private isOnlineSvc: OnlineService,
              private headerSvc: HeaderService,
              private lokiSvc: LokiService) {

    this.getThisUserSub = this.lokiSvc.returnCallSub().subscribe(coll => {
      if (coll) {
        this.getThisUser = coll.by('name', 'getUserOne');
        this.userSub = this.getThisUser.req('', this.wsService).subscribe(user => {
          this.user = user['body'].record;
        });
      }
    });
    this.user = JSON.parse(localStorage.getItem('userId'));
    this.headerSub = this.headerSvc.getUrlParams().subscribe(id => {
      if (id) {
        this.id = id;
      }
    });
    this.isOnlineSvc.getIsOnline().subscribe(isOnline => {
        this.isOnline = isOnline;
    });
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.headerSub.unsubscribe();
    this.userSub.unsubscribe();
  }

  toggleBarFn() {
    this.toggleBar.emit(!this.isBar);
  }

  setAccount() {
    this.router.navigate(['settings']);
  }
  setPassword() {
    this.router.navigate(['change-password']);
  }

  logOut() {
    this.wsService.closeConnect();
    localStorage.removeItem('sign');
    this.router.navigate(['sign-in']);
  }

  stopProp(e) {
    e.stopPropagation();
  }

}
