import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {RouterModule, Routes} from '@angular/router';
import {ContentComponent} from './content.component';
import {NameComponent} from './name/name.component';
import {LnameComponent} from './lname/lname.component';
import {AgeComponent} from './age/age.component';

const routes: Routes = [
  {
    path: '', component: ContentComponent,
    children: [
      {path: 'name/:id', component: NameComponent},
      {path: 'lastname/:id', component: LnameComponent},
      {path: 'age/:id', component: AgeComponent}
    ]
  },
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
  ]
})
export class ContentRoutingModule {
}
