const config = {
    query_url: "wordspinner/getsetsone?_uid="
}