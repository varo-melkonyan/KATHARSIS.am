import { Component, OnDestroy, OnInit } from '@angular/core';
import { HeaderService } from '../../services/header.service';
import { Subscription } from 'rxjs/Subscription';
import { Router } from '@angular/router';
import { LoadingService } from '../../services/loading.service';
import { AddWellService } from './add-well.service';
import { DbService } from '../../services/db.service';
import {log} from 'util';

@Component({
  selector: 'app-add-well',
  templateUrl: './add-well.component.html',
  styleUrls: ['./add-well.component.scss']
})
export class AddWellComponent implements OnInit, OnDestroy {
  private headerSub: Subscription;
  private routerSub: Subscription;
  public addWellSub: Subscription;
  public dbReady: Subscription;
  public id = '';
  public step = 0;
  public page = '';
  public item;

  constructor(private headerSvc: HeaderService,
              private loadingSvc: LoadingService,
              private addWellSvc: AddWellService,
              private dbSvc: DbService,
              private router: Router) {
    this.getRouting();
    this.headerSvc.setUrlParams('Add New Well');
    this.routerSub = router.events.subscribe(event => {
      if (this.router.url.length < 16) {
        this.headerSvc.setUrlParams('Add New Well');
        this.addWellSvc.setSelectedWell(null);
        this.item = null;
        this.getRouting();
      }
    });
    this.dbReady = this.dbSvc.getDbReady().subscribe(ready => {
      if (ready) {
        if (this.addWellSub) {
          this.addWellSub.unsubscribe();
        }
        this.addWellSub = this.addWellSvc.getEditItemName().subscribe(id => {
          this.getRouting();
          if (id) {
            this.id = id.split(' ').join('/');
            this.dbSvc.openDatabase().then(() => {
              this.dbSvc.getByKey('wells', this.id).then(
                  well => {
                    if (well) {
                      this.item = well;
                      this.headerSvc.setUrlParams(this.item.name);
                      this.addWellSvc.setSelectedWell(this.item);
                    } else {
                      this.router.navigate(['/']);
                    }
                  },
                  error => {
                  }
              );
            });
          } else {
            this.headerSvc.setUrlParams('Add New Well');
            this.addWellSvc.setSelectedWell(null);
            this.item = null;
          }
        });
      }
    });
  }

  ngOnInit() {
    if (!localStorage.getItem('sign')) {
      this.router.navigate(['sign-in']);
    }
  }

  ngOnDestroy() {
    if (this.headerSub) {
      this.headerSub.unsubscribe();
    }
    if (this.dbReady) {
      this.dbReady.unsubscribe();
    }
    if (this.addWellSub) {
      this.addWellSub.unsubscribe();
    }
    if (this.routerSub) {
      this.routerSub.unsubscribe();
    }
  }

  getRouting() {
    if (this.router.url.indexOf('/well/well-form') > -1) {
      this.step = 0;
      this.page = 'well-form';
    }
    if (this.router.url.indexOf('/well/w3a-form') > -1) {
      this.step = 1;
      this.page = 'w3a-form';
    }
    if (this.router.url.indexOf('/well/dwr-form') > -1) {
      this.step = 2;
      this.page = 'dwr-form';
    }
    if (this.router.url.indexOf('/well/w3-form') > -1) {
      this.step = 3;
      this.page = 'w3-form';
    }
  }

  setPage(page) {
    if (this.page === page) {
      return false;
    }
    window.scrollTo(0,  0);
    this.loadingSvc.startLoading();
    const ids  = this.id.split('/').join(' ');
    this.router.navigate([this.id ? `well/${page}/${ids}` : `well/${page}`]);
    this.page = page;
  }
}
