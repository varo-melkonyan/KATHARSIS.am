import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';

import { Subject, BehaviorSubject } from 'rxjs';


@Injectable()
export class AddWellService {
  public editItemName = new BehaviorSubject<string>(null);
  public selectedWell = new BehaviorSubject<any>(null);


  constructor () {

  }

  setEditItemName (id) {
    this.editItemName.next(id);
  }

  getEditItemName () {
    return this.editItemName;
  }

  setSelectedWell (well) {
    this.selectedWell.next(well);
  }

  getSelectedWell () {
    return this.selectedWell;
  }


}
