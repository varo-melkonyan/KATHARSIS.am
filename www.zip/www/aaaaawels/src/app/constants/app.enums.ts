export enum AccessLevel {
    Administrator,
    Manager,
    Supervisor,
    Crewman
}
export enum WellStatus {
    Upcoming,
    Ongoing,
    Done
}
export enum FormStatus {
    Unsigned,
    Signed,
    Confirmed
}

export enum FormType {
    DWR,
    W3A,
    W3
}
