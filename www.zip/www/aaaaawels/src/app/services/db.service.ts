import { Injectable } from '@angular/core';
import { IndexDetails, NgxIndexedDB } from 'ngx-indexed-db';
import { appConfig } from '../constants/app.config';
import { BehaviorSubject } from 'rxjs';
import {AddWellService} from '../components/add-well/add-well.service';


@Injectable()
export class DbService {
    public db = new NgxIndexedDB(appConfig.dbName, appConfig.dbVersion);
    private dbVersion = appConfig.dbVersion;
    private dbReady = new BehaviorSubject<boolean>(null);

    constructor (private wellSvc: AddWellService) {
        this.createDB();
    }
    createDB() {
        window.indexedDB.deleteDatabase(appConfig.dbName);
        this.db.openDatabase(this.dbVersion, evt => {
            const wells = evt.currentTarget.result.createObjectStore('wells', {
                keyPath: 'id',
                autoIncrement: true
            });
            wells.createIndex('isEdit', 'isEdit', {unique: false});

            const teams = evt.currentTarget.result.createObjectStore('teams', {
                keyPath: 'id',
                autoIncrement: true
            });
            teams.createIndex('isEdit', 'isEdit', {unique: false});

            const users = evt.currentTarget.result.createObjectStore('users', {
                keyPath: 'id',
                autoIncrement: true
            });
            users.createIndex('isEdit', 'isEdit', {unique: false});

            const w3a = evt.currentTarget.result.createObjectStore('w3a', {keyPath: 'id', autoIncrement: true});
            w3a.createIndex('wellId', 'wellId', {unique: false});
            w3a.createIndex('isEdit', 'isEdit', {unique: false});

            const w3 = evt.currentTarget.result.createObjectStore('w3', {keyPath: 'id', autoIncrement: true});
            w3.createIndex('wellId', 'wellId', {unique: false});
            w3.createIndex('isEdit', 'isEdit', {unique: false});

            const dwr = evt.currentTarget.result.createObjectStore('dwr', {keyPath: 'id', autoIncrement: true});
            dwr.createIndex('wellId', 'wellId', {unique: false});
            dwr.createIndex('date', 'date', {unique: false});
            dwr.createIndex('isEdit', 'isEdit', {unique: false});
        });
    }

    getAllByIndexAndValue(storeName: string, index: string, value: any) {
        return this.db.getAll(storeName, IDBKeyRange.only(value), {
            indexName: index,
            order: 'asc'
        });
    }

    openDatabase(upgradeCallback?: Function): Promise<any> {
        return this.db.openDatabase(this.dbVersion, upgradeCallback);
    }
    getAll(storeName: string, keyRange?: IDBKeyRange, indexDetails?: IndexDetails): Promise<any> {
        return this.db.getAll(storeName, keyRange, indexDetails);
    }
    update(storeName: string, value: any, key?: any): Promise<any> {
        return this.db.update(storeName, value, key);
    }
    add(storeName: string, value: any, key?: any): Promise<any> {
        return this.db.add(storeName, value, key);
    }
    getByKey(storeName: string, key: any): Promise<any> {
        return this.db.getByKey(storeName, key);
    }
    getByIndex(storeName: string, indexName: string, key: any): Promise<any> {
        return this.db.getByIndex(storeName, indexName, key);
    }
    delete(storeName: string, key: any): Promise<any> {
        return this.db.delete(storeName, key);
    }
    deleteDatabase() {
        window.indexedDB.deleteDatabase(appConfig.dbName);
    }
    openCursor(storeName: string, cursorCallback: (evt: Event) => void, keyRange?: IDBKeyRange): Promise<any> {
        return this.db.openCursor(storeName, cursorCallback, keyRange);
    }
    clear(storeName: string): Promise<any> {
        return this.db.clear(storeName);
    }
    count(storeName: string, keyRange?: IDBValidKey | IDBKeyRange): Promise<any> {
        return this.db.count(storeName, keyRange);
    }
    setDbReady() {
        this.dbReady.next(true);
    }
    getDbReady() {
        return this.dbReady;
    }
}
