import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loading-pop',
  templateUrl: './loading-pop.component.html',
  styleUrls: ['./loading-pop.component.scss']
})
export class LoadingPopComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
