import {Component, OnInit} from '@angular/core';
import {FormArray, FormBuilder, FormGroup} from '@angular/forms';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {


  public listForm: FormGroup;

  constructor(private fb: FormBuilder) {
  }

  ngOnInit(): void {
    this.listForm = this.fb.group({
      row: this.fb.array([
        this.fb.control('')
      ])
    });
    document.getElementById('signup').hidden = true;
    document.getElementById('signin').hidden = true;
    document.getElementById('signout').hidden = false;
  }

  get row(): any {
    return this.listForm.get('row') as FormArray;
  }

  addrow(): void {
    this.row.push(this.fb.control(''));
  }

  clearRows(): void {
    const control = this.listForm.controls.row as FormArray;
    while (control.length) {
      control.removeAt(control.length - 1);
    }
  }

  delRow(i): void {
    const control = this.listForm.controls.row as FormArray;
    control.removeAt(i);
  }
}
