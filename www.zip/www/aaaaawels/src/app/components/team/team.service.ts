import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';

import { BehaviorSubject, Subject } from 'rxjs';


@Injectable()
export class TeamService {
  public teamData = new BehaviorSubject(null);


  constructor () {

  }

  setTeamData (data) {
    this.teamData.next(data);
  }

  getTeamData () {
    return this.teamData;
  }
}
