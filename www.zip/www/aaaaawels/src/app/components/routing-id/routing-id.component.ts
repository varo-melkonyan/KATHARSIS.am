import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HeaderService } from '../../services/header.service';
import { AddEmployeeService } from '../add-employee/add-employee.service';
import { AddTeamService } from '../add-team/add-team.service';
import { AddWellService } from '../add-well/add-well.service';

@Component({
  selector: 'app-routing-id',
  templateUrl: './routing-id.component.html',
  styleUrls: ['./routing-id.component.scss']
})
export class RoutingIdComponent implements OnInit, OnDestroy {
  private sub: any;
  private id: string;

  constructor(private route: ActivatedRoute,
              private addUserSvc: AddEmployeeService,
              private addTeamSvc: AddTeamService,
              private addWellSvc: AddWellService) {
    this.sub = this.route.params.subscribe(params => {
      if (params['id']) {
        this.id  = params['id'];
        this.addUserSvc.setEditItemName(this.id);
        this.addTeamSvc.setEditItemName(this.id);
        this.addWellSvc.setEditItemName(this.id);
      }
    });
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

}
