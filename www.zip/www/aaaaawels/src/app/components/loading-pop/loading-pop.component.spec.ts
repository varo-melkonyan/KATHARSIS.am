import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoadingPopComponent } from './loading-pop.component';

describe('LoadingPopComponent', () => {
  let component: LoadingPopComponent;
  let fixture: ComponentFixture<LoadingPopComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoadingPopComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoadingPopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
