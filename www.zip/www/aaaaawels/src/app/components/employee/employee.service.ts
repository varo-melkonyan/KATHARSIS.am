import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';

import { BehaviorSubject, Subject } from 'rxjs';


@Injectable()
export class EmployeeService {
  public employeeData = new BehaviorSubject(null);


  constructor () {

  }

  setEmployeeData (data) {
    this.employeeData.next(data);
  }

  getEmployeeData () {
    return this.employeeData;
  }
}
