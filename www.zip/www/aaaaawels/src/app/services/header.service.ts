import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';

import { Subject } from 'rxjs';


@Injectable()
export class HeaderService {
  public urlParams = new Subject<string>();
  public isActive = new Subject<boolean>();


  constructor () {

  }

  setUrlParams (url) {
    this.urlParams.next(url);
  }

  getUrlParams () {
    return this.urlParams;
  }

  setIsActive (isActive: boolean) {
    this.isActive.next(isActive);
  }

  getIsActive () {
    return this.isActive;
  }
}
