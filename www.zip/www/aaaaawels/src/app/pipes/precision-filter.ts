import { Pipe, PipeTransform } from '@angular/core';


@Pipe({
    name: 'precisionPipe'
})
export class PrecisionFilter implements PipeTransform {
    transform (items: any[], se: any) {
        if (se[0] && se[1]) {
            items =  items.filter((item) => {
                if ((+new Date(se[0]) - +new Date(se[1])) / item > 5040) {
                       return false;
                   } else {
                    return item;
                }
                });
        }
        return items;
    }
}
