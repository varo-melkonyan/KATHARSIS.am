export const localData = {
  wells: [],
  teams: [],
  users: []
};
