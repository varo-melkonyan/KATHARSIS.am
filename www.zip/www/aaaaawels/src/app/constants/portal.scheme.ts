export const portalScheme = [
    {
        name: 'getWell',
        reqName: 'SelectWellWide::REQ',
        resName: 'SelectWellWide::RES',
        req: function (svc: any) {
            const obj = {
                header: {
                    name: this.reqName,
                },
                body: {
                    records: {}
                },
            };
            svc.setParams(obj, this.resName, 0);
            return svc.getData(this.resName);
        }
    },
    {
        name: 'getTags',
        reqName: 'SelectWellTags::REQ',
        resName: 'SelectWellTags::RES',
        req: function (svc: any) {
            const obj = {
                header: {
                    name: this.reqName,
                },
                body: {
                    tags: {}
                },
            };
            svc.setParams(obj, this.resName, 0);
            return svc.getData(this.resName);
        }
    },
    {
        name: 'getUser',
        reqName: 'SelectUser::REQ',
        resName: 'SelectUser::RES',
        req: function (svc: any) {
            const obj = {
                header: {
                    name: this.reqName,
                },
                body: {
                    records: {}
                },
            };
            svc.setParams(obj, this.resName, 0);
            return svc.getData(this.resName);
        }
    },
    {
        name: 'getUserOne',
        reqName: 'GetOneUser::REQ',
        resName: 'GetOneUser::RES',
        req: function ($eq: any, svc: any) {
            if ($eq) {
                const obj = {
                    header: {
                        name: this.reqName,
                    },
                    body: {
                        record: {
                            accessLevel: {}
                        },
                        filter: {
                            name: {
                                $eq
                            }
                        }
                    }
                };
                svc.setParams(obj, this.resName, 0);
            }
            return svc.getData(this.resName);
        }
    },
    {
        name: 'getTeam',
        reqName: 'SelectTeamWide::REQ',
        resName: 'SelectTeamWide::RES',
        req: function (svc: any) {
            const obj = {
                header: {
                    name: this.reqName
                },
                body: {
                    records: {}
                }
            };
            svc.setParams(obj, this.resName, 0);
            return svc.getData(this.resName);
        }
    },
    {
        name: 'changePassword',
        reqName: 'ChangeUserPassword::REQ',
        resName: 'ChangeUserPassword::RES',
        req: function (body: any, svc: any) {
            const obj = {
                header: {
                    name: this.reqName,
                },
                body
            };
            svc.setParams(obj, this.resName, 0);
            return svc.getData(this.resName);
        }
    },
    {
        name: 'getWellUserMetaData',
        reqName: 'SelectWellUserMetadata::REQ',
        resName: 'SelectWellUserMetadata::RES',
        req: function (svc: any) {
            const obj = {
                header: {
                    name: this.reqName
                },
                body: {
                    records: {}
                }
            };
            svc.setParams(obj, this.resName, 0);
            return svc.getData(this.resName);
        }
    },
    {
        name: 'setTransferForm',
        reqName: 'TransferForm::REQ',
        resName: 'TransferForm::RES',
        req: function (formId: any, wellId: any, formType: any, svc: any) {
            const obj = {
                header: {
                    name: this.reqName
                },
                body: {
                    formId,
                    wellId,
                    formType

                }
            };
            svc.setParams(obj, this.resName, 0);
            return svc.getData(this.resName);
        }
    },
    {
        name: 'insertWell',
        reqName: 'InsertWell::REQ',
        resName: 'InsertWell::RES',
        req: function (record: any, svc: any) {
            const obj = {
                header: {
                    name: this.reqName,
                },
                body: {
                    record
                }
            };
            svc.setParams(obj, this.resName, 0);
            return svc.getData(this.resName);
        }
    },
    {
        name: 'insertTeam',
        reqName: 'InsertTeam::REQ',
        resName: 'InsertTeam::RES',
        req: function (record: any, svc: any) {
            if (record) {
                const obj = {
                    header: {
                        name: this.reqName,
                    },
                    body: {
                        record
                    }
                };
                svc.setParams(obj, this.resName, 0);
            }
            return svc.getData(this.resName);
        }
    },
    {
        name: 'insertUser',
        reqName: 'InsertUser::REQ',
        resName: 'InsertUser::RES',
        req: function (record: any, svc: any) {
            const obj = {
                header: {
                    name: this.reqName,
                },
                body: {
                    record
                },
            };
            svc.setParams(obj, this.resName, 0);
            return svc.getData(this.resName);
        }
    },
    {
        name: 'insertDWR',
        reqName: 'InsertDWR::REQ',
        resName: 'InsertDWR::RES',
        req: function (record: any, svc: any) {
            const obj = {
                header: {
                    name: this.reqName,
                },
                body: {
                    record
                },
            };
            svc.setParams(obj, this.resName, 0);
            return svc.getData(this.resName);
        }
    },
    {
        name: 'insertW3',
        reqName: 'InsertW3::REQ',
        resName: 'InsertW3::RES',
        req: function (record: any, svc: any) {
            const obj = {
                header: {
                    name: this.reqName,
                },
                body: {
                    record
                }
            };
            svc.setParams(obj, this.resName, 0);
            return svc.getData(this.resName);
        }
    },
    {
        name: 'insertW3A',
        reqName: 'InsertW3A::REQ',
        resName: 'InsertW3A::RES',
        req: function (record: any, svc: any) {
            const obj = {
                header: {
                    name: this.reqName,
                },
                body: {
                    record
                }
            };
            svc.setParams(obj, this.resName, 0);
            return svc.getData(this.resName);
        }
    },
    {
        name: 'selectDWR',
        reqName: 'SelectDWR::REQ',
        resName: 'SelectDWR::RES',
        req: function (svc: any) {
            const obj = {
                header: {
                    name: this.reqName
                },
                body: {}
            };
            svc.setParams(obj, this.resName, 0);
            return svc.getData(this.resName);
        }
    },
    {
        name: 'removeDWR',
        reqName: 'RemoveDWR::REQ',
        resName: 'RemoveDWR::RES',
        req: function (id: any, wellId: any, svc: any) {
            const obj = {
                header: {
                    name: this.reqName,
                },
                body: {
                    filter: {
                        id: {
                            $eq: id
                        },
                        wellId: {
                            $eq: wellId
                        }
                    }
                },
            };
            svc.setParams(obj, this.resName, 0);
            return svc.getData(this.resName);
        }
    },
    {
        name: 'selectW3A',
        reqName: 'SelectW3A::REQ',
        resName: 'SelectW3A::RES',
        req: function (svc: any) {
            const obj = {
                header: {
                    name: this.reqName,
                },
                body: {}
            };
            svc.setParams(obj, this.resName, 0);
            return svc.getData(this.resName);
        }
    },
    {
        name: 'selectW3',
        reqName: 'SelectW3::REQ',
        resName: 'SelectW3::RES',
        req: function (svc: any) {
            const obj = {
                header: {
                    name: this.reqName,
                },
                body: {}
            };
            svc.setParams(obj, this.resName, 0);
            return svc.getData(this.resName);
        }
    },
    {
        name: 'removeWell',
        reqName: 'RemoveWell::REQ',
        resName: 'RemoveWell::RES',
        req: function ($eq: any, svc: any) {
            if ($eq) {
                const obj = {
                    header: {
                        name: this.reqName,
                    },
                    body: {
                        filter: {
                            id: {
                                $eq
                            }
                        }
                    }
                };
                svc.setParams(obj, this.resName, 0);
            }
            return svc.getData(this.resName);
        }
    },
    {
        name: 'removeTeam',
        reqName: 'RemoveTeam::REQ',
        resName: 'RemoveTeam::RES',
        req: function ($eq: any, svc: any) {
            if ($eq) {
                const obj = {
                    header: {
                        name: this.reqName,
                    },
                    body: {
                        filter: {
                            id: {
                                $eq
                            }
                        }
                    }
                };
                svc.setParams(obj, this.resName, 0);
            }
            return svc.getData(this.resName);
        }
    },
    {
        name: 'removeUser',
        reqName: 'RemoveUser::REQ',
        resName: 'RemoveUser::RES',
        req: function ($eq: any, svc: any) {
            if ($eq) {
                const obj = {
                    header: {
                        name: this.reqName,
                    },
                    body: {
                        filter: {
                            id: {
                                $eq
                            }
                        }
                    }
                };
                svc.setParams(obj, this.resName, 0);
            }
            return svc.getData(this.resName);
        }
    },
    {
        name: 'updateWellUserMetadata',
        reqName: 'UpdateWellUserMetadata::REQ',
        resName: 'UpdateWellUserMetadata::RES',
        req: function ($eq: any, tags: any, svc: any) {
            const obj = {
                header: {
                    name: this.reqName,
                },
                body: {
                    filter: {itemId: {$eq}},
                    update: {$set: {metadata: {tags}}}
                }
            };
            svc.setParams(obj, this.resName, 0);
            return svc.getData(this.resName);
        }
    },
    {
        name: 'connectionEstablished',
        ltrName: 'ConnectionEstablished::LTR',
        get: function (svc: any) {
            const obj = {
                header: {
                    name: this.reqName,
                },
                body: {
                    userId: ''
                }
            };
            svc.setParams(obj, this.ltrName, 0);
            return svc.getData(this.ltrName);
        }
    }
];
