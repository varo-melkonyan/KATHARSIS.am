import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'wellFilter'
})
export class WellFilterPipe implements PipeTransform {
  transform(items: any, name: string, status: number, tag: string, team: string,  w3a: number, w3: number, dwr: number) {
    if (items && items.length) {
      return items.filter(item => {
        if (name && item.name.toLowerCase().indexOf(name.toLowerCase()) === -1) {
          return false;
        }
        if (status && +status !== +item.status) {
          return false;
        }
        if (tag && !item['metadata'].tags) {
          return false;
        }
        if (tag && item['metadata'].tags && item['metadata'].tags.toString().toLowerCase().indexOf(tag.toLowerCase()) === -1) {
          return false;
        }
        /*if (item.teamName === null) {
          item.teamName = '(any)';
        }*/
        if (team && (item.team ? item.team.name.toLowerCase().indexOf(team.toLowerCase()) === -1 :
            '(any)'.indexOf(team.toLowerCase()) === -1)) {
          return false;
        }
        if (w3a && +w3a !== +item.w3aStatus) {
          return false;
        }
        if (w3 && +w3 !== +item.w3Status) {
          return false;
        }
        if (dwr && +dwr !== +item.dwrStatus) {
          return false;
        }
        return true;
      });
    } else {
      return items;
    }
  }
}
