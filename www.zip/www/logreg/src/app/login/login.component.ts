import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {RegistrGuard} from '../registr.guard';
import {Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [RegistrGuard]
})
export class LoginComponent implements OnInit {

  public loginForm: FormGroup;

  constructor(private fb: FormBuilder, private router: Router) {
  }

  ngOnInit(): void {
    document.getElementById('signup').hidden = false;
    document.getElementById('signin').hidden = false;
    document.getElementById('signout').hidden = true;
    this.loginForm = this.fb.group({
      login: [''],
      password: ['']
    });
  }

  getLogin(): void {
    this.router.navigate(['/list']);
  }
}
