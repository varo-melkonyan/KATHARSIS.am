import {
    Component,
    EventEmitter, HostListener,
    Input,
    OnChanges,
    OnDestroy,
    OnInit,
    Output,
    SimpleChanges
} from '@angular/core';

@Component({
    selector: 'app-select-picker',
    templateUrl: './select-picker.component.html',
    styleUrls: ['./select-picker.component.scss']
})
export class SelectPickerComponent implements OnInit, OnChanges, OnDestroy {
    @Input() list: any;
    @Input() isCustom: boolean;
    @Input() value: string;
    @Output() selected = new EventEmitter();

    public customInputModel: string;
    public showList = false;
    public addBtn = false;
    public isFocusOut = false;

    @HostListener('keydown', ['$event']) onKeyDown(e) {
        if (e.keyCode === 9) {
            this.showList = false;
        }
    }

    constructor() {
    }

    ngOnInit() {
    }

    ngOnChanges(changes: SimpleChanges) {
        if (changes.value && changes.value.currentValue && changes.value.firstChange) {
            this.addCustomInput(changes.value.currentValue);
        }
    }

    ngOnDestroy() {
    }

    addCustomInput(value: string) {
        this.outputValue(value);
        this.addBtn = false;
        if (this.list.indexOf(this.customInputModel) < 0) {
            this.list.unshift(value);
        }
    }

    selectPick(value) {
        this.outputValue(value);
        this.isFocusOut = true;
        this.showList = false;
        this.addBtn = !(this.list.indexOf(this.customInputModel) > -1);
    }

    outputValue(value: string) {
        this.customInputModel = value;
        this.selected.emit(value);
    }

    addBtnSel(event) {
        this.validateInput(event);
        const value = event.target.value;
        this.addBtn = value && this.list.indexOf(value) < 0;
    }

    validateInput(event: any) {
        event.target.value = event.target.value.replace(/\s\s+/g, ' ');
        event.target.value = event.target.value === ' ' ? '' : event.target.value;
    }
}
