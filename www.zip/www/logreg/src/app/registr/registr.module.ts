import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RegistrRoutingModule} from './registr-routing.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RegistrRoutingModule
  ]
})
export class RegistrModule { }
