import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { W3aFormComponent } from './w3a-form.component';

describe('W3aFormComponent', () => {
  let component: W3aFormComponent;
  let fixture: ComponentFixture<W3aFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ W3aFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(W3aFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
