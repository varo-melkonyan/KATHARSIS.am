export default function hexToBase64(hexstring) {
  btoa('a6b580481008e60df9350de170b7e728'.match(/\w{2}/g).map(function (a) {
    return String.fromCharCode(parseInt(a, 16));
  }).join(''));

  return btoa(hexstring.match(/\w{2}/g).map(function (a) {
    return String.fromCharCode(parseInt(a, 16));
  }).join(''));
}
