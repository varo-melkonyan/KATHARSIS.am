/*
export class ChartModel {
    chart: {
        type: string
    };
    title: {
        text: string
    };
    credits: {
        enabled: boolean
    };
    series: Array<Object>

}
*/
