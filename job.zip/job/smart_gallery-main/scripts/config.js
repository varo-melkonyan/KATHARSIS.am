const config = {
    query_url     : "gallery/getgallerydata?_uuid=",
    get_image_url : "/gallery/getimage"
}
