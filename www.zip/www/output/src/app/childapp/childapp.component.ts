import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-childapp',
  templateUrl: './childapp.component.html',
  styleUrls: ['./childapp.component.css']
})
export class ChildappComponent implements OnInit {

  @Input() myinput;
  @Output() myoutput: EventEmitter<any> = new EventEmitter<any>();

  constructor() {
  }

  getData(data): void {
    this.myoutput.emit(data);
  }

  ngOnInit(): void {
  }

}
